<?php
// Cấu hình kết nối database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'club_management');

// Tạo kết nối MySQLi
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Set charset UTF-8
$conn->set_charset("utf8mb4");

// Hàm escape string để bảo mật
function escape_string($data) {
    global $conn;
    return $conn->real_escape_string(trim($data));
}

// Hàm thực thi query
function execute_query($sql) {
    global $conn;
    return $conn->query($sql);
}

// Hàm lấy kết quả query
function get_result($sql) {
    global $conn;
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result;
    }
    return false;
}

// Hàm lấy một dòng
function get_single_row($sql) {
    global $conn;
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Hàm đếm số dòng
function count_rows($sql) {
    global $conn;
    $result = $conn->query($sql);
    if ($result) {
        return $result->num_rows;
    }
    return 0;
}

// Hàm lấy ID vừa insert
function get_last_insert_id() {
    global $conn;
    return $conn->insert_id;
}
?>