<?php
$page_title = "Chi Tiết Sự Kiện - Sinh Viên";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('student');

$user_id = $_SESSION['user_id'];

// Lấy event_id
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Không tìm thấy sự kiện!";
    redirect('events.php');
}

$event_id = (int)$_GET['id'];

// Lấy thông tin sự kiện
$event_sql = "SELECT e.*, c.club_name, c.club_id, u.full_name as creator_name,
              (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status != 'cancelled') as registered_count,
              (SELECT status FROM event_registrations WHERE event_id = e.event_id AND user_id = $user_id) as my_status
              FROM events e
              INNER JOIN clubs c ON e.club_id = c.club_id
              INNER JOIN users u ON e.created_by = u.user_id
              WHERE e.event_id = $event_id AND e.status = 'approved'";
$event = get_single_row($event_sql);

if (!$event) {
    $_SESSION['error'] = "Không tìm thấy sự kiện!";
    redirect('events.php');
}

// Lấy danh sách người đã đăng ký
$participants_sql = "SELECT u.full_name, u.avatar, er.registration_date, er.status
                     FROM event_registrations er
                     INNER JOIN users u ON er.user_id = u.user_id
                     WHERE er.event_id = $event_id AND er.status != 'cancelled'
                     ORDER BY er.registration_date ASC";
$participants = get_result($participants_sql);

require_once '../includes/header.php';
?>

<style>
    .event-banner {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 60px 0;
    }
    
    .event-icon {
        width: 120px;
        height: 120px;
        background: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 50px;
        color: #667eea;
        margin: 0 auto;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    .info-box {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
    }
    
    .participant-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
    }
</style>

<div class="event-banner">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <div class="event-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
            </div>
            <div class="col-md-9">
                <div class="mb-3">
                    <span class="badge bg-white text-dark me-2">
                        <i class="fas fa-users me-1"></i>
                        <?php echo htmlspecialchars($event['club_name']); ?>
                    </span>
                    <?php if ($event['my_status'] === 'registered'): ?>
                        <span class="badge bg-success">
                            <i class="fas fa-check me-1"></i> Đã đăng ký
                        </span>
                    <?php elseif ($event['my_status'] === 'attended'): ?>
                        <span class="badge bg-primary">
                            <i class="fas fa-check-double me-1"></i> Đã tham dự
                        </span>
                    <?php endif; ?>
                </div>
                
                <h1 class="display-4 fw-bold mb-4"><?php echo htmlspecialchars($event['event_name']); ?></h1>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p class="mb-2">
                            <i class="fas fa-calendar me-2"></i>
                            <strong>Ngày:</strong> <?php echo format_date($event['event_date'], 'd/m/Y (l)'); ?>
                        </p>
                        <p class="mb-0">
                            <i class="fas fa-clock me-2"></i>
                            <strong>Giờ:</strong> 
                            <?php echo date('H:i', strtotime($event['start_time'])); ?> - 
                            <?php echo date('H:i', strtotime($event['end_time'])); ?>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p class="mb-2">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <strong>Địa điểm:</strong> <?php echo htmlspecialchars($event['location']); ?>
                        </p>
                        <?php if ($event['max_participants']): ?>
                        <p class="mb-0">
                            <i class="fas fa-user-friends me-2"></i>
                            <strong>Đã đăng ký:</strong> 
                            <?php echo $event['registered_count']; ?> / <?php echo $event['max_participants']; ?> người
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if (!$event['my_status'] && strtotime($event['event_date']) >= time()): ?>
                    <?php if (!$event['max_participants'] || $event['registered_count'] < $event['max_participants']): ?>
                        <form method="POST" action="events.php" class="d-inline">
                            <input type="hidden" name="action" value="register">
                            <input type="hidden" name="event_id" value="<?php echo $event_id; ?>">
                            <button type="submit" class="btn btn-light btn-lg"
                                    onclick="return confirm('Bạn có chắc muốn đăng ký sự kiện này?')">
                                <i class="fas fa-calendar-plus me-2"></i> Đăng Ký Ngay
                            </button>
                        </form>
                    <?php else: ?>
                        <button class="btn btn-secondary btn-lg" disabled>
                            <i class="fas fa-users me-2"></i> Sự Kiện Đã Đầy
                        </button>
                    <?php endif; ?>
                <?php elseif ($event['my_status'] === 'registered' && strtotime($event['event_date']) >= time()): ?>
                    <a href="events.php?action=cancel&id=<?php echo $event_id; ?>" 
                       class="btn btn-warning btn-lg"
                       onclick="return confirm('Bạn có chắc muốn hủy đăng ký?')">
                        <i class="fas fa-times me-2"></i> Hủy Đăng Ký
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container my-5">
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <div class="row">
        <!-- Thông tin chính -->
        <div class="col-md-8 mb-4">
            <!-- Mô tả -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-info-circle me-2 text-primary"></i> Thông Tin Chi Tiết
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($event['description']): ?>
                        <p><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                    <?php else: ?>
                        <p class="text-muted">Chưa có mô tả chi tiết</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Người tham gia -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-users me-2 text-success"></i> 
                        Người Tham Gia (<?php echo $event['registered_count']; ?>)
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($participants && $participants->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($participant = $participants->fetch_assoc()): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex align-items-center">
                                    <img src="../assets/images/<?php echo $participant['avatar']; ?>" 
                                         class="participant-avatar me-3"
                                         onerror="this.src='../assets/images/default-avatar.png'">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-0"><?php echo htmlspecialchars($participant['full_name']); ?></h6>
                                        <small class="text-muted">
                                            Đăng ký: <?php echo format_date($participant['registration_date'], 'd/m/Y H:i'); ?>
                                        </small>
                                    </div>
                                    <?php if ($participant['status'] === 'attended'): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check"></i> Đã tham dự
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-primary">Đã đăng ký</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-0">Chưa có người đăng ký</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Thông tin tổ chức -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-building me-2 text-warning"></i> Thông Tin
                    </h5>
                </div>
                <div class="card-body">
                    <div class="info-box">
                        <h6 class="mb-3">
                            <i class="fas fa-users me-2 text-primary"></i> Câu Lạc Bộ
                        </h6>
                        <p class="mb-0">
                            <a href="club-detail.php?id=<?php echo $event['club_id']; ?>" 
                               class="text-decoration-none">
                                <?php echo htmlspecialchars($event['club_name']); ?>
                            </a>
                        </p>
                    </div>
                    
                    <div class="info-box">
                        <h6 class="mb-3">
                            <i class="fas fa-user-tie me-2 text-success"></i> Người Tạo
                        </h6>
                        <p class="mb-0"><?php echo htmlspecialchars($event['creator_name']); ?></p>
                    </div>
                    
                    <div class="info-box">
                        <h6 class="mb-3">
                            <i class="fas fa-calendar-check me-2 text-info"></i> Trạng Thái
                        </h6>
                        <?php if (strtotime($event['event_date']) < time()): ?>
                            <span class="badge bg-secondary">Đã diễn ra</span>
                        <?php else: ?>
                            <span class="badge bg-success">Sắp diễn ra</span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($event['max_participants']): ?>
                    <div class="info-box">
                        <h6 class="mb-3">
                            <i class="fas fa-chart-pie me-2 text-danger"></i> Số Lượng
                        </h6>
                        <div class="progress mb-2" style="height: 25px;">
                            <?php 
                            $percent = ($event['registered_count'] / $event['max_participants']) * 100;
                            ?>
                            <div class="progress-bar <?php echo $percent >= 90 ? 'bg-danger' : 'bg-success'; ?>" 
                                 style="width: <?php echo $percent; ?>%">
                                <?php echo round($percent); ?>%
                            </div>
                        </div>
                        <small class="text-muted">
                            <?php echo $event['registered_count']; ?> / <?php echo $event['max_participants']; ?> người
                        </small>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Hành động -->
            <?php if ($event['my_status'] === 'registered' && strtotime($event['event_date']) >= time()): ?>
            <div class="card border-warning">
                <div class="card-header bg-warning text-dark">
                    <h6 class="mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i> Lưu Ý
                    </h6>
                </div>
                <div class="card-body">
                    <p class="mb-3">Bạn đã đăng ký sự kiện này. Vui lòng có mặt đúng giờ!</p>
                    <a href="events.php?action=cancel&id=<?php echo $event_id; ?>" 
                       class="btn btn-outline-danger w-100"
                       onclick="return confirm('Bạn có chắc muốn hủy đăng ký?')">
                        <i class="fas fa-times me-2"></i> Hủy Đăng Ký
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>