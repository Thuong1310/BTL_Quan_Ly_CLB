<?php
$page_title = "Chi Tiết CLB - Sinh Viên";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('student');

$user_id = $_SESSION['user_id'];

// Lấy club_id
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Không tìm thấy CLB!";
    redirect('clubs.php');
}

$club_id = (int)$_GET['id'];

// Lấy thông tin CLB
$club_sql = "SELECT c.*, 
             COUNT(DISTINCT cm.member_id) as member_count,
             (SELECT status FROM club_members WHERE club_id = c.club_id AND user_id = $user_id) as my_status
             FROM clubs c
             LEFT JOIN club_members cm ON c.club_id = cm.club_id AND cm.status = 'active'
             WHERE c.club_id = $club_id AND c.status = 'active'
             GROUP BY c.club_id";
$club = get_single_row($club_sql);

if (!$club) {
    $_SESSION['error'] = "Không tìm thấy CLB!";
    redirect('clubs.php');
}

// Lấy leaders
$leaders_sql = "SELECT u.full_name, u.email, cl.position
                FROM club_leaders cl
                INNER JOIN users u ON cl.user_id = u.user_id
                WHERE cl.club_id = $club_id AND cl.status = 'active'";
$leaders = get_result($leaders_sql);

// Lấy sự kiện của CLB
$events_sql = "SELECT * FROM events 
               WHERE club_id = $club_id 
               AND status = 'approved' 
               AND event_date >= CURDATE()
               ORDER BY event_date ASC
               LIMIT 5";
$events = get_result($events_sql);

// Lấy thành viên nổi bật
$members_sql = "SELECT u.full_name, u.avatar, cm.join_date
                FROM club_members cm
                INNER JOIN users u ON cm.user_id = u.user_id
                WHERE cm.club_id = $club_id AND cm.status = 'active'
                ORDER BY cm.join_date ASC
                LIMIT 12";
$members = get_result($members_sql);

require_once '../includes/header.php';
?>

<style>
    .club-banner {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 60px 0;
    }
    
    .club-avatar {
        width: 150px;
        height: 150px;
        background: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 60px;
        color: #667eea;
        margin: 0 auto;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    .member-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .leader-card {
        border-left: 4px solid #667eea;
    }
</style>

<div class="club-banner">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <div class="club-avatar">
                    <i class="fas fa-users"></i>
                </div>
            </div>
            <div class="col-md-9">
                <h1 class="display-4 fw-bold mb-3"><?php echo htmlspecialchars($club['club_name']); ?></h1>
                <p class="lead mb-3">
                    <span class="badge bg-white text-dark me-2">
                        <i class="fas fa-tag me-1"></i>
                        <?php echo htmlspecialchars($club['category']); ?>
                    </span>
                    <span class="badge bg-white text-dark">
                        <i class="fas fa-users me-1"></i>
                        <?php echo $club['member_count']; ?> thành viên
                    </span>
                </p>
                
                <?php if (!$club['my_status']): ?>
                    <form method="POST" action="clubs.php" class="d-inline">
                        <input type="hidden" name="action" value="join">
                        <input type="hidden" name="club_id" value="<?php echo $club_id; ?>">
                        <button type="submit" class="btn btn-light btn-lg"
                                onclick="return confirm('Bạn có chắc muốn tham gia CLB này?')">
                            <i class="fas fa-user-plus me-2"></i> Tham Gia CLB
                        </button>
                    </form>
                <?php elseif ($club['my_status'] === 'active'): ?>
                    <button class="btn btn-success btn-lg" disabled>
                        <i class="fas fa-check me-2"></i> Đã Tham Gia
                    </button>
                <?php elseif ($club['my_status'] === 'pending'): ?>
                    <button class="btn btn-warning btn-lg" disabled>
                        <i class="fas fa-clock me-2"></i> Đơn Chờ Duyệt
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container my-5">
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <div class="row">
        <!-- Thông tin chính -->
        <div class="col-md-8 mb-4">
            <!-- Giới thiệu -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-info-circle me-2 text-primary"></i> Giới Thiệu
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($club['description']): ?>
                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($club['description'])); ?></p>
                    <?php else: ?>
                        <p class="text-muted mb-0">Chưa có mô tả</p>
                    <?php endif; ?>
                    
                    <?php if ($club['establishment_date']): ?>
                        <hr>
                        <p class="mb-0">
                            <i class="fas fa-calendar me-2 text-primary"></i>
                            <strong>Ngày thành lập:</strong> <?php echo format_date($club['establishment_date']); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Sự kiện sắp tới -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-alt me-2 text-success"></i> Sự Kiện Sắp Tới
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($events && $events->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($event = $events->fetch_assoc()): ?>
                            <div class="list-group-item px-0 border-start border-4 border-success">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-2"><?php echo htmlspecialchars($event['event_name']); ?></h6>
                                        <p class="mb-1 text-muted small">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo format_date($event['event_date']); ?>
                                            <i class="fas fa-clock ms-3 me-1"></i>
                                            <?php echo date('H:i', strtotime($event['start_time'])); ?> - 
                                            <?php echo date('H:i', strtotime($event['end_time'])); ?>
                                        </p>
                                        <p class="mb-0 text-muted small">
                                            <i class="fas fa-map-marker-alt me-1"></i>
                                            <?php echo htmlspecialchars($event['location']); ?>
                                        </p>
                                    </div>
                                    <a href="event-detail.php?id=<?php echo $event['event_id']; ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Chi tiết
                                    </a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-0">Chưa có sự kiện sắp tới</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Thành viên -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-user-friends me-2 text-info"></i> 
                        Thành Viên (<?php echo $club['member_count']; ?>)
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($members && $members->num_rows > 0): ?>
                        <div class="row g-3">
                            <?php while($member = $members->fetch_assoc()): ?>
                            <div class="col-md-3 col-6 text-center">
                                <img src="../assets/images/<?php echo $member['avatar']; ?>" 
                                     class="member-avatar mb-2"
                                     onerror="this.src='../assets/images/default-avatar.png'">
                                <p class="mb-0 small"><strong><?php echo htmlspecialchars($member['full_name']); ?></strong></p>
                                <small class="text-muted">
                                    Từ <?php echo date('m/Y', strtotime($member['join_date'])); ?>
                                </small>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center mb-0">Chưa có thành viên</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Ban chủ nhiệm -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-user-tie me-2 text-warning"></i> Ban Chủ Nhiệm
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($leaders && $leaders->num_rows > 0): ?>
                        <?php while($leader = $leaders->fetch_assoc()): ?>
                        <div class="card leader-card mb-3">
                            <div class="card-body">
                                <h6 class="mb-1"><?php echo htmlspecialchars($leader['full_name']); ?></h6>
                                <p class="text-muted mb-2 small">
                                    <i class="fas fa-briefcase me-1"></i>
                                    <?php echo htmlspecialchars($leader['position']); ?>
                                </p>
                                <p class="text-muted mb-0 small">
                                    <i class="fas fa-envelope me-1"></i>
                                    <?php echo htmlspecialchars($leader['email']); ?>
                                </p>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center mb-0">Chưa có chủ nhiệm</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Thống kê -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-bar me-2 text-primary"></i> Thống Kê
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Thành viên</span>
                            <strong class="text-primary"><?php echo $club['member_count']; ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-primary" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <?php
                    $total_events = get_single_row("SELECT COUNT(*) as count FROM events WHERE club_id = $club_id")['count'];
                    $upcoming = get_single_row("SELECT COUNT(*) as count FROM events WHERE club_id = $club_id AND event_date >= CURDATE()")['count'];
                    ?>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Tổng sự kiện</span>
                            <strong class="text-success"><?php echo $total_events; ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-success" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Sắp diễn ra</span>
                            <strong class="text-warning"><?php echo $upcoming; ?></strong>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar bg-warning" style="width: <?php echo $total_events > 0 ? ($upcoming / $total_events * 100) : 0; ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>