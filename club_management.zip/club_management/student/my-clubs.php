<?php
$page_title = "CLB Của Tôi - Sinh Viên";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('student');

$user_id = $_SESSION['user_id'];

// Xử lý rời CLB
if (isset($_GET['action']) && $_GET['action'] === 'leave' && isset($_GET['id'])) {
    $club_id = (int)$_GET['id'];
    
    $update_sql = "UPDATE club_members 
                   SET status = 'left' 
                   WHERE club_id = $club_id AND user_id = $user_id";
    
    if (execute_query($update_sql)) {
        $_SESSION['success'] = "Đã rời CLB thành công!";
        
        // Thông báo cho leaders
        $leaders_sql = "SELECT user_id FROM club_leaders WHERE club_id = $club_id AND status = 'active'";
        $leaders = get_result($leaders_sql);
        
        $club_info = get_club_info($club_id);
        
        if ($leaders) {
            while($leader = $leaders->fetch_assoc()) {
                create_notification(
                    $leader['user_id'],
                    'Thành viên rời CLB',
                    $_SESSION['full_name'] . ' đã rời CLB ' . $club_info['club_name'],
                    'warning'
                );
            }
        }
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('my-clubs.php');
}

// Lấy danh sách CLB đã tham gia
$my_clubs_sql = "SELECT c.*, cm.join_date, cm.status as member_status,
                 COUNT(DISTINCT cm2.member_id) as member_count,
                 COUNT(DISTINCT e.event_id) as total_events,
                 (SELECT COUNT(*) FROM events e2 
                  INNER JOIN event_registrations er ON e2.event_id = er.event_id 
                  WHERE e2.club_id = c.club_id AND er.user_id = $user_id) as my_events_count
                 FROM clubs c
                 INNER JOIN club_members cm ON c.club_id = cm.club_id
                 LEFT JOIN club_members cm2 ON c.club_id = cm2.club_id AND cm2.status = 'active'
                 LEFT JOIN events e ON c.club_id = e.club_id
                 WHERE cm.user_id = $user_id AND cm.status = 'active'
                 GROUP BY c.club_id
                 ORDER BY cm.join_date DESC";
$my_clubs = get_result($my_clubs_sql);

// Đếm số CLB
$my_clubs_count = $my_clubs ? $my_clubs->num_rows : 0;

// Lấy đơn đang chờ duyệt
$pending_sql = "SELECT c.*, cm.created_at as apply_date
                FROM clubs c
                INNER JOIN club_members cm ON c.club_id = cm.club_id
                WHERE cm.user_id = $user_id AND cm.status = 'pending'
                ORDER BY cm.created_at DESC";
$pending_clubs = get_result($pending_sql);

require_once '../includes/header.php';
?>

<style>
    .my-club-card {
        transition: all 0.3s;
        height: 100%;
    }
    
    .my-club-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .club-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px 20px;
        text-align: center;
    }
    
    .stat-item {
        text-align: center;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 10px;
    }
</style>

<div class="container my-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="mb-4">
                <i class="fas fa-heart me-2 text-danger"></i> CLB Của Tôi
                <span class="badge bg-primary"><?php echo $my_clubs_count; ?></span>
            </h2>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Đơn chờ duyệt -->
    <?php if ($pending_clubs && $pending_clubs->num_rows > 0): ?>
    <div class="alert alert-warning mb-4">
        <h5 class="alert-heading">
            <i class="fas fa-clock me-2"></i> Đơn Đăng Ký Chờ Duyệt
        </h5>
        <hr>
        <?php while($pending = $pending_clubs->fetch_assoc()): ?>
        <div class="d-flex justify-content-between align-items-center mb-2">
            <div>
                <strong><?php echo htmlspecialchars($pending['club_name']); ?></strong><br>
                <small>Đã gửi lúc: <?php echo format_date($pending['apply_date'], 'd/m/Y H:i'); ?></small>
            </div>
            <span class="badge bg-warning">Chờ duyệt</span>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
    
    <!-- Danh sách CLB -->
    <?php if ($my_clubs && $my_clubs->num_rows > 0): ?>
        <div class="row g-4">
            <?php 
            mysqli_data_seek($my_clubs, 0); // Reset pointer
            while($club = $my_clubs->fetch_assoc()): 
            ?>
            <div class="col-md-6">
                <div class="card my-club-card">
                    <div class="club-header">
                        <i class="fas fa-users fa-3x mb-3"></i>
                        <h5 class="mb-0"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                        <small class="badge bg-white text-dark mt-2">
                            <?php echo htmlspecialchars($club['category']); ?>
                        </small>
                    </div>
                    
                    <div class="card-body">
                        <p class="text-muted small mb-3">
                            <?php 
                            $desc = $club['description'] ?? '';
                            echo htmlspecialchars(substr($desc, 0, 100)) . (strlen($desc) > 100 ? '...' : ''); 
                            ?>
                        </p>
                        
                        <div class="row g-2 mb-3">
                            <div class="col-4">
                                <div class="stat-item">
                                    <h5 class="mb-0 text-primary"><?php echo $club['member_count']; ?></h5>
                                    <small class="text-muted">Thành viên</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="stat-item">
                                    <h5 class="mb-0 text-success"><?php echo $club['total_events']; ?></h5>
                                    <small class="text-muted">Sự kiện</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="stat-item">
                                    <h5 class="mb-0 text-info"><?php echo $club['my_events_count']; ?></h5>
                                    <small class="text-muted">Đã tham gia</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <small class="text-muted">
                                <i class="fas fa-calendar me-1"></i>
                                Tham gia: <?php echo format_date($club['join_date']); ?>
                            </small>
                            <span class="badge bg-success">Thành viên</span>
                        </div>
                    </div>
                    
                    <div class="card-footer bg-white border-top">
                        <div class="d-flex gap-2">
                            <a href="club-detail.php?id=<?php echo $club['club_id']; ?>" 
                               class="btn btn-outline-primary flex-fill">
                                <i class="fas fa-info-circle me-1"></i> Chi tiết
                            </a>
                            <a href="?action=leave&id=<?php echo $club['club_id']; ?>" 
                               class="btn btn-outline-danger flex-fill"
                               onclick="return confirm('Bạn có chắc muốn rời CLB này?\nBạn sẽ không nhận được thông báo về các hoạt động của CLB nữa.')">
                                <i class="fas fa-sign-out-alt me-1"></i> Rời CLB
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-users-slash fa-5x text-muted mb-4"></i>
                <h4 class="text-muted mb-3">Bạn chưa tham gia CLB nào</h4>
                <p class="text-muted mb-4">Hãy khám phá và tham gia các CLB để kết nối và phát triển kỹ năng!</p>
                <a href="clubs.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-search me-2"></i> Khám Phá CLB
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>