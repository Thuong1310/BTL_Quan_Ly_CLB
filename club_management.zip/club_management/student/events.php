<?php
$page_title = "Sự Kiện - Sinh Viên";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('student');

$user_id = $_SESSION['user_id'];

// Xử lý đăng ký sự kiện
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $event_id = (int)$_POST['event_id'];
    
    // Kiểm tra đã đăng ký chưa
    $check_sql = "SELECT * FROM event_registrations WHERE event_id = $event_id AND user_id = $user_id";
    $existing = get_single_row($check_sql);
    
    if ($existing) {
        if ($existing['status'] === 'registered' || $existing['status'] === 'attended') {
            $_SESSION['error'] = "Bạn đã đăng ký sự kiện này rồi!";
        } else {
            $_SESSION['error'] = "Bạn đã hủy đăng ký sự kiện này trước đó!";
        }
    } else {
        // Kiểm tra số lượng tham gia
        $event_info = get_single_row("SELECT max_participants FROM events WHERE event_id = $event_id");
        
        if ($event_info && $event_info['max_participants']) {
            $registered_count = get_single_row("SELECT COUNT(*) as count FROM event_registrations 
                                               WHERE event_id = $event_id AND status != 'cancelled'")['count'];
            
            if ($registered_count >= $event_info['max_participants']) {
                $_SESSION['error'] = "Sự kiện đã đủ số lượng tham gia!";
                redirect('events.php');
            }
        }
        
        $insert_sql = "INSERT INTO event_registrations (event_id, user_id, status) 
                       VALUES ($event_id, $user_id, 'registered')";
        
        if (execute_query($insert_sql)) {
            $_SESSION['success'] = "Đăng ký sự kiện thành công!";
            
            // Tạo thông báo
            $event = get_single_row("SELECT event_name, created_by FROM events WHERE event_id = $event_id");
            create_notification(
                $event['created_by'],
                'Đăng ký sự kiện mới',
                $_SESSION['full_name'] . ' đã đăng ký tham gia sự kiện "' . $event['event_name'] . '"',
                'info'
            );
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('events.php');
}

// Xử lý hủy đăng ký
if (isset($_GET['action']) && $_GET['action'] === 'cancel' && isset($_GET['id'])) {
    $event_id = (int)$_GET['id'];
    
    $update_sql = "UPDATE event_registrations 
                   SET status = 'cancelled' 
                   WHERE event_id = $event_id AND user_id = $user_id";
    
    if (execute_query($update_sql)) {
        $_SESSION['success'] = "Đã hủy đăng ký sự kiện!";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('events.php');
}

// Tìm kiếm và lọc
$search = isset($_GET['search']) ? escape_string($_GET['search']) : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

$where_conditions = ["e.status = 'approved'"];

if (!empty($search)) {
    $where_conditions[] = "(e.event_name LIKE '%$search%' OR c.club_name LIKE '%$search%')";
}

if ($filter === 'upcoming') {
    $where_conditions[] = "e.event_date >= CURDATE()";
} elseif ($filter === 'past') {
    $where_conditions[] = "e.event_date < CURDATE()";
} elseif ($filter === 'registered') {
    $where_conditions[] = "er.user_id = $user_id AND er.status = 'registered'";
}

$where_sql = implode(' AND ', $where_conditions);

// Pagination
$per_page = 10;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $per_page;

// Đếm tổng số sự kiện
$count_sql = "SELECT COUNT(DISTINCT e.event_id) as total 
              FROM events e
              INNER JOIN clubs c ON e.club_id = c.club_id
              LEFT JOIN event_registrations er ON e.event_id = er.event_id
              WHERE $where_sql";
$total_events = get_single_row($count_sql)['total'];
$total_pages = ceil($total_events / $per_page);

// Lấy danh sách sự kiện
$events_sql = "SELECT e.*, c.club_name,
               (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status != 'cancelled') as registered_count,
               (SELECT status FROM event_registrations WHERE event_id = e.event_id AND user_id = $user_id) as my_status
               FROM events e
               INNER JOIN clubs c ON e.club_id = c.club_id
               LEFT JOIN event_registrations er ON e.event_id = er.event_id
               WHERE $where_sql
               GROUP BY e.event_id
               ORDER BY e.event_date DESC, e.start_time DESC
               LIMIT $per_page OFFSET $offset";
$events = get_result($events_sql);

require_once '../includes/header.php';
?>

<style>
    .event-card {
        transition: all 0.3s;
        border-left: 4px solid #667eea;
    }
    
    .event-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transform: translateX(5px);
    }
    
    .event-date {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 15px;
        text-align: center;
        border-radius: 10px;
        min-width: 100px;
    }
    
    .event-date .day {
        font-size: 2rem;
        font-weight: bold;
        line-height: 1;
    }
    
    .event-date .month {
        font-size: 0.9rem;
        text-transform: uppercase;
    }
</style>

<div class="container my-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="mb-4">
                <i class="fas fa-calendar-alt me-2"></i> Danh Sách Sự Kiện
            </h2>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Tìm kiếm và lọc -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" class="form-control" name="search" 
                               placeholder="Tìm kiếm sự kiện..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                
                <div class="col-md-3">
                    <select class="form-select" name="filter">
                        <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                        <option value="upcoming" <?php echo $filter === 'upcoming' ? 'selected' : ''; ?>>Sắp diễn ra</option>
                        <option value="past" <?php echo $filter === 'past' ? 'selected' : ''; ?>>Đã diễn ra</option>
                        <option value="registered" <?php echo $filter === 'registered' ? 'selected' : ''; ?>>Đã đăng ký</option>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i> Tìm Kiếm
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Danh sách sự kiện -->
    <?php if ($events && $events->num_rows > 0): ?>
        <?php while($event = $events->fetch_assoc()): ?>
        <div class="card event-card mb-3">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-2 col-sm-3 text-center mb-3 mb-md-0">
                        <div class="event-date">
                            <div class="day"><?php echo date('d', strtotime($event['event_date'])); ?></div>
                            <div class="month"><?php echo date('M Y', strtotime($event['event_date'])); ?></div>
                        </div>
                    </div>
                    
                    <div class="col-md-7 col-sm-9 mb-3 mb-md-0">
                        <h5 class="mb-2"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                        
                        <p class="mb-2">
                            <span class="badge bg-info me-2">
                                <i class="fas fa-users me-1"></i>
                                <?php echo htmlspecialchars($event['club_name']); ?>
                            </span>
                            
                            <?php if ($event['my_status'] === 'registered'): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check me-1"></i> Đã đăng ký
                                </span>
                            <?php elseif ($event['my_status'] === 'attended'): ?>
                                <span class="badge bg-primary">
                                    <i class="fas fa-check-double me-1"></i> Đã tham dự
                                </span>
                            <?php endif; ?>
                            
                            <?php if (strtotime($event['event_date']) < time()): ?>
                                <span class="badge bg-secondary">Đã diễn ra</span>
                            <?php endif; ?>
                        </p>
                        
                        <p class="mb-1 text-muted">
                            <i class="fas fa-clock me-2"></i>
                            <?php echo date('H:i', strtotime($event['start_time'])); ?> - 
                            <?php echo date('H:i', strtotime($event['end_time'])); ?>
                        </p>
                        
                        <p class="mb-1 text-muted">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <?php echo htmlspecialchars($event['location']); ?>
                        </p>
                        
                        <?php if ($event['max_participants']): ?>
                        <p class="mb-0 text-muted">
                            <i class="fas fa-user-friends me-2"></i>
                            <?php echo $event['registered_count']; ?> / <?php echo $event['max_participants']; ?> người
                            <?php 
                            $percent = ($event['registered_count'] / $event['max_participants']) * 100;
                            if ($percent >= 90): 
                            ?>
                                <span class="badge bg-warning text-dark ms-2">Sắp đầy</span>
                            <?php endif; ?>
                        </p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-3 text-end">
                        <div class="d-grid gap-2">
                            <a href="event-detail.php?id=<?php echo $event['event_id']; ?>" 
                               class="btn btn-outline-primary">
                                <i class="fas fa-info-circle me-1"></i> Chi tiết
                            </a>
                            
                            <?php if (!$event['my_status'] && strtotime($event['event_date']) >= time()): ?>
                                <?php if (!$event['max_participants'] || $event['registered_count'] < $event['max_participants']): ?>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="register">
                                        <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
                                        <button type="submit" class="btn btn-success w-100"
                                                onclick="return confirm('Bạn có chắc muốn đăng ký sự kiện này?')">
                                            <i class="fas fa-calendar-plus me-1"></i> Đăng ký
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-secondary w-100" disabled>
                                        <i class="fas fa-users me-1"></i> Đã đầy
                                    </button>
                                <?php endif; ?>
                            <?php elseif ($event['my_status'] === 'registered' && strtotime($event['event_date']) >= time()): ?>
                                <a href="?action=cancel&id=<?php echo $event['event_id']; ?>" 
                                   class="btn btn-warning"
                                   onclick="return confirm('Bạn có chắc muốn hủy đăng ký?')">
                                    <i class="fas fa-times me-1"></i> Hủy đăng ký
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($current_page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $current_page - 1; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo urlencode($filter); ?>">
                        <i class="fas fa-chevron-left"></i> Trước
                    </a>
                </li>
                <?php endif; ?>
                
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if ($i == 1 || $i == $total_pages || ($i >= $current_page - 2 && $i <= $current_page + 2)): ?>
                    <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo urlencode($filter); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php elseif ($i == $current_page - 3 || $i == $current_page + 3): ?>
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($current_page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $current_page + 1; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo urlencode($filter); ?>">
                        Sau <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
        
    <?php else: ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-calendar-times fa-5x text-muted mb-4"></i>
                <h4 class="text-muted">Không tìm thấy sự kiện nào</h4>
                <p class="text-muted">Hãy thử tìm kiếm với từ khóa khác</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>