<?php
$page_title = "Dashboard - Sinh Viên";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('student');

$user_id = $_SESSION['user_id'];

// Lấy thống kê tổng quan
$my_clubs_sql = "SELECT COUNT(*) as count FROM club_members 
                 WHERE user_id = $user_id AND status = 'active'";
$my_clubs_count = get_single_row($my_clubs_sql)['count'];

$my_events_sql = "SELECT COUNT(*) as count FROM event_registrations 
                  WHERE user_id = $user_id AND status != 'cancelled'";
$my_events_count = get_single_row($my_events_sql)['count'];

$attended_events_sql = "SELECT COUNT(*) as count FROM event_registrations 
                        WHERE user_id = $user_id AND status = 'attended'";
$attended_events = get_single_row($attended_events_sql)['count'];

$pending_requests_sql = "SELECT COUNT(*) as count FROM club_members 
                         WHERE user_id = $user_id AND status = 'pending'";
$pending_requests = get_single_row($pending_requests_sql)['count'];

// Lấy CLB của tôi với thông tin chi tiết
$my_clubs_list_sql = "SELECT c.*, cm.join_date,
                      COUNT(DISTINCT cm2.member_id) as total_members,
                      COUNT(DISTINCT e.event_id) as upcoming_events
                      FROM clubs c
                      INNER JOIN club_members cm ON c.club_id = cm.club_id
                      LEFT JOIN club_members cm2 ON c.club_id = cm2.club_id AND cm2.status = 'active'
                      LEFT JOIN events e ON c.club_id = e.club_id AND e.event_date >= CURDATE() AND e.status = 'approved'
                      WHERE cm.user_id = $user_id AND cm.status = 'active'
                      GROUP BY c.club_id
                      ORDER BY cm.join_date DESC
                      LIMIT 6";
$my_clubs_list = get_result($my_clubs_list_sql);

// Lấy sự kiện sắp tới mà tôi đã đăng ký
$upcoming_events_sql = "SELECT e.*, c.club_name, c.club_id,
                        DATEDIFF(e.event_date, CURDATE()) as days_left
                        FROM events e
                        INNER JOIN clubs c ON e.club_id = c.club_id
                        INNER JOIN event_registrations er ON e.event_id = er.event_id
                        WHERE er.user_id = $user_id 
                        AND er.status = 'registered'
                        AND e.event_date >= CURDATE()
                        AND e.status = 'approved'
                        ORDER BY e.event_date ASC, e.start_time ASC
                        LIMIT 5";
$upcoming_events = get_result($upcoming_events_sql);

// Lấy sự kiện mới chưa đăng ký
$new_events_sql = "SELECT e.*, c.club_name,
                   (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status != 'cancelled') as registered_count
                   FROM events e
                   INNER JOIN clubs c ON e.club_id = c.club_id
                   WHERE e.status = 'approved' 
                   AND e.event_date >= CURDATE()
                   AND e.event_id NOT IN (
                       SELECT event_id FROM event_registrations WHERE user_id = $user_id
                   )
                   ORDER BY e.created_at DESC
                   LIMIT 4";
$new_events = get_result($new_events_sql);

// Lấy hoạt động gần đây
$recent_activities_sql = "SELECT 'join_club' as type, c.club_name as title, cm.created_at as activity_date, c.club_id as ref_id
                          FROM club_members cm
                          INNER JOIN clubs c ON cm.club_id = c.club_id
                          WHERE cm.user_id = $user_id AND cm.status = 'active'
                          UNION ALL
                          SELECT 'register_event' as type, e.event_name as title, er.registration_date as activity_date, e.event_id as ref_id
                          FROM event_registrations er
                          INNER JOIN events e ON er.event_id = e.event_id
                          WHERE er.user_id = $user_id AND er.status != 'cancelled'
                          ORDER BY activity_date DESC
                          LIMIT 5";
$recent_activities = get_result($recent_activities_sql);

require_once '../includes/header.php';
?>

<style>
    .stat-card {
        border-radius: 15px;
        padding: 25px;
        color: white;
        transition: all 0.3s;
        height: 100%;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    }
    
    .stat-icon {
        width: 60px;
        height: 60px;
        background: rgba(255,255,255,0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }
    
    .club-mini-card {
        border-radius: 12px;
        transition: all 0.3s;
        border: 2px solid #f0f0f0;
    }
    
    .club-mini-card:hover {
        border-color: #667eea;
        box-shadow: 0 5px 15px rgba(102,126,234,0.2);
        transform: translateY(-3px);
    }
    
    .event-timeline {
        position: relative;
        padding-left: 30px;
    }
    
    .event-timeline::before {
        content: '';
        position: absolute;
        left: 10px;
        top: 0;
        bottom: 0;
        width: 2px;
        background: #e0e0e0;
    }
    
    .event-timeline-item {
        position: relative;
        padding-bottom: 20px;
    }
    
    .event-timeline-dot {
        position: absolute;
        left: -24px;
        top: 8px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #667eea;
        border: 3px solid white;
        box-shadow: 0 0 0 2px #667eea;
    }
    
    .activity-item {
        border-left: 3px solid #667eea;
        padding-left: 15px;
        margin-bottom: 15px;
    }
</style>

<div class="container-fluid my-4">
    <!-- Welcome Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-2">
                        <i class="fas fa-home me-2 text-primary"></i> 
                        Chào mừng trở lại, <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong>!
                    </h2>
                    <p class="text-muted mb-0">
                        <i class="fas fa-calendar-day me-2"></i>
                        <?php echo strftime('%A, %d %B %Y', time()); ?>
                    </p>
                </div>
                <div>
                    <a href="clubs.php" class="btn btn-primary me-2">
                        <i class="fas fa-search me-2"></i> Khám Phá CLB
                    </a>
                    <a href="events.php" class="btn btn-success">
                        <i class="fas fa-calendar-plus me-2"></i> Xem Sự Kiện
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    show_message('info');
    ?>
    
    <!-- Thống kê -->
    <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">CLB Đã Tham Gia</p>
                        <h2 class="mb-0 fw-bold"><?php echo $my_clubs_count; ?></h2>
                        <small class="opacity-75">
                            <?php if($pending_requests > 0): ?>
                                <i class="fas fa-clock me-1"></i><?php echo $pending_requests; ?> đang chờ
                            <?php else: ?>
                                <i class="fas fa-check-circle me-1"></i>Hoạt động tốt
                            <?php endif; ?>
                        </small>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card bg-success">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Sự Kiện Đã Đăng Ký</p>
                        <h2 class="mb-0 fw-bold"><?php echo $my_events_count; ?></h2>
                        <small class="opacity-75">
                            <i class="fas fa-calendar-check me-1"></i>Tổng cộng
                        </small>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card bg-info">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Đã Tham Dự</p>
                        <h2 class="mb-0 fw-bold"><?php echo $attended_events; ?></h2>
                        <small class="opacity-75">
                            <i class="fas fa-check-double me-1"></i>Điểm danh thành công
                        </small>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card bg-warning text-dark">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Tỷ Lệ Tham Dự</p>
                        <h2 class="mb-0 fw-bold">
                            <?php echo $my_events_count > 0 ? round(($attended_events / $my_events_count) * 100) : 0; ?>%
                        </h2>
                        <small class="opacity-75">
                            <i class="fas fa-chart-line me-1"></i>Hiệu suất
                        </small>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- CLB của tôi -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-users me-2 text-primary"></i> CLB Của Tôi
                    </h5>
                    <a href="my-clubs.php" class="btn btn-sm btn-outline-primary">
                        Xem tất cả <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
                <div class="card-body">
                    <?php if ($my_clubs_list && $my_clubs_list->num_rows > 0): ?>
                        <div class="row g-3">
                            <?php while($club = $my_clubs_list->fetch_assoc()): ?>
                            <div class="col-md-6">
                                <div class="club-mini-card card h-100">
                                    <div class="card-body">
                                        <div class="d-flex align-items-start mb-3">
                                            <div class="flex-shrink-0">
                                                <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                                                    <i class="fas fa-users fa-2x text-primary"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-1">
                                                    <a href="club-detail.php?id=<?php echo $club['club_id']; ?>" 
                                                       class="text-decoration-none text-dark">
                                                        <?php echo htmlspecialchars($club['club_name']); ?>
                                                    </a>
                                                </h6>
                                                <span class="badge bg-primary bg-opacity-10 text-primary">
                                                    <?php echo htmlspecialchars($club['category']); ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="row g-2 text-center">
                                            <div class="col-6">
                                                <div class="border rounded p-2">
                                                    <h6 class="mb-0 text-primary"><?php echo $club['total_members']; ?></h6>
                                                    <small class="text-muted">Thành viên</small>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="border rounded p-2">
                                                    <h6 class="mb-0 text-success"><?php echo $club['upcoming_events']; ?></h6>
                                                    <small class="text-muted">Sự kiện</small>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3 pt-3 border-top">
                                            <small class="text-muted">
                                                <i class="fas fa-calendar me-1"></i>
                                                Tham gia: <?php echo format_date($club['join_date']); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-users fa-4x text-muted mb-3"></i>
                            <h5 class="text-muted mb-3">Bạn chưa tham gia CLB nào</h5>
                            <p class="text-muted mb-4">Hãy khám phá và tham gia các CLB để trải nghiệm những hoạt động thú vị!</p>
                            <a href="clubs.php" class="btn btn-primary">
                                <i class="fas fa-search me-2"></i> Khám Phá CLB
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Sự kiện mới -->
            <div class="card border-0 shadow-sm mt-4">
                <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-star me-2 text-warning"></i> Sự Kiện Mới
                    </h5>
                    <a href="events.php" class="btn btn-sm btn-outline-warning">
                        Xem tất cả <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
                <div class="card-body">
                    <?php if ($new_events && $new_events->num_rows > 0): ?>
                        <div class="row g-3">
                            <?php while($event = $new_events->fetch_assoc()): ?>
                            <div class="col-md-6">
                                <div class="card border h-100 hover-shadow">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <span class="badge bg-warning text-dark">
                                                <i class="fas fa-calendar me-1"></i>
                                                <?php echo format_date($event['event_date'], 'd/m/Y'); ?>
                                            </span>
                                            <?php if($event['max_participants'] && $event['registered_count'] >= $event['max_participants'] * 0.9): ?>
                                                <span class="badge bg-danger">Sắp đầy</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <h6 class="mb-2">
                                            <a href="event-detail.php?id=<?php echo $event['event_id']; ?>" 
                                               class="text-decoration-none text-dark">
                                                <?php echo htmlspecialchars($event['event_name']); ?>
                                            </a>
                                        </h6>
                                        
                                        <p class="text-muted small mb-2">
                                            <i class="fas fa-building me-1"></i>
                                            <?php echo htmlspecialchars($event['club_name']); ?>
                                        </p>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo date('H:i', strtotime($event['start_time'])); ?>
                                            </small>
                                            <a href="event-detail.php?id=<?php echo $event['event_id']; ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye me-1"></i> Xem
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-0">Không có sự kiện mới</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Sự kiện sắp tới -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-check me-2 text-success"></i> Sự Kiện Sắp Tới
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($upcoming_events && $upcoming_events->num_rows > 0): ?>
                        <div class="event-timeline">
                            <?php while($event = $upcoming_events->fetch_assoc()): ?>
                            <div class="event-timeline-item">
                                <div class="event-timeline-dot"></div>
                                <div class="card border-0 bg-light">
                                    <div class="card-body p-3">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h6 class="mb-0">
                                                <a href="event-detail.php?id=<?php echo $event['event_id']; ?>" 
                                                   class="text-decoration-none text-dark">
                                                    <?php echo htmlspecialchars($event['event_name']); ?>
                                                </a>
                                            </h6>
                                            <?php if($event['days_left'] <= 2): ?>
                                                <span class="badge bg-danger">Gấp!</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <p class="text-muted small mb-2">
                                            <i class="fas fa-building me-1"></i>
                                            <a href="club-detail.php?id=<?php echo $event['club_id']; ?>" 
                                               class="text-decoration-none">
                                                <?php echo htmlspecialchars($event['club_name']); ?>
                                            </a>
                                        </p>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                <i class="fas fa-calendar-day me-1"></i>
                                                <?php 
                                                if($event['days_left'] == 0) {
                                                    echo 'Hôm nay';
                                                } elseif($event['days_left'] == 1) {
                                                    echo 'Ngày mai';
                                                } else {
                                                    echo 'Còn ' . $event['days_left'] . ' ngày';
                                                }
                                                ?>
                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i>
                                                <?php echo date('H:i', strtotime($event['start_time'])); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-3">Chưa có sự kiện nào</p>
                            <a href="events.php" class="btn btn-sm btn-primary">
                                <i class="fas fa-search me-2"></i> Tìm sự kiện
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Hoạt động gần đây -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-history me-2 text-info"></i> Hoạt Động Gần Đây
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($recent_activities && $recent_activities->num_rows > 0): ?>
                        <?php while($activity = $recent_activities->fetch_assoc()): ?>
                        <div class="activity-item">
                            <?php if($activity['type'] === 'join_club'): ?>
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="bg-primary bg-opacity-10 rounded-circle p-2">
                                            <i class="fas fa-users text-primary"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="mb-1 small">
                                            Đã tham gia <strong><?php echo htmlspecialchars($activity['title']); ?></strong>
                                        </p>
                                        <small class="text-muted">
                                            <i class="fas fa-clock me-1"></i>
                                            <?php echo format_date($activity['activity_date'], 'd/m/Y H:i'); ?>
                                        </small>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="bg-success bg-opacity-10 rounded-circle p-2">
                                            <i class="fas fa-calendar-check text-success"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="mb-1 small">
                                            Đã đăng ký <strong><?php echo htmlspecialchars($activity['title']); ?></strong>
                                        </p>
                                        <small class="text-muted">
                                            <i class="fas fa-clock me-1"></i>
                                            <?php echo format_date($activity['activity_date'], 'd/m/Y H:i'); ?>
                                        </small>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-history fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-0">Chưa có hoạt động nào</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>