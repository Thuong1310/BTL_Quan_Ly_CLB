<?php
$page_title = "Câu Lạc Bộ - Sinh Viên";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('student');

$user_id = $_SESSION['user_id'];

// Xử lý đăng ký vào CLB
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'join') {
    $club_id = (int)$_POST['club_id'];
    
    // Kiểm tra đã là thành viên chưa
    $check_sql = "SELECT * FROM club_members WHERE club_id = $club_id AND user_id = $user_id";
    $existing = get_single_row($check_sql);
    
    if ($existing) {
        if ($existing['status'] === 'active') {
            $_SESSION['error'] = "Bạn đã là thành viên của CLB này!";
        } elseif ($existing['status'] === 'pending') {
            $_SESSION['error'] = "Đơn đăng ký của bạn đang chờ duyệt!";
        } else {
            $_SESSION['error'] = "Đơn đăng ký của bạn đã bị từ chối trước đó!";
        }
    } else {
        $join_date = date('Y-m-d');
        $insert_sql = "INSERT INTO club_members (club_id, user_id, join_date, status) 
                       VALUES ($club_id, $user_id, '$join_date', 'pending')";
        
        if (execute_query($insert_sql)) {
            $_SESSION['success'] = "Đã gửi đơn đăng ký! Vui lòng chờ admin hoặc leader phê duyệt.";
            
            // Tạo thông báo cho leaders của CLB
            $leaders_sql = "SELECT user_id FROM club_leaders WHERE club_id = $club_id AND status = 'active'";
            $leaders = get_result($leaders_sql);
            
            $club_info = get_club_info($club_id);
            
            if ($leaders) {
                while($leader = $leaders->fetch_assoc()) {
                    create_notification(
                        $leader['user_id'],
                        'Đơn xin vào CLB mới',
                        $_SESSION['full_name'] . ' đã gửi đơn xin tham gia CLB ' . $club_info['club_name'],
                        'info',
                        'leader/members.php'
                    );
                }
            }
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('clubs.php');
}

// Tìm kiếm và lọc
$search = isset($_GET['search']) ? escape_string($_GET['search']) : '';
$category = isset($_GET['category']) ? escape_string($_GET['category']) : '';

$where_conditions = ["c.status = 'active'"];

if (!empty($search)) {
    $where_conditions[] = "(c.club_name LIKE '%$search%' OR c.description LIKE '%$search%')";
}

if (!empty($category)) {
    $where_conditions[] = "c.category = '$category'";
}

$where_sql = implode(' AND ', $where_conditions);

// Pagination
$per_page = 12;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $per_page;

// Đếm tổng số CLB
$count_sql = "SELECT COUNT(*) as total FROM clubs c WHERE $where_sql";
$total_clubs = get_single_row($count_sql)['total'];
$total_pages = ceil($total_clubs / $per_page);

// Lấy danh sách CLB
$clubs_sql = "SELECT c.*, 
              COUNT(DISTINCT cm.member_id) as member_count,
              COUNT(DISTINCT e.event_id) as event_count,
              (SELECT status FROM club_members WHERE club_id = c.club_id AND user_id = $user_id) as my_status
              FROM clubs c
              LEFT JOIN club_members cm ON c.club_id = cm.club_id AND cm.status = 'active'
              LEFT JOIN events e ON c.club_id = e.club_id
              WHERE $where_sql
              GROUP BY c.club_id
              ORDER BY c.created_at DESC
              LIMIT $per_page OFFSET $offset";
$clubs = get_result($clubs_sql);

// Lấy danh mục
$categories_sql = "SELECT DISTINCT category FROM clubs WHERE status = 'active' ORDER BY category";
$categories = get_result($categories_sql);

require_once '../includes/header.php';
?>

<style>
    .club-card {
        transition: all 0.3s;
        height: 100%;
        border-radius: 15px;
        overflow: hidden;
    }
    
    .club-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .club-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 40px 20px;
        text-align: center;
    }
    
    .club-icon {
        width: 80px;
        height: 80px;
        background: rgba(255,255,255,0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-size: 35px;
    }
</style>

<div class="container my-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="mb-4">
                <i class="fas fa-users me-2"></i> Danh Sách Câu Lạc Bộ
            </h2>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Tìm kiếm và lọc -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" class="form-control" name="search" 
                               placeholder="Tìm kiếm CLB..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                
                <div class="col-md-4">
                    <select class="form-select" name="category">
                        <option value="">-- Tất cả danh mục --</option>
                        <?php 
                        if ($categories && $categories->num_rows > 0):
                            while($cat = $categories->fetch_assoc()): 
                        ?>
                        <option value="<?php echo htmlspecialchars($cat['category']); ?>" 
                                <?php echo $category === $cat['category'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category']); ?>
                        </option>
                        <?php 
                            endwhile;
                        endif; 
                        ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i> Tìm Kiếm
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Danh sách CLB -->
    <?php if ($clubs && $clubs->num_rows > 0): ?>
        <div class="row g-4 mb-4">
            <?php while($club = $clubs->fetch_assoc()): ?>
            <div class="col-md-4">
                <div class="card club-card">
                    <div class="club-header">
                        <div class="club-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h5 class="mb-0"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                    </div>
                    
                    <div class="card-body">
                        <div class="mb-3">
                            <span class="badge bg-primary me-2">
                                <i class="fas fa-tag me-1"></i>
                                <?php echo htmlspecialchars($club['category']); ?>
                            </span>
                            <?php if ($club['my_status'] === 'active'): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check me-1"></i> Đã tham gia
                                </span>
                            <?php elseif ($club['my_status'] === 'pending'): ?>
                                <span class="badge bg-warning">
                                    <i class="fas fa-clock me-1"></i> Chờ duyệt
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <p class="text-muted small mb-3">
                            <?php 
                            $desc = $club['description'] ?? 'Chưa có mô tả';
                            echo htmlspecialchars(substr($desc, 0, 100)) . (strlen($desc) > 100 ? '...' : ''); 
                            ?>
                        </p>
                        
                        <div class="row text-center mb-3">
                            <div class="col-6">
                                <h5 class="mb-0 text-primary"><?php echo $club['member_count']; ?></h5>
                                <small class="text-muted">Thành viên</small>
                            </div>
                            <div class="col-6">
                                <h5 class="mb-0 text-success"><?php echo $club['event_count']; ?></h5>
                                <small class="text-muted">Sự kiện</small>
                            </div>
                        </div>
                        
                        <?php if ($club['establishment_date']): ?>
                        <p class="text-muted small mb-3">
                            <i class="fas fa-calendar me-2"></i>
                            Thành lập: <?php echo format_date($club['establishment_date']); ?>
                        </p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-footer bg-white border-top">
                        <div class="d-flex gap-2">
                            <a href="club-detail.php?id=<?php echo $club['club_id']; ?>" 
                               class="btn btn-outline-primary flex-fill">
                                <i class="fas fa-info-circle me-1"></i> Chi tiết
                            </a>
                            
                            <?php if (!$club['my_status']): ?>
                                <form method="POST" action="" class="flex-fill">
                                    <input type="hidden" name="action" value="join">
                                    <input type="hidden" name="club_id" value="<?php echo $club['club_id']; ?>">
                                    <button type="submit" class="btn btn-success w-100"
                                            onclick="return confirm('Bạn có chắc muốn tham gia CLB này?')">
                                        <i class="fas fa-user-plus me-1"></i> Tham gia
                                    </button>
                                </form>
                            <?php elseif ($club['my_status'] === 'active'): ?>
                                <button class="btn btn-success flex-fill" disabled>
                                    <i class="fas fa-check me-1"></i> Đã tham gia
                                </button>
                            <?php elseif ($club['my_status'] === 'pending'): ?>
                                <button class="btn btn-warning flex-fill" disabled>
                                    <i class="fas fa-clock me-1"></i> Chờ duyệt
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($current_page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $current_page - 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>">
                        <i class="fas fa-chevron-left"></i> Trước
                    </a>
                </li>
                <?php endif; ?>
                
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if ($i == 1 || $i == $total_pages || ($i >= $current_page - 2 && $i <= $current_page + 2)): ?>
                    <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php elseif ($i == $current_page - 3 || $i == $current_page + 3): ?>
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($current_page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $current_page + 1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>">
                        Sau <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
        
    <?php else: ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-users-slash fa-5x text-muted mb-4"></i>
                <h4 class="text-muted">Không tìm thấy câu lạc bộ nào</h4>
                <p class="text-muted">Hãy thử tìm kiếm với từ khóa khác</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>