<?php
session_start();

// Xóa tất cả session
session_unset();
session_destroy();

// Redirect về trang login
header("Location: login.php");
exit();
?>