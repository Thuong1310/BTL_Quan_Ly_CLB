<?php
// Kết nối CSDL
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "club_management";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Kết nối CSDL thất bại: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

echo "<h3>Đang thực hiện tạo tài khoản admin...</h3>";

try {
    // Thông tin admin muốn tạo
    $username = 'admin1';
    $password_raw = 'admin1'; // mật khẩu gốc
    $full_name = 'admin1';
    $email = 'admin@gmail.com';
    $phone = '0123456789';
    $role = 'admin';
    $status = 'active';

    // Mã hóa mật khẩu
    $password_hashed = password_hash($password_raw, PASSWORD_BCRYPT);

    // Kiểm tra nếu tài khoản admin đã tồn tại
    $check = $conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
    $check->bind_param("ss", $username, $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "❌ Tài khoản admin đã tồn tại. Không thể tạo lại.<br>";
        $check->close();
        $conn->close();
        exit;
    }
    $check->close();

    // Thêm tài khoản admin mới
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, phone, role, status) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $username, $email, $password_hashed, $full_name, $phone, $role, $status);

    if ($stmt->execute()) {
        echo "✅ TÀI KHOẢN ADMIN ĐÃ ĐƯỢC TẠO THÀNH CÔNG!<br><br>";
        echo "👤 <b>Tên đăng nhập:</b> $username<br>";
        echo "🔑 <b>Mật khẩu:</b> $password_raw<br>";
        echo "📧 <b>Email:</b> $email<br><br>";
        echo "<b>⚠️ VUI LÒNG XÓA FILE NÀY NGAY SAU KHI TẠO XONG!</b>";
    } else {
        echo "Lỗi khi thêm admin: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    echo "Đã xảy ra lỗi: " . $e->getMessage();
}
?>
