<?php
require_once 'config/database.php';
require_once 'includes/functions.php';


// Nếu chưa đăng nhập, hiển thị landing page
$page_title = "Trang Chủ - Hệ Thống Quản Lý CLB";

// Lấy thống kê cho landing page
$total_clubs = get_single_row("SELECT COUNT(*) as count FROM clubs WHERE status = 'active'")['count'];
$total_members = get_single_row("SELECT COUNT(*) as count FROM club_members WHERE status = 'active'")['count'];
$total_events = get_single_row("SELECT COUNT(*) as count FROM events WHERE status = 'approved' OR status = 'completed'")['count'];

// Lấy một số CLB nổi bật
$featured_clubs_sql = "SELECT c.*, COUNT(cm.member_id) as member_count
                       FROM clubs c
                       LEFT JOIN club_members cm ON c.club_id = cm.club_id AND cm.status = 'active'
                       WHERE c.status = 'active'
                       GROUP BY c.club_id
                       ORDER BY member_count DESC
                       LIMIT 6";
$featured_clubs = get_result($featured_clubs_sql);

// Lấy sự kiện sắp diễn ra
$upcoming_events_sql = "SELECT e.*, c.club_name
                        FROM events e
                        INNER JOIN clubs c ON e.club_id = c.club_id
                        WHERE e.status = 'approved' AND e.event_date >= CURDATE()
                        ORDER BY e.event_date ASC
                        LIMIT 6";
$upcoming_events = get_result($upcoming_events_sql);

require_once 'includes/header.php';
?>

<style>
    .hero-section {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 100px 0;
        margin-top: -20px;
    }
    
    .feature-box {
        padding: 40px 30px;
        text-align: center;
        border-radius: 15px;
        background: white;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: all 0.3s;
        height: 100%;
    }
    
    .feature-box:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    }
    
    .feature-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 35px;
        color: white;
    }
    
    .club-card {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: all 0.3s;
        height: 100%;
    }
    
    .club-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .club-icon {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 40px;
        text-align: center;
        font-size: 50px;
    }
    
    .event-card {
        border-left: 4px solid #667eea;
        transition: all 0.3s;
    }
    
    .event-card:hover {
        border-left-color: #764ba2;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .stat-number {
        font-size: 3rem;
        font-weight: bold;
    }
    
    .cta-section {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 80px 0;
        margin-top: 80px;
    }
</style>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">
                    Kết Nối & Phát Triển Cùng Câu Lạc Bộ
                </h1>
                <p class="lead mb-4">
                    Nền tảng quản lý câu lạc bộ toàn diện, giúp sinh viên tìm kiếm, 
                    tham gia và phát triển kỹ năng qua các hoạt động ngoại khóa.
                </p>
                <div class="d-flex gap-3">
                    <a href="register.php" class="btn btn-light btn-lg px-5">
                        <i class="fas fa-user-plus me-2"></i> Đăng Ký Ngay
                    </a>
                    <a href="login.php" class="btn btn-outline-light btn-lg px-5">
                        <i class="fas fa-sign-in-alt me-2"></i> Đăng Nhập
                    </a>
                </div>
            </div>
            <div class="col-lg-6 text-center mt-5 mt-lg-0">
                <i class="fas fa-users-cog" style="font-size: 200px; opacity: 0.2;"></i>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="stat-number text-primary"><?php echo $total_clubs; ?>+</div>
                <h5 class="text-muted">Câu Lạc Bộ</h5>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="stat-number text-success"><?php echo $total_members; ?>+</div>
                <h5 class="text-muted">Thành Viên</h5>
            </div>
            <div class="col-md-4">
                <div class="stat-number text-warning"><?php echo $total_events; ?>+</div>
                <h5 class="text-muted">Sự Kiện</h5>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-3">Tính Năng Nổi Bật</h2>
            <p class="text-muted">Hệ thống quản lý toàn diện với nhiều tính năng hữu ích</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h4>Tìm Kiếm CLB</h4>
                    <p class="text-muted">
                        Dễ dàng tìm kiếm và khám phá các câu lạc bộ phù hợp với sở thích của bạn
                    </p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h4>Quản Lý Sự Kiện</h4>
                    <p class="text-muted">
                        Đăng ký, tham gia và theo dõi các sự kiện một cách dễ dàng
                    </p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <h4>Điểm Danh QR</h4>
                    <p class="text-muted">
                        Điểm danh sự kiện nhanh chóng và chính xác bằng mã QR
                    </p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h4>Thông Báo Realtime</h4>
                    <p class="text-muted">
                        Nhận thông báo ngay lập tức về các hoạt động và sự kiện
                    </p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h4>Thống Kê Chi Tiết</h4>
                    <p class="text-muted">
                        Xem thống kê hoạt động và báo cáo chi tiết về CLB
                    </p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h4>Responsive Design</h4>
                    <p class="text-muted">
                        Sử dụng mượt mà trên mọi thiết bị di động và desktop
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Clubs -->
<?php if ($featured_clubs && $featured_clubs->num_rows > 0): ?>
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-3">Câu Lạc Bộ Nổi Bật</h2>
            <p class="text-muted">Khám phá các câu lạc bộ đang hoạt động sôi nổi</p>
        </div>
        
        <div class="row g-4">
            <?php while($club = $featured_clubs->fetch_assoc()): ?>
            <div class="col-md-4">
                <div class="card club-card">
                    <div class="club-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($club['club_name']); ?></h5>
                        <p class="text-muted mb-2">
                            <i class="fas fa-tag me-2"></i><?php echo htmlspecialchars($club['category']); ?>
                        </p>
                        <p class="card-text text-muted small">
                            <?php echo htmlspecialchars(substr($club['description'], 0, 100)); ?>...
                        </p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="badge bg-primary">
                                <i class="fas fa-user-friends me-1"></i>
                                <?php echo $club['member_count']; ?> thành viên
                            </span>
                            <a href="login.php" class="btn btn-sm btn-outline-primary">
                                Tham gia <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Upcoming Events -->
<?php if ($upcoming_events && $upcoming_events->num_rows > 0): ?>
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-3">Sự Kiện Sắp Diễn Ra</h2>
            <p class="text-muted">Đừng bỏ lỡ các sự kiện thú vị</p>
        </div>
        
        <div class="row g-4">
            <?php while($event = $upcoming_events->fetch_assoc()): ?>
            <div class="col-md-6">
                <div class="card event-card">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="me-3 text-center">
                                <div class="bg-primary text-white rounded p-2" style="min-width: 70px;">
                                    <div class="fw-bold"><?php echo date('d', strtotime($event['event_date'])); ?></div>
                                    <div class="small"><?php echo date('M', strtotime($event['event_date'])); ?></div>
                                </div>
                            </div>
                            <div class="flex-grow-1">
                                <h5 class="mb-2"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-users me-2"></i>
                                    <?php echo htmlspecialchars($event['club_name']); ?>
                                </p>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-clock me-2"></i>
                                    <?php echo date('H:i', strtotime($event['start_time'])); ?> - 
                                    <?php echo date('H:i', strtotime($event['end_time'])); ?>
                                </p>
                                <p class="text-muted mb-0">
                                    <i class="fas fa-map-marker-alt me-2"></i>
                                    <?php echo htmlspecialchars($event['location']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container text-center">
        <h2 class="display-5 fw-bold mb-4">Sẵn Sàng Bắt Đầu?</h2>
        <p class="lead mb-5">
            Tham gia ngay hôm nay để khám phá và kết nối với các câu lạc bộ tuyệt vời!
        </p>
        <a href="register.php" class="btn btn-light btn-lg px-5">
            <i class="fas fa-rocket me-2"></i> Đăng Ký Miễn Phí
        </a>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>