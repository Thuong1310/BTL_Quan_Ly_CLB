<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('leader');

header('Content-Type: application/json');

if(isset($_GET['id'])) {
    $event_id = (int)$_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    // Kiểm tra quyền
    $sql = "SELECT e.* FROM events e
            INNER JOIN club_leaders cl ON e.club_id = cl.club_id
            WHERE e.event_id = $event_id 
            AND cl.user_id = $user_id 
            AND cl.status = 'active'";
    
    $event = get_single_row($sql);
    
    if($event) {
        echo json_encode([
            'success' => true,
            'event' => $event
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Không tìm thấy sự kiện'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Thiếu thông tin'
    ]);
}
?>