<?php
$page_title = "Quản Lý Sự Kiện - Leader";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('leader');

$user_id = $_SESSION['user_id'];
$club_id = isset($_GET['club_id']) ? (int)$_GET['club_id'] : 0;

if (!$club_id || !is_club_leader($user_id, $club_id)) {
    $_SESSION['error'] = "Bạn không có quyền truy cập!";
    redirect('index.php');
}

$club_info = get_club_info($club_id);

// Xử lý thêm sự kiện
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $event_name = escape_string($_POST['event_name']);
    $description = escape_string($_POST['description']);
    $event_date = escape_string($_POST['event_date']);
    $start_time = escape_string($_POST['start_time']);
    $end_time = escape_string($_POST['end_time']);
    $location = escape_string($_POST['location']);
    $max_participants = !empty($_POST['max_participants']) ? (int)$_POST['max_participants'] : 'NULL';
    
    if(empty($event_name) || empty($event_date) || empty($start_time) || empty($location)) {
        $_SESSION['error'] = "Vui lòng nhập đầy đủ thông tin bắt buộc!";
    } else {
        $sql = "INSERT INTO events (club_id, event_name, description, event_date, start_time, end_time, location, max_participants, created_by, status) 
                VALUES ($club_id, '$event_name', '$description', '$event_date', '$start_time', '$end_time', '$location', $max_participants, $user_id, 'pending')";
        
        if(execute_query($sql)) {
            $_SESSION['success'] = "Tạo sự kiện thành công! Chờ admin phê duyệt.";
            
            // Thông báo cho admin
            $admins_sql = "SELECT user_id FROM users WHERE role = 'admin'";
            $admins = get_result($admins_sql);
            if($admins) {
                while($admin = $admins->fetch_assoc()) {
                    create_notification(
                        $admin['user_id'],
                        'Sự kiện mới chờ duyệt',
                        'CLB "' . $club_info['club_name'] . '" đã tạo sự kiện "' . $event_name . '"',
                        'info',
                        'admin/approvals.php'
                    );
                }
            }
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('events.php?club_id=' . $club_id);
}

// Xử lý cập nhật sự kiện
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $event_id = (int)$_POST['event_id'];
    $event_name = escape_string($_POST['event_name']);
    $description = escape_string($_POST['description']);
    $event_date = escape_string($_POST['event_date']);
    $start_time = escape_string($_POST['start_time']);
    $end_time = escape_string($_POST['end_time']);
    $location = escape_string($_POST['location']);
    $max_participants = !empty($_POST['max_participants']) ? (int)$_POST['max_participants'] : 'NULL';
    
    $sql = "UPDATE events SET 
            event_name = '$event_name',
            description = '$description',
            event_date = '$event_date',
            start_time = '$start_time',
            end_time = '$end_time',
            location = '$location',
            max_participants = $max_participants
            WHERE event_id = $event_id AND club_id = $club_id";
    
    if(execute_query($sql)) {
        $_SESSION['success'] = "Cập nhật sự kiện thành công!";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('events.php?club_id=' . $club_id);
}

// Xử lý xóa sự kiện
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $event_id = (int)$_GET['id'];
    
    $sql = "DELETE FROM events WHERE event_id = $event_id AND club_id = $club_id";
    
    if(execute_query($sql)) {
        $_SESSION['success'] = "Xóa sự kiện thành công!";
    } else {
        $_SESSION['error'] = "Không thể xóa sự kiện!";
    }
    redirect('events.php?club_id=' . $club_id);
}

// Lọc và tìm kiếm
$search = isset($_GET['search']) ? escape_string($_GET['search']) : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

$where_conditions = ["e.club_id = $club_id"];

if (!empty($search)) {
    $where_conditions[] = "e.event_name LIKE '%$search%'";
}

if ($filter === 'upcoming') {
    $where_conditions[] = "e.event_date >= CURDATE()";
} elseif ($filter === 'past') {
    $where_conditions[] = "e.event_date < CURDATE()";
} elseif ($filter === 'pending') {
    $where_conditions[] = "e.status = 'pending'";
} elseif ($filter === 'approved') {
    $where_conditions[] = "e.status = 'approved'";
}

$where_sql = implode(' AND ', $where_conditions);

// Lấy danh sách sự kiện
$events_sql = "SELECT e.*, 
               (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status != 'cancelled') as registered_count
               FROM events e
               WHERE $where_sql
               ORDER BY e.event_date DESC, e.start_time DESC";
$events = get_result($events_sql);

// Thống kê
$total_events = get_single_row("SELECT COUNT(*) as count FROM events WHERE club_id = $club_id")['count'];
$pending_count = get_single_row("SELECT COUNT(*) as count FROM events WHERE club_id = $club_id AND status = 'pending'")['count'];
$approved_count = get_single_row("SELECT COUNT(*) as count FROM events WHERE club_id = $club_id AND status = 'approved'")['count'];
$upcoming_count = get_single_row("SELECT COUNT(*) as count FROM events WHERE club_id = $club_id AND event_date >= CURDATE() AND status = 'approved'")['count'];

require_once '../includes/header.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-2">
                        <i class="fas fa-calendar-alt me-2"></i> Quản Lý Sự Kiện
                    </h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="index.php?club_id=<?php echo $club_id; ?>"><?php echo htmlspecialchars($club_info['club_name']); ?></a></li>
                            <li class="breadcrumb-item active">Sự kiện</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addEventModal">
                        <i class="fas fa-plus me-2"></i> Tạo Sự Kiện
                    </button>
                    <a href="index.php?club_id=<?php echo $club_id; ?>" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i> Quay Lại
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Thống kê -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-left: 4px solid #007bff !important;">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Tổng Sự Kiện</h6>
                    <h3 class="mb-0 fw-bold text-primary"><?php echo $total_events; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-left: 4px solid #28a745 !important;">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Đã Duyệt</h6>
                    <h3 class="mb-0 fw-bold text-success"><?php echo $approved_count; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-left: 4px solid #ffc107 !important;">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Chờ Duyệt</h6>
                    <h3 class="mb-0 fw-bold text-warning"><?php echo $pending_count; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-left: 4px solid #17a2b8 !important;">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Sắp Diễn Ra</h6>
                    <h3 class="mb-0 fw-bold text-info"><?php echo $upcoming_count; ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tìm kiếm và lọc -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <input type="hidden" name="club_id" value="<?php echo $club_id; ?>">
                
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" class="form-control" name="search" 
                               placeholder="Tìm kiếm sự kiện..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                
                <div class="col-md-4">
                    <select class="form-select" name="filter">
                        <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                        <option value="upcoming" <?php echo $filter === 'upcoming' ? 'selected' : ''; ?>>Sắp diễn ra</option>
                        <option value="past" <?php echo $filter === 'past' ? 'selected' : ''; ?>>Đã diễn ra</option>
                        <option value="pending" <?php echo $filter === 'pending' ? 'selected' : ''; ?>>Chờ duyệt</option>
                        <option value="approved" <?php echo $filter === 'approved' ? 'selected' : ''; ?>>Đã duyệt</option>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i> Lọc
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Danh sách sự kiện -->
    <?php if ($events && $events->num_rows > 0): ?>
        <div class="row">
            <?php while($event = $events->fetch_assoc()): ?>
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h5 class="mb-0"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                            <?php if($event['status'] === 'pending'): ?>
                                <span class="badge bg-warning">Chờ duyệt</span>
                            <?php elseif($event['status'] === 'approved'): ?>
                                <span class="badge bg-success">Đã duyệt</span>
                            <?php elseif($event['status'] === 'rejected'): ?>
                                <span class="badge bg-danger">Bị từ chối</span>
                            <?php endif; ?>
                        </div>
                        
                        <?php if($event['description']): ?>
                        <p class="text-muted small mb-3">
                            <?php echo htmlspecialchars(substr($event['description'], 0, 100)) . (strlen($event['description']) > 100 ? '...' : ''); ?>
                        </p>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <p class="mb-2">
                                <i class="fas fa-calendar text-primary me-2"></i>
                                <strong>Ngày:</strong> <?php echo format_date($event['event_date']); ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-clock text-success me-2"></i>
                                <strong>Giờ:</strong> 
                                <?php echo date('H:i', strtotime($event['start_time'])); ?> - 
                                <?php echo date('H:i', strtotime($event['end_time'])); ?>
                            </p>
                            <p class="mb-2">
                                <i class="fas fa-map-marker-alt text-danger me-2"></i>
                                <strong>Địa điểm:</strong> <?php echo htmlspecialchars($event['location']); ?>
                            </p>
                            <?php if($event['max_participants']): ?>
                            <p class="mb-0">
                                <i class="fas fa-users text-info me-2"></i>
                                <strong>Đăng ký:</strong> 
                                <?php echo $event['registered_count']; ?> / <?php echo $event['max_participants']; ?> người
                                <?php 
                                $percent = ($event['registered_count'] / $event['max_participants']) * 100;
                                ?>
                                <div class="progress mt-2" style="height: 8px;">
                                    <div class="progress-bar bg-info" style="width: <?php echo $percent; ?>%"></div>
                                </div>
                            </p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button class="btn btn-sm btn-outline-primary flex-fill" 
                                    onclick="editEvent(<?php echo $event['event_id']; ?>)">
                                <i class="fas fa-edit me-1"></i> Sửa
                            </button>
                            <a href="event-detail.php?id=<?php echo $event['event_id']; ?>&club_id=<?php echo $club_id; ?>" 
                               class="btn btn-sm btn-outline-info flex-fill">
                                <i class="fas fa-eye me-1"></i> Chi tiết
                            </a>
                            <button class="btn btn-sm btn-outline-danger" 
                                    onclick="deleteEvent(<?php echo $event['event_id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="fas fa-calendar-times fa-5x text-muted mb-4"></i>
                <h4 class="text-muted mb-3">Chưa có sự kiện nào</h4>
                <p class="text-muted mb-4">Hãy tạo sự kiện đầu tiên cho CLB của bạn!</p>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addEventModal">
                    <i class="fas fa-plus me-2"></i> Tạo Sự Kiện
                </button>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Modal Thêm Sự Kiện -->
<div class="modal fade" id="addEventModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-calendar-plus me-2"></i> Tạo Sự Kiện Mới
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label class="form-label">Tên Sự Kiện <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="event_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Mô Tả</label>
                        <textarea class="form-control" name="description" rows="4"></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Ngày Tổ Chức <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="event_date" 
                                   min="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Giờ Bắt Đầu <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" name="start_time" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Giờ Kết Thúc <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" name="end_time" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Địa Điểm <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="location" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Số Lượng Tối Đa</label>
                            <input type="number" class="form-control" name="max_participants" min="1">
                            <small class="text-muted">Để trống nếu không giới hạn</small>
                        </div>
                    </div>
                    
                    <div class="alert alert-info mb-0">
                        <i class="fas fa-info-circle me-2"></i>
                        Sự kiện sẽ được gửi đến admin để phê duyệt trước khi công khai.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save me-2"></i> Tạo Sự Kiện
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Sửa Sự Kiện -->
<div class="modal fade" id="editEventModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-edit me-2"></i> Chỉnh Sửa Sự Kiện
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body" id="editEventForm">
                    <!-- Content will be loaded via JS -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Cập Nhật
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editEvent(eventId) {
    fetch('get_event.php?id=' + eventId)
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                const event = data.event;
                document.getElementById('editEventForm').innerHTML = `
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="event_id" value="${event.event_id}">
                    
                    <div class="mb-3">
                        <label class="form-label">Tên Sự Kiện <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="event_name" value="${event.event_name}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Mô Tả</label>
                        <textarea class="form-control" name="description" rows="4">${event.description || ''}</textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Ngày Tổ Chức <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="event_date" value="${event.event_date}" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Giờ Bắt Đầu <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" name="start_time" value="${event.start_time}" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Giờ Kết Thúc <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" name="end_time" value="${event.end_time}" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Địa Điểm <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="location" value="${event.location}" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Số Lượng Tối Đa</label>
                            <input type="number" class="form-control" name="max_participants" value="${event.max_participants || ''}" min="1">
                        </div>
                    </div>
                `;
                
                new bootstrap.Modal(document.getElementById('editEventModal')).show();
            }
        })
        .catch(error => {
            alert('Có lỗi xảy ra!');
            console.error(error);
        });
}

function deleteEvent(eventId) {
    if(confirm('Bạn có chắc muốn xóa sự kiện này?\nTất cả dữ liệu liên quan sẽ bị xóa!')) {
        window.location.href = 'events.php?action=delete&id=' + eventId + '&club_id=<?php echo $club_id; ?>';
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>