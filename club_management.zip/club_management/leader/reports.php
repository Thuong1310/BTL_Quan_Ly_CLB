<?php
$page_title = "Báo Cáo - Leader";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('leader');

$user_id = $_SESSION['user_id'];
$club_id = isset($_GET['club_id']) ? (int)$_GET['club_id'] : 0;

if (!$club_id || !is_club_leader($user_id, $club_id)) {
    $_SESSION['error'] = "Bạn không có quyền truy cập!";
    redirect('index.php');
}

$club_info = get_club_info($club_id);

// Lấy khoảng thời gian
$start_date = isset($_GET['start_date']) ? escape_string($_GET['start_date']) : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? escape_string($_GET['end_date']) : date('Y-m-t');

// Thống kê thành viên
$total_members = get_single_row("SELECT COUNT(*) as count FROM club_members 
                                 WHERE club_id = $club_id AND status = 'active'")['count'];

$new_members = get_single_row("SELECT COUNT(*) as count FROM club_members 
                               WHERE club_id = $club_id 
                               AND status = 'active'
                               AND join_date BETWEEN '$start_date' AND '$end_date'")['count'];

// Thống kê sự kiện
$total_events = get_single_row("SELECT COUNT(*) as count FROM events 
                                WHERE club_id = $club_id 
                                AND event_date BETWEEN '$start_date' AND '$end_date'")['count'];

$completed_events = get_single_row("SELECT COUNT(*) as count FROM events 
                                    WHERE club_id = $club_id 
                                    AND event_date BETWEEN '$start_date' AND '$end_date'
                                    AND event_date < CURDATE()
                                    AND status = 'approved'")['count'];

// Thống kê tài chính
$finance_stats = get_single_row("SELECT 
                                 SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) as income,
                                 SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) as expense
                                 FROM finances 
                                 WHERE club_id = $club_id 
                                 AND transaction_date BETWEEN '$start_date' AND '$end_date'");
$income = $finance_stats['income'] ?? 0;
$expense = $finance_stats['expense'] ?? 0;

// Thành viên tích cực nhất
$top_members_sql = "SELECT u.full_name, u.avatar,
                    COUNT(DISTINCT er.event_id) as events_count
                    FROM users u
                    INNER JOIN club_members cm ON u.user_id = cm.user_id
                    LEFT JOIN event_registrations er ON u.user_id = er.user_id AND er.status = 'attended'
                    LEFT JOIN events e ON er.event_id = e.event_id AND e.club_id = $club_id
                    WHERE cm.club_id = $club_id AND cm.status = 'active'
                    GROUP BY u.user_id
                    ORDER BY events_count DESC
                    LIMIT 10";
$top_members = get_result($top_members_sql);

// Sự kiện trong kỳ
$events_list_sql = "SELECT e.*, 
                    (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status != 'cancelled') as registered_count,
                    (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status = 'attended') as attended_count
                    FROM events e
                    WHERE e.club_id = $club_id 
                    AND e.event_date BETWEEN '$start_date' AND '$end_date'
                    ORDER BY e.event_date DESC";
$events_list = get_result($events_list_sql);

// Giao dịch trong kỳ
$transactions_sql = "SELECT * FROM finances 
                     WHERE club_id = $club_id 
                     AND transaction_date BETWEEN '$start_date' AND '$end_date'
                     ORDER BY transaction_date DESC";
$transactions = get_result($transactions_sql);

// Thống kê theo tháng
$monthly_stats_sql = "SELECT 
                      DATE_FORMAT(e.event_date, '%Y-%m') as month,
                      COUNT(DISTINCT e.event_id) as events_count,
                      COUNT(DISTINCT er.registration_id) as registrations_count
                      FROM events e
                      LEFT JOIN event_registrations er ON e.event_id = er.event_id
                      WHERE e.club_id = $club_id 
                      AND e.event_date BETWEEN '$start_date' AND '$end_date'
                      GROUP BY DATE_FORMAT(e.event_date, '%Y-%m')
                      ORDER BY month";
$monthly_stats = get_result($monthly_stats_sql);

require_once '../includes/header.php';
?>

<style>
    @media print {
        .no-print {
            display: none !important;
        }
        .card {
            break-inside: avoid;
        }
    }
    
    .report-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        border-radius: 15px;
        margin-bottom: 30px;
    }
    
    .stat-box {
        background: white;
        border-radius: 12px;
        padding: 20px;
        border: 2px solid #e0e0e0;
        text-align: center;
    }
</style>

<div class="container-fluid my-4">
    <div class="row mb-4 no-print">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-2">
                        <i class="fas fa-file-alt me-2"></i> Báo Cáo Hoạt Động
                    </h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="index.php?club_id=<?php echo $club_id; ?>"><?php echo htmlspecialchars($club_info['club_name']); ?></a></li>
                            <li class="breadcrumb-item active">Báo cáo</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button onclick="window.print()" class="btn btn-primary">
                        <i class="fas fa-print me-2"></i> In Báo Cáo
                    </button>
                    <a href="index.php?club_id=<?php echo $club_id; ?>" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i> Quay Lại
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bộ lọc -->
    <div class="card border-0 shadow-sm mb-4 no-print">
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <input type="hidden" name="club_id" value="<?php echo $club_id; ?>">
                
                <div class="col-md-4">
                    <label class="form-label">Từ Ngày</label>
                    <input type="date" class="form-control" name="start_date" 
                           value="<?php echo $start_date; ?>">
                </div>
                
                <div class="col-md-4">
                    <label class="form-label">Đến Ngày</label>
                    <input type="date" class="form-control" name="end_date" 
                           value="<?php echo $end_date; ?>">
                </div>
                
                <div class="col-md-4">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-sync me-2"></i> Tạo Báo Cáo
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Header báo cáo -->
    <div class="report-header">
        <div class="text-center">
            <h2 class="mb-3">BÁO CÁO HOẠT ĐỘNG CÂU LẠC BỘ</h2>
            <h4 class="mb-3"><?php echo htmlspecialchars($club_info['club_name']); ?></h4>
            <p class="mb-0">
                Từ ngày <?php echo format_date($start_date); ?> đến <?php echo format_date($end_date); ?>
            </p>
        </div>
    </div>
    
    <!-- Tổng quan -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-0">
            <h5 class="mb-0">
                <i class="fas fa-chart-line me-2"></i> Tổng Quan
            </h5>
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="stat-box border-primary">
                        <i class="fas fa-users fa-3x text-primary mb-2"></i>
                        <h3 class="mb-0"><?php echo $total_members; ?></h3>
                        <p class="text-muted mb-0">Tổng Thành Viên</p>
                        <?php if($new_members > 0): ?>
                        <small class="text-success">
                            <i class="fas fa-arrow-up me-1"></i>+<?php echo $new_members; ?> mới
                        </small>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="stat-box border-success">
                        <i class="fas fa-calendar-alt fa-3x text-success mb-2"></i>
                        <h3 class="mb-0"><?php echo $total_events; ?></h3>
                        <p class="text-muted mb-0">Sự Kiện Tổ Chức</p>
                        <small class="text-success">
                            <?php echo $completed_events; ?> hoàn thành
                        </small>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="stat-box border-info">
                        <i class="fas fa-arrow-up fa-3x text-success mb-2"></i>
                        <h3 class="mb-0"><?php echo format_currency($income); ?></h3>
                        <p class="text-muted mb-0">Thu Nhập</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="stat-box border-warning">
                        <i class="fas fa-arrow-down fa-3x text-danger mb-2"></i>
                        <h3 class="mb-0"><?php echo format_currency($expense); ?></h3>
                        <p class="text-muted mb-0">Chi Tiêu</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Thống kê sự kiện -->
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-check me-2"></i> Chi Tiết Sự Kiện
                    </h5>
                </div>
                <div class="card-body">
                    <?php if($events_list && $events_list->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Tên Sự Kiện</th>
                                        <th>Ngày</th>
                                        <th class="text-center">Đăng Ký</th>
                                        <th class="text-center">Tham Dự</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($event = $events_list->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                                        <td><?php echo format_date($event['event_date'], 'd/m/Y'); ?></td>
                                        <td class="text-center"><?php echo $event['registered_count']; ?></td>
                                        <td class="text-center"><?php echo $event['attended_count']; ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-muted mb-0">Không có sự kiện trong kỳ</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Top thành viên -->
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-star me-2"></i> Thành Viên Tích Cực
                    </h5>
                </div>
                <div class="card-body">
                    <?php if($top_members && $top_members->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php 
                            $rank = 1;
                            while($member = $top_members->fetch_assoc()): 
                            ?>
                            <div class="list-group-item px-0 d-flex align-items-center">
                                <span class="badge bg-primary me-3"><?php echo $rank++; ?></span>
                                <img src="../assets/images/<?php echo $member['avatar']; ?>" 
                                     class="rounded-circle me-3"
                                     style="width: 40px; height: 40px; object-fit: cover;"
                                     onerror="this.src='../assets/images/default-avatar.png'">
                                <div class="flex-grow-1">
                                    <h6 class="mb-0"><?php echo htmlspecialchars($member['full_name']); ?></h6>
                                </div>
                                <span class="badge bg-success"><?php echo $member['events_count']; ?> sự kiện</span>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-muted mb-0">Chưa có dữ liệu</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Chi tiết tài chính -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white border-0">
            <h5 class="mb-0">
                <i class="fas fa-money-bill-wave me-2"></i> Chi Tiết Tài Chính
            </h5>
        </div>
        <div class="card-body">
            <?php if($transactions && $transactions->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Ngày</th>
                                <th>Loại</th>
                                <th>Danh Mục</th>
                                <th>Mô Tả</th>
                                <th class="text-end">Số Tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($trans = $transactions->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo format_date($trans['transaction_date'], 'd/m/Y'); ?></td>
                                <td>
                                    <?php if($trans['transaction_type'] === 'income'): ?>
                                        <span class="badge bg-success">THU</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">CHI</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($trans['category']); ?></td>
                                <td><?php echo htmlspecialchars($trans['description']); ?></td>
                                <td class="text-end <?php echo $trans['transaction_type'] === 'income' ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo $trans['transaction_type'] === 'income' ? '+' : '-'; ?>
                                    <?php echo format_currency($trans['amount']); ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <tr class="fw-bold">
                                <td colspan="4" class="text-end">TỔNG CỘNG:</td>
                                <td class="text-end <?php echo ($income - $expense) >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo format_currency($income - $expense); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-center text-muted mb-0">Không có giao dịch trong kỳ</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Kết luận -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0">
            <h5 class="mb-0">
                <i class="fas fa-clipboard-check me-2"></i> Nhận Xét & Đánh Giá
            </h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-success mb-3">
                        <i class="fas fa-check-circle me-2"></i> Điểm Mạnh
                    </h6>
                    <ul>
                        <?php if($total_events > 0): ?>
                        <li>Tổ chức được <?php echo $total_events; ?> sự kiện trong kỳ</li>
                        <?php endif; ?>
                        
                        <?php if($new_members > 0): ?>
                        <li>Thu hút được <?php echo $new_members; ?> thành viên mới</li>
                        <?php endif; ?>
                        
                        <?php if($income > $expense): ?>
                        <li>Tài chính dương, có thặng dư <?php echo format_currency($income - $expense); ?></li>
                        <?php endif; ?>
                        
                        <?php if($completed_events > 0): ?>
                        <li>Hoàn thành <?php echo $completed_events; ?> sự kiện theo kế hoạch</li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <div class="col-md-6">
                    <h6 class="text-warning mb-3">
                        <i class="fas fa-exclamation-triangle me-2"></i> Cần Cải Thiện
                    </h6>
                    <ul>
                        <?php if($expense > $income): ?>
                        <li>Chi tiêu vượt thu nhập <?php echo format_currency($expense - $income); ?></li>
                        <?php endif; ?>
                        
                        <?php if($total_events == 0): ?>
                        <li>Chưa tổ chức sự kiện nào trong kỳ</li>
                        <?php endif; ?>
                        
                        <?php if($new_members == 0): ?>
                        <li>Chưa có thành viên mới tham gia</li>
                        <?php endif; ?>
                        
                        <li>Cần tăng cường hoạt động và thu hút thành viên</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Chữ ký -->
    <div class="row mt-5 no-print">
        <div class="col-md-6 text-center">
            <p class="mb-5"><strong>Người Lập</strong></p>
            <p class="mb-0"><?php echo htmlspecialchars($_SESSION['full_name']); ?></p>
        </div>
        <div class="col-md-6 text-center">
            <p class="mb-5"><strong>Ngày Lập</strong></p>
            <p class="mb-0"><?php echo date('d/m/Y'); ?></p>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>