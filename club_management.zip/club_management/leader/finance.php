<?php
$page_title = "Quản Lý Tài Chính - Leader";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('leader');

$user_id = $_SESSION['user_id'];
$club_id = isset($_GET['club_id']) ? (int)$_GET['club_id'] : 0;

if (!$club_id || !is_club_leader($user_id, $club_id)) {
    $_SESSION['error'] = "Bạn không có quyền truy cập!";
    redirect('index.php');
}

$club_info = get_club_info($club_id);

// Xử lý thêm giao dịch
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $transaction_type = escape_string($_POST['transaction_type']);
    $amount = (float)$_POST['amount'];
    $category = escape_string($_POST['category']);
    $description = escape_string($_POST['description']);
    $transaction_date = escape_string($_POST['transaction_date']);
    
    if($amount <= 0) {
        $_SESSION['error'] = "Số tiền phải lớn hơn 0!";
    } else {
        $sql = "INSERT INTO finances (club_id, transaction_type, amount, category, description, transaction_date, created_by) 
                VALUES ($club_id, '$transaction_type', $amount, '$category', '$description', '$transaction_date', $user_id)";
        
        if(execute_query($sql)) {
            $_SESSION['success'] = "Thêm giao dịch thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('finance.php?club_id=' . $club_id);
}

// Xử lý xóa giao dịch
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $finance_id = (int)$_GET['id'];
    
    $sql = "DELETE FROM finances WHERE finance_id = $finance_id AND club_id = $club_id";
    
    if(execute_query($sql)) {
        $_SESSION['success'] = "Xóa giao dịch thành công!";
    } else {
        $_SESSION['error'] = "Không thể xóa giao dịch!";
    }
    redirect('finance.php?club_id=' . $club_id);
}

// Lọc
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$month = isset($_GET['month']) ? escape_string($_GET['month']) : date('Y-m');

$where_conditions = ["club_id = $club_id"];

if ($filter === 'income') {
    $where_conditions[] = "transaction_type = 'income'";
} elseif ($filter === 'expense') {
    $where_conditions[] = "transaction_type = 'expense'";
}

if (!empty($month)) {
    $where_conditions[] = "DATE_FORMAT(transaction_date, '%Y-%m') = '$month'";
}

$where_sql = implode(' AND ', $where_conditions);

// Lấy danh sách giao dịch
$finances_sql = "SELECT f.*, u.full_name as creator_name
                 FROM finances f
                 INNER JOIN users u ON f.created_by = u.user_id
                 WHERE $where_sql
                 ORDER BY f.transaction_date DESC, f.created_at DESC";
$finances = get_result($finances_sql);

// Thống kê
$total_income_sql = "SELECT SUM(amount) as total FROM finances 
                     WHERE club_id = $club_id AND transaction_type = 'income'";
$total_income = get_single_row($total_income_sql)['total'] ?? 0;

$total_expense_sql = "SELECT SUM(amount) as total FROM finances 
                      WHERE club_id = $club_id AND transaction_type = 'expense'";
$total_expense = get_single_row($total_expense_sql)['total'] ?? 0;

$balance = $total_income - $total_expense;

// Thống kê theo tháng hiện tại
$month_income = get_single_row("SELECT SUM(amount) as total FROM finances 
                                WHERE club_id = $club_id 
                                AND transaction_type = 'income' 
                                AND DATE_FORMAT(transaction_date, '%Y-%m') = '$month'")['total'] ?? 0;

$month_expense = get_single_row("SELECT SUM(amount) as total FROM finances 
                                 WHERE club_id = $club_id 
                                 AND transaction_type = 'expense' 
                                 AND DATE_FORMAT(transaction_date, '%Y-%m') = '$month'")['total'] ?? 0;

// Thống kê theo danh mục
$category_stats_sql = "SELECT category, transaction_type, SUM(amount) as total
                       FROM finances
                       WHERE club_id = $club_id AND DATE_FORMAT(transaction_date, '%Y-%m') = '$month'
                       GROUP BY category, transaction_type
                       ORDER BY total DESC";
$category_stats = get_result($category_stats_sql);

require_once '../includes/header.php';
?>

<style>
    .finance-card {
        border-left: 4px solid;
        transition: all 0.3s;
    }
    
    .finance-card.income {
        border-left-color: #28a745;
    }
    
    .finance-card.expense {
        border-left-color: #dc3545;
    }
    
    .finance-card:hover {
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
</style>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-2">
                        <i class="fas fa-dollar-sign me-2"></i> Quản Lý Tài Chính
                    </h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="index.php?club_id=<?php echo $club_id; ?>"><?php echo htmlspecialchars($club_info['club_name']); ?></a></li>
                            <li class="breadcrumb-item active">Tài chính</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addFinanceModal">
                        <i class="fas fa-plus me-2"></i> Thêm Giao Dịch
                    </button>
                    <a href="index.php?club_id=<?php echo $club_id; ?>" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i> Quay Lại
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Thống kê tổng quan -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card border-0 shadow-sm text-white bg-success">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1 opacity-75">Tổng Thu</h6>
                            <h3 class="mb-0 fw-bold"><?php echo format_currency($total_income); ?></h3>
                        </div>
                        <i class="fas fa-arrow-up fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card border-0 shadow-sm text-white bg-danger">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1 opacity-75">Tổng Chi</h6>
                            <h3 class="mb-0 fw-bold"><?php echo format_currency($total_expense); ?></h3>
                        </div>
                        <i class="fas fa-arrow-down fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card border-0 shadow-sm text-white <?php echo $balance >= 0 ? 'bg-info' : 'bg-warning text-dark'; ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1 opacity-75">Số Dư</h6>
                            <h3 class="mb-0 fw-bold"><?php echo format_currency($balance); ?></h3>
                        </div>
                        <i class="fas fa-wallet fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Danh sách giao dịch -->
        <div class="col-lg-8 mb-4">
            <!-- Bộ lọc -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <form method="GET" action="" class="row g-3">
                        <input type="hidden" name="club_id" value="<?php echo $club_id; ?>">
                        
                        <div class="col-md-6">
                            <label class="form-label">Tháng</label>
                            <input type="month" class="form-control" name="month" 
                                   value="<?php echo $month; ?>">
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Loại</label>
                            <select class="form-select" name="filter">
                                <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                                <option value="income" <?php echo $filter === 'income' ? 'selected' : ''; ?>>Thu</option>
                                <option value="expense" <?php echo $filter === 'expense' ? 'selected' : ''; ?>>Chi</option>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-filter me-2"></i> Lọc
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Danh sách -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i> Danh Sách Giao Dịch
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($finances && $finances->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($finance = $finances->fetch_assoc()): ?>
                            <div class="list-group-item finance-card <?php echo $finance['transaction_type']; ?> px-0">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <div class="d-flex align-items-center mb-2">
                                            <?php if($finance['transaction_type'] === 'income'): ?>
                                                <span class="badge bg-success me-2">THU</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger me-2">CHI</span>
                                            <?php endif; ?>
                                            
                                            <?php if($finance['category']): ?>
                                                <span class="badge bg-secondary">
                                                    <?php echo htmlspecialchars($finance['category']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php if($finance['description']): ?>
                                        <p class="mb-2"><?php echo htmlspecialchars($finance['description']); ?></p>
                                        <?php endif; ?>
                                        
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo format_date($finance['transaction_date']); ?>
                                            <i class="fas fa-user ms-2 me-1"></i>
                                            <?php echo htmlspecialchars($finance['creator_name']); ?>
                                        </small>
                                    </div>
                                    
                                    <div class="text-end ms-3">
                                        <h5 class="mb-2 <?php echo $finance['transaction_type'] === 'income' ? 'text-success' : 'text-danger'; ?>">
                                            <?php echo $finance['transaction_type'] === 'income' ? '+' : '-'; ?>
                                            <?php echo format_currency($finance['amount']); ?>
                                        </h5>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                onclick="deleteFinance(<?php echo $finance['finance_id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-receipt fa-5x text-muted mb-3"></i>
                            <h5 class="text-muted">Chưa có giao dịch nào</h5>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Thống kê tháng -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-line me-2"></i> Tháng <?php echo date('m/Y', strtotime($month)); ?>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Thu nhập</span>
                            <strong class="text-success"><?php echo format_currency($month_income); ?></strong>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-success" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Chi tiêu</span>
                            <strong class="text-danger"><?php echo format_currency($month_expense); ?></strong>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-danger" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="text-center p-3 rounded" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <small class="text-white d-block mb-1">Chênh lệch</small>
                        <h4 class="text-white mb-0 fw-bold">
                            <?php echo format_currency($month_income - $month_expense); ?>
                        </h4>
                    </div>
                </div>
            </div>
            
            <!-- Thống kê danh mục -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-pie me-2"></i> Theo Danh Mục
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($category_stats && $category_stats->num_rows > 0): ?>
                        <?php while($stat = $category_stats->fetch_assoc()): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($stat['category']); ?>
                                    <span class="badge <?php echo $stat['transaction_type'] === 'income' ? 'bg-success' : 'bg-danger'; ?> ms-1">
                                        <?php echo $stat['transaction_type'] === 'income' ? 'Thu' : 'Chi'; ?>
                                    </span>
                                </small>
                                <small class="fw-bold"><?php echo format_currency($stat['total']); ?></small>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar <?php echo $stat['transaction_type'] === 'income' ? 'bg-success' : 'bg-danger'; ?>" 
                                     style="width: <?php echo ($stat['total'] / max($month_income, $month_expense)) * 100; ?>%"></div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-center text-muted mb-0">Chưa có dữ liệu</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Thêm Giao Dịch -->
<div class="modal fade" id="addFinanceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-plus-circle me-2"></i> Thêm Giao Dịch
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label class="form-label">Loại Giao Dịch <span class="text-danger">*</span></label>
                        <select class="form-select" name="transaction_type" required>
                            <option value="income">Thu nhập</option>
                            <option value="expense">Chi tiêu</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Số Tiền <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="amount" 
                               min="1" step="1000" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Danh Mục</label>
                        <input type="text" class="form-control" name="category" 
                               placeholder="VD: Tài trợ, Chi phí sự kiện...">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Mô Tả</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Ngày Giao Dịch <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="transaction_date" 
                               value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save me-2"></i> Lưu
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function deleteFinance(financeId) {
    if(confirm('Bạn có chắc muốn xóa giao dịch này?')) {
        window.location.href = 'finance.php?action=delete&id=' + financeId + '&club_id=<?php echo $club_id; ?>';
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>