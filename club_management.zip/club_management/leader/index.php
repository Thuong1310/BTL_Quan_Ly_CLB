<?php
$page_title = "Dashboard - Leader";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('leader');

$user_id = $_SESSION['user_id'];

// Lấy các CLB mà user là leader
$my_clubs_sql = "SELECT c.*, cl.position
                 FROM clubs c
                 INNER JOIN club_leaders cl ON c.club_id = cl.club_id
                 WHERE cl.user_id = $user_id AND cl.status = 'active'";
$my_clubs = get_result($my_clubs_sql);

// Nếu không phải leader của CLB nào
if (!$my_clubs || $my_clubs->num_rows == 0) {
    $_SESSION['error'] = "Bạn không phải là chủ nhiệm của CLB nào!";
    redirect('../student/index.php');
}

// Lấy CLB đầu tiên làm mặc định
$default_club = $my_clubs->fetch_assoc();
mysqli_data_seek($my_clubs, 0);

// Lấy club_id được chọn
$selected_club_id = isset($_GET['club_id']) ? (int)$_GET['club_id'] : $default_club['club_id'];

// Kiểm tra xem user có phải leader của CLB này không
if (!is_club_leader($user_id, $selected_club_id)) {
    $_SESSION['error'] = "Bạn không có quyền truy cập CLB này!";
    redirect('index.php');
}

// Lấy thông tin CLB
$club_info = get_club_info($selected_club_id);

// Thống kê CLB
$total_members_sql = "SELECT COUNT(*) as count FROM club_members 
                      WHERE club_id = $selected_club_id AND status = 'active'";
$total_members = get_single_row($total_members_sql)['count'];

$pending_members_sql = "SELECT COUNT(*) as count FROM club_members 
                        WHERE club_id = $selected_club_id AND status = 'pending'";
$pending_members = get_single_row($pending_members_sql)['count'];

$total_events_sql = "SELECT COUNT(*) as count FROM events WHERE club_id = $selected_club_id";
$total_events = get_single_row($total_events_sql)['count'];

$upcoming_events_sql = "SELECT COUNT(*) as count FROM events 
                        WHERE club_id = $selected_club_id 
                        AND event_date >= CURDATE() 
                        AND status = 'approved'";
$upcoming_events = get_single_row($upcoming_events_sql)['count'];

$pending_events_sql = "SELECT COUNT(*) as count FROM events 
                       WHERE club_id = $selected_club_id AND status = 'pending'";
$pending_events = get_single_row($pending_events_sql)['count'];

// Tài chính
$finance_sql = "SELECT 
                SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) as total_income,
                SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) as total_expense
                FROM finances WHERE club_id = $selected_club_id";
$finance = get_single_row($finance_sql);
$total_income = $finance['total_income'] ?? 0;
$total_expense = $finance['total_expense'] ?? 0;
$balance = $total_income - $total_expense;

// Đơn chờ duyệt
$pending_requests_sql = "SELECT cm.*, u.full_name, u.email
                         FROM club_members cm
                         INNER JOIN users u ON cm.user_id = u.user_id
                         WHERE cm.club_id = $selected_club_id AND cm.status = 'pending'
                         ORDER BY cm.created_at DESC
                         LIMIT 5";
$pending_requests = get_result($pending_requests_sql);

// Sự kiện sắp tới
$upcoming_events_list_sql = "SELECT e.*, 
                             (SELECT COUNT(*) FROM event_registrations WHERE event_id = e.event_id AND status != 'cancelled') as registered_count
                             FROM events e
                             WHERE e.club_id = $selected_club_id 
                             AND e.event_date >= CURDATE()
                             AND e.status = 'approved'
                             ORDER BY e.event_date ASC, e.start_time ASC
                             LIMIT 5";
$upcoming_events_list = get_result($upcoming_events_list_sql);

// Thành viên hoạt động tích cực
$active_members_sql = "SELECT u.full_name, u.avatar, 
                       COUNT(DISTINCT er.event_id) as events_attended
                       FROM users u
                       INNER JOIN club_members cm ON u.user_id = cm.user_id
                       LEFT JOIN event_registrations er ON u.user_id = er.user_id AND er.status = 'attended'
                       LEFT JOIN events e ON er.event_id = e.event_id AND e.club_id = $selected_club_id
                       WHERE cm.club_id = $selected_club_id AND cm.status = 'active'
                       GROUP BY u.user_id
                       ORDER BY events_attended DESC
                       LIMIT 5";
$active_members = get_result($active_members_sql);

require_once '../includes/header.php';
?>

<style>
    .stat-card {
        border-radius: 15px;
        padding: 25px;
        transition: all 0.3s;
        height: 100%;
        border: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .club-selector {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px;
        border-radius: 15px;
        margin-bottom: 30px;
    }
    
    .member-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .quick-action-btn {
        padding: 15px;
        border-radius: 12px;
        transition: all 0.3s;
        border: 2px solid #e0e0e0;
    }
    
    .quick-action-btn:hover {
        border-color: #667eea;
        background: #f8f9fa;
        transform: translateY(-3px);
    }
</style>

<div class="container-fluid my-4">
    <!-- Club Selector -->
    <div class="club-selector">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h3 class="mb-2">
                    <i class="fas fa-users me-2"></i>
                    <?php echo htmlspecialchars($club_info['club_name']); ?>
                </h3>
                <p class="mb-0">
                    <span class="badge bg-white text-dark me-2">
                        <?php echo htmlspecialchars($club_info['category']); ?>
                    </span>
                    <span class="badge bg-white bg-opacity-25">
                        Chủ nhiệm: <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                    </span>
                </p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <?php if($my_clubs->num_rows > 1): ?>
                <select class="form-select bg-white" onchange="window.location.href='?club_id='+this.value">
                    <?php 
                    mysqli_data_seek($my_clubs, 0);
                    while($club = $my_clubs->fetch_assoc()): 
                    ?>
                    <option value="<?php echo $club['club_id']; ?>" 
                            <?php echo $club['club_id'] == $selected_club_id ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($club['club_name']); ?>
                    </option>
                    <?php endwhile; ?>
                </select>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="mb-3">
                        <i class="fas fa-bolt me-2 text-warning"></i> Thao Tác Nhanh
                    </h5>
                    <div class="row g-3">
                        <div class="col-md-3">
                            <a href="members.php?club_id=<?php echo $selected_club_id; ?>" 
                               class="quick-action-btn d-block text-center text-decoration-none">
                                <i class="fas fa-user-plus fa-2x text-primary mb-2"></i>
                                <p class="mb-0 fw-bold">Quản Lý Thành Viên</p>
                                <?php if($pending_members > 0): ?>
                                <span class="badge bg-danger mt-2"><?php echo $pending_members; ?> chờ duyệt</span>
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="events.php?club_id=<?php echo $selected_club_id; ?>" 
                               class="quick-action-btn d-block text-center text-decoration-none">
                                <i class="fas fa-calendar-plus fa-2x text-success mb-2"></i>
                                <p class="mb-0 fw-bold">Tạo Sự Kiện</p>
                                <small class="text-muted">Tổ chức hoạt động mới</small>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="finance.php?club_id=<?php echo $selected_club_id; ?>" 
                               class="quick-action-btn d-block text-center text-decoration-none">
                                <i class="fas fa-dollar-sign fa-2x text-warning mb-2"></i>
                                <p class="mb-0 fw-bold">Quản Lý Tài Chính</p>
                                <small class="text-muted">Thu chi và báo cáo</small>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="reports.php?club_id=<?php echo $selected_club_id; ?>" 
                               class="quick-action-btn d-block text-center text-decoration-none">
                                <i class="fas fa-file-alt fa-2x text-info mb-2"></i>
                                <p class="mb-0 fw-bold">Xuất Báo Cáo</p>
                                <small class="text-muted">Thống kê hoạt động</small>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Thống kê -->
    <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card bg-primary text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Tổng Thành Viên</p>
                        <h2 class="mb-0 fw-bold"><?php echo $total_members; ?></h2>
                        <?php if($pending_members > 0): ?>
                        <small class="opacity-75">
                            <i class="fas fa-clock me-1"></i><?php echo $pending_members; ?> chờ duyệt
                        </small>
                        <?php endif; ?>
                    </div>
                    <i class="fas fa-users fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card bg-success text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Tổng Sự Kiện</p>
                        <h2 class="mb-0 fw-bold"><?php echo $total_events; ?></h2>
                        <small class="opacity-75">
                            <i class="fas fa-calendar-check me-1"></i><?php echo $upcoming_events; ?> sắp tới
                        </small>
                    </div>
                    <i class="fas fa-calendar-alt fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card bg-warning text-dark">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Sự Kiện Chờ Duyệt</p>
                        <h2 class="mb-0 fw-bold"><?php echo $pending_events; ?></h2>
                        <small class="opacity-75">
                            <i class="fas fa-hourglass-half me-1"></i>Cần xử lý
                        </small>
                    </div>
                    <i class="fas fa-clock fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="stat-card <?php echo $balance >= 0 ? 'bg-info' : 'bg-danger'; ?> text-white">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1 opacity-75">Số Dư</p>
                        <h2 class="mb-0 fw-bold"><?php echo number_format($balance); ?></h2>
                        <small class="opacity-75">VNĐ</small>
                    </div>
                    <i class="fas fa-wallet fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Đơn chờ duyệt -->
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-user-clock me-2 text-warning"></i> Đơn Chờ Duyệt
                    </h5>
                    <a href="members.php?club_id=<?php echo $selected_club_id; ?>&filter=pending" 
                       class="btn btn-sm btn-outline-warning">
                        Xem tất cả
                    </a>
                </div>
                <div class="card-body">
                    <?php if($pending_requests && $pending_requests->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($request = $pending_requests->fetch_assoc()): ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($request['full_name']); ?></h6>
                                        <small class="text-muted">
                                            <i class="fas fa-envelope me-1"></i>
                                            <?php echo htmlspecialchars($request['email']); ?>
                                        </small><br>
                                        <small class="text-muted">
                                            <i class="fas fa-clock me-1"></i>
                                            <?php echo format_date($request['created_at'], 'd/m/Y H:i'); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <a href="members.php?action=approve&id=<?php echo $request['member_id']; ?>&club_id=<?php echo $selected_club_id; ?>" 
                                           class="btn btn-sm btn-success me-1"
                                           onclick="return confirm('Duyệt đơn này?')">
                                            <i class="fas fa-check"></i>
                                        </a>
                                        <a href="members.php?action=reject&id=<?php echo $request['member_id']; ?>&club_id=<?php echo $selected_club_id; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Từ chối đơn này?')">
                                            <i class="fas fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                            <p class="text-muted mb-0">Không có đơn chờ duyệt</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Sự kiện sắp tới -->
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-calendar-alt me-2 text-success"></i> Sự Kiện Sắp Tới
                    </h5>
                    <a href="events.php?club_id=<?php echo $selected_club_id; ?>" 
                       class="btn btn-sm btn-outline-success">
                        Xem tất cả
                    </a>
                </div>
                <div class="card-body">
                    <?php if($upcoming_events_list && $upcoming_events_list->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while($event = $upcoming_events_list->fetch_assoc()): ?>
                            <div class="list-group-item px-0 border-start border-4 border-success">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1">
                                            <?php echo htmlspecialchars($event['event_name']); ?>
                                        </h6>
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i>
                                            <?php echo format_date($event['event_date']); ?>
                                            <i class="fas fa-clock ms-2 me-1"></i>
                                            <?php echo date('H:i', strtotime($event['start_time'])); ?>
                                        </small><br>
                                        <small class="text-muted">
                                            <i class="fas fa-map-marker-alt me-1"></i>
                                            <?php echo htmlspecialchars($event['location']); ?>
                                        </small>
                                    </div>
                                    <span class="badge bg-info">
                                        <?php echo $event['registered_count']; ?> người
                                    </span>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                            <p class="text-muted mb-3">Chưa có sự kiện sắp tới</p>
                            <a href="events.php?club_id=<?php echo $selected_club_id; ?>" 
                               class="btn btn-sm btn-success">
                                <i class="fas fa-plus me-2"></i> Tạo Sự Kiện
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Thành viên tích cực & Tài chính -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-star me-2 text-warning"></i> Thành Viên Tích Cực
                    </h5>
                </div>
                <div class="card-body">
                    <?php if($active_members && $active_members->num_rows > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php 
                            $rank = 1;
                            while($member = $active_members->fetch_assoc()): 
                            ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex align-items-center">
                                    <div class="me-3">
                                        <span class="badge bg-primary rounded-circle" style="width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">
                                            <?php echo $rank++; ?>
                                        </span>
                                    </div>
                                    <img src="../assets/images/<?php echo $member['avatar']; ?>" 
                                         class="member-avatar me-3"
                                         onerror="this.src='../assets/images/default-avatar.png'">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-0"><?php echo htmlspecialchars($member['full_name']); ?></h6>
                                        <small class="text-muted">
                                            <i class="fas fa-calendar-check me-1"></i>
                                            <?php echo $member['events_attended']; ?> sự kiện
                                        </small>
                                    </div>
                                    <?php if($rank <= 2): ?>
                                        <i class="fas fa-trophy text-warning fa-2x"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-center text-muted mb-0">Chưa có dữ liệu</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-pie me-2 text-info"></i> Tổng Quan Tài Chính
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Thu Nhập</span>
                            <strong class="text-success h5 mb-0"><?php echo format_currency($total_income); ?></strong>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-success" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted">Chi Tiêu</span>
                            <strong class="text-danger h5 mb-0"><?php echo format_currency($total_expense); ?></strong>
                        </div>
                        <div class="progress" style="height: 10px;">
                            <div class="progress-bar bg-danger" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="text-center p-3 rounded" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <small class="text-white d-block mb-1">Số Dư Hiện Tại</small>
                        <h3 class="text-white mb-0 fw-bold"><?php echo format_currency($balance); ?></h3>
                    </div>
                    
                    <div class="text-center mt-3">
                        <a href="finance.php?club_id=<?php echo $selected_club_id; ?>" 
                           class="btn btn-outline-primary">
                            <i class="fas fa-chart-line me-2"></i> Xem Chi Tiết
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>