<?php
$page_title = "Quản Lý Thành Viên - Leader";
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('leader');

$user_id = $_SESSION['user_id'];
$club_id = isset($_GET['club_id']) ? (int)$_GET['club_id'] : 0;

// Kiểm tra quyền
if (!$club_id || !is_club_leader($user_id, $club_id)) {
    $_SESSION['error'] = "Bạn không có quyền truy cập!";
    redirect('index.php');
}

$club_info = get_club_info($club_id);

// Xử lý duyệt thành viên
if (isset($_GET['action']) && $_GET['action'] === 'approve' && isset($_GET['id'])) {
    $member_id = (int)$_GET['id'];
    
    $sql = "UPDATE club_members SET 
            status = 'active',
            approved_by = $user_id,
            approved_at = NOW()
            WHERE member_id = $member_id AND club_id = $club_id";
    
    if (execute_query($sql)) {
        $_SESSION['success'] = "Đã duyệt thành viên!";
        
        // Tạo thông báo
        $member_info = get_single_row("SELECT user_id FROM club_members WHERE member_id = $member_id");
        create_notification(
            $member_info['user_id'],
            'Đơn đăng ký được chấp nhận',
            'Đơn đăng ký tham gia CLB "' . $club_info['club_name'] . '" của bạn đã được chấp nhận!',
            'success',
            'student/club-detail.php?id=' . $club_id
        );
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('members.php?club_id=' . $club_id);
}

// Xử lý từ chối thành viên
if (isset($_GET['action']) && $_GET['action'] === 'reject' && isset($_GET['id'])) {
    $member_id = (int)$_GET['id'];
    
    $sql = "UPDATE club_members SET status = 'rejected' 
            WHERE member_id = $member_id AND club_id = $club_id";
    
    if (execute_query($sql)) {
        $_SESSION['success'] = "Đã từ chối đơn!";
        
        // Tạo thông báo
        $member_info = get_single_row("SELECT user_id FROM club_members WHERE member_id = $member_id");
        create_notification(
            $member_info['user_id'],
            'Đơn đăng ký bị từ chối',
            'Đơn đăng ký tham gia CLB "' . $club_info['club_name'] . '" của bạn đã bị từ chối.',
            'error'
        );
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('members.php?club_id=' . $club_id);
}

// Xử lý xóa thành viên
if (isset($_GET['action']) && $_GET['action'] === 'remove' && isset($_GET['id'])) {
    $member_id = (int)$_GET['id'];
    
    $sql = "UPDATE club_members SET status = 'left' 
            WHERE member_id = $member_id AND club_id = $club_id";
    
    if (execute_query($sql)) {
        $_SESSION['success'] = "Đã xóa thành viên khỏi CLB!";
        
        // Tạo thông báo
        $member_info = get_single_row("SELECT user_id FROM club_members WHERE member_id = $member_id");
        create_notification(
            $member_info['user_id'],
            'Đã bị xóa khỏi CLB',
            'Bạn đã bị xóa khỏi CLB "' . $club_info['club_name'] . '"',
            'warning'
        );
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('members.php?club_id=' . $club_id);
}

// Lọc và tìm kiếm
$search = isset($_GET['search']) ? escape_string($_GET['search']) : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'active';

$where_conditions = ["cm.club_id = $club_id"];

if (!empty($search)) {
    $where_conditions[] = "(u.full_name LIKE '%$search%' OR u.email LIKE '%$search%' OR u.username LIKE '%$search%')";
}

if ($filter === 'active') {
    $where_conditions[] = "cm.status = 'active'";
} elseif ($filter === 'pending') {
    $where_conditions[] = "cm.status = 'pending'";
} elseif ($filter === 'all') {
    $where_conditions[] = "cm.status IN ('active', 'pending')";
}

$where_sql = implode(' AND ', $where_conditions);

// Pagination
$per_page = 20;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $per_page;

// Đếm tổng số thành viên
$count_sql = "SELECT COUNT(*) as total 
              FROM club_members cm
              INNER JOIN users u ON cm.user_id = u.user_id
              WHERE $where_sql";
$total_members = get_single_row($count_sql)['total'];
$total_pages = ceil($total_members / $per_page);

// Lấy danh sách thành viên
$members_sql = "SELECT cm.*, u.full_name, u.email, u.avatar, u.phone,
                (SELECT COUNT(*) FROM event_registrations er 
                 INNER JOIN events e ON er.event_id = e.event_id
                 WHERE er.user_id = u.user_id AND e.club_id = $club_id AND er.status = 'attended') as events_attended
                FROM club_members cm
                INNER JOIN users u ON cm.user_id = u.user_id
                WHERE $where_sql
                ORDER BY 
                    CASE WHEN cm.status = 'pending' THEN 0 ELSE 1 END,
                    cm.created_at DESC
                LIMIT $per_page OFFSET $offset";
$members = get_result($members_sql);

// Thống kê
$total_active = get_single_row("SELECT COUNT(*) as count FROM club_members WHERE club_id = $club_id AND status = 'active'")['count'];
$total_pending = get_single_row("SELECT COUNT(*) as count FROM club_members WHERE club_id = $club_id AND status = 'pending'")['count'];

require_once '../includes/header.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-2">
                        <i class="fas fa-users me-2"></i> Quản Lý Thành Viên
                    </h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="index.php?club_id=<?php echo $club_id; ?>"><?php echo htmlspecialchars($club_info['club_name']); ?></a></li>
                            <li class="breadcrumb-item active">Thành viên</li>
                        </ol>
                    </nav>
                </div>
                <a href="index.php?club_id=<?php echo $club_id; ?>" class="btn btn-outline-primary">
                    <i class="fas fa-arrow-left me-2"></i> Quay Lại
                </a>
            </div>
        </div>
    </div>
    
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <!-- Thống kê -->
    <div class="row mb-4">
        <div class="col-md-6 mb-3">
            <div class="card border-0 shadow-sm" style="border-left: 4px solid #28a745 !important;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Thành Viên Hoạt Động</h6>
                            <h2 class="mb-0 fw-bold text-success"><?php echo $total_active; ?></h2>
                        </div>
                        <i class="fas fa-user-check fa-3x text-success opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-3">
            <div class="card border-0 shadow-sm" style="border-left: 4px solid #ffc107 !important;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-1">Đơn Chờ Duyệt</h6>
                            <h2 class="mb-0 fw-bold text-warning"><?php echo $total_pending; ?></h2>
                        </div>
                        <i class="fas fa-clock fa-3x text-warning opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tìm kiếm và lọc -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <input type="hidden" name="club_id" value="<?php echo $club_id; ?>">
                
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" class="form-control" name="search" 
                               placeholder="Tìm kiếm theo tên, email..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                
                <div class="col-md-4">
                    <select class="form-select" name="filter">
                        <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>Tất cả</option>
                        <option value="active" <?php echo $filter === 'active' ? 'selected' : ''; ?>>Hoạt động</option>
                        <option value="pending" <?php echo $filter === 'pending' ? 'selected' : ''; ?>>Chờ duyệt</option>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i> Lọc
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Danh sách thành viên -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <?php if ($members && $members->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Thành Viên</th>
                                <th>Liên Hệ</th>
                                <th>Ngày Tham Gia</th>
                                <th>Sự Kiện Tham Dự</th>
                                <th>Trạng Thái</th>
                                <th class="text-center">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($member = $members->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="../assets/images/<?php echo $member['avatar']; ?>" 
                                             class="rounded-circle me-3"
                                             style="width: 50px; height: 50px; object-fit: cover;"
                                             onerror="this.src='../assets/images/default-avatar.png'">
                                        <div>
                                            <h6 class="mb-0"><?php echo htmlspecialchars($member['full_name']); ?></h6>
                                            <small class="text-muted">@<?php echo htmlspecialchars($member['email']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <small>
                                        <i class="fas fa-envelope me-1"></i>
                                        <?php echo htmlspecialchars($member['email']); ?><br>
                                        <?php if($member['phone']): ?>
                                        <i class="fas fa-phone me-1"></i>
                                        <?php echo htmlspecialchars($member['phone']); ?>
                                        <?php endif; ?>
                                    </small>
                                </td>
                                <td>
                                    <small><?php echo format_date($member['join_date'], 'd/m/Y'); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-info">
                                        <i class="fas fa-calendar-check me-1"></i>
                                        <?php echo $member['events_attended']; ?> sự kiện
                                    </span>
                                </td>
                                <td>
                                    <?php if($member['status'] === 'active'): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check-circle me-1"></i> Hoạt động
                                        </span>
                                    <?php elseif($member['status'] === 'pending'): ?>
                                        <span class="badge bg-warning">
                                            <i class="fas fa-clock me-1"></i> Chờ duyệt
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($member['status'] === 'pending'): ?>
                                        <div class="btn-group btn-group-sm">
                                            <a href="?action=approve&id=<?php echo $member['member_id']; ?>&club_id=<?php echo $club_id; ?>" 
                                               class="btn btn-success"
                                               onclick="return confirm('Duyệt thành viên này?')">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <a href="?action=reject&id=<?php echo $member['member_id']; ?>&club_id=<?php echo $club_id; ?>" 
                                               class="btn btn-danger"
                                               onclick="return confirm('Từ chối đơn này?')">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <a href="?action=remove&id=<?php echo $member['member_id']; ?>&club_id=<?php echo $club_id; ?>" 
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Xóa thành viên này khỏi CLB?')">
                                            <i class="fas fa-user-minus me-1"></i> Xóa
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if ($current_page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $current_page - 1; ?>&club_id=<?php echo $club_id; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo $filter; ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if ($i == 1 || $i == $total_pages || ($i >= $current_page - 2 && $i <= $current_page + 2)): ?>
                            <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&club_id=<?php echo $club_id; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo $filter; ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                            <?php elseif ($i == $current_page - 3 || $i == $current_page + 3): ?>
                            <li class="page-item disabled">
                                <span class="page-link">...</span>
                            </li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($current_page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $current_page + 1; ?>&club_id=<?php echo $club_id; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo $filter; ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-users-slash fa-5x text-muted mb-4"></i>
                    <h4 class="text-muted">Không tìm thấy thành viên</h4>
                    <p class="text-muted">
                        <?php if(!empty($search)): ?>
                            Không có kết quả cho từ khóa "<?php echo htmlspecialchars($search); ?>"
                        <?php else: ?>
                            CLB chưa có thành viên nào
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>