<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

require_login();

if (isset($_GET['id'])) {
    $notification_id = (int)$_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    // Kiểm tra thông báo có thuộc về user không
    $check_sql = "SELECT * FROM notifications WHERE notification_id = $notification_id AND user_id = $user_id";
    $notification = get_single_row($check_sql);
    
    if ($notification) {
        // Đánh dấu đã đọc
        $update_sql = "UPDATE notifications SET is_read = 1 WHERE notification_id = $notification_id";
        execute_query($update_sql);
        
        // Redirect đến link của thông báo nếu có
        if (!empty($notification['link'])) {
            redirect($notification['link']);
        }
    }
}

// Redirect về trang trước đó hoặc trang chủ
$redirect = $_GET['redirect'] ?? 'index.php';
redirect($redirect);
?>