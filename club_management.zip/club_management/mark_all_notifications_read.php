<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

require_login();

$user_id = $_SESSION['user_id'];

// Đánh dấu tất cả thông báo đã đọc
$sql = "UPDATE notifications SET is_read = 1 WHERE user_id = $user_id AND is_read = 0";

if (execute_query($sql)) {
    $_SESSION['success'] = "Đã đánh dấu tất cả thông báo là đã đọc!";
} else {
    $_SESSION['error'] = "Có lỗi xảy ra!";
}

// Redirect về trang trước đó
$redirect = $_GET['redirect'] ?? 'index.php';
redirect($redirect);
?>