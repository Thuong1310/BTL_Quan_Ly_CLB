<?php
// Kiểm tra đã require database và functions chưa
if (!isset($conn)) {
    require_once __DIR__ . '/../config/database.php';
}
if (!function_exists('is_logged_in')) {
    require_once __DIR__ . '/../functions.php';
}

// Lấy thông tin user nếu đã đăng nhập
$current_user = null;
$unread_notifications = 0;
$notifications = [];

if (is_logged_in()) {
    $user_id = $_SESSION['user_id'];
    
    // Lấy thông tin user
    $user_sql = "SELECT * FROM users WHERE user_id = $user_id";
    $current_user = get_single_row($user_sql);
    
    // Đếm thông báo chưa đọc
    $notif_count_sql = "SELECT COUNT(*) as count FROM notifications 
                        WHERE user_id = $user_id AND is_read = 0";
    $unread_notifications = get_single_row($notif_count_sql)['count'];
    
    // Lấy 5 thông báo mới nhất
    $notif_sql = "SELECT * FROM notifications 
                  WHERE user_id = $user_id 
                  ORDER BY created_at DESC 
                  LIMIT 5";
    $notifications = get_result($notif_sql);
}

// Xác định đường dẫn gốc
$base_path = '';
if (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) {
    $base_path = '../';
} elseif (strpos($_SERVER['PHP_SELF'], '/leader/') !== false) {
    $base_path = '../';
} elseif (strpos($_SERVER['PHP_SELF'], '/student/') !== false) {
    $base_path = '../';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Hệ Thống Quản Lý CLB'; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand:hover {
            color: #fff !important;
            transform: scale(1.05);
            transition: all 0.3s;
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 8px;
            transition: all 0.3s;
            margin: 0 5px;
        }
        
        .nav-link:hover {
            background: rgba(255,255,255,0.2);
            color: white !important;
        }
        
        .nav-link.active {
            background: rgba(255,255,255,0.3);
            color: white !important;
        }
        
        .notification-badge {
            position: absolute;
            top: 5px;
            right: 5px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.7rem;
            font-weight: bold;
        }
        
        .notification-item {
            border-bottom: 1px solid #eee;
            padding: 12px;
            transition: background 0.3s;
        }
        
        .notification-item:hover {
            background: #f8f9fa;
        }
        
        .notification-item.unread {
            background: #e3f2fd;
        }
        
        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            border: none;
            min-width: 320px;
        }
        
        .dropdown-item {
            padding: 10px 20px;
            transition: all 0.3s;
        }
        
        .dropdown-item:hover {
            background: #f8f9fa;
            padding-left: 25px;
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
        }
        
        .btn-notification {
            position: relative;
            background: transparent;
            border: none;
            color: white;
            font-size: 1.2rem;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .btn-notification:hover {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        .navbar-toggler {
            border-color: rgba(255,255,255,0.3);
        }
        
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(255, 255, 255, 0.9)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        
        .notification-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 15px;
            font-weight: 600;
            border-radius: 10px 10px 0 0;
        }
        
        .notification-footer {
            text-align: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 0 0 10px 10px;
        }
        
        @media (max-width: 768px) {
            .navbar-brand {
                font-size: 1.2rem;
            }
            
            .nav-link {
                margin: 5px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo $base_path; ?>index.php">
                <i class="fas fa-users-cog"></i>
                <span>Quản Lý CLB</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <?php if (is_logged_in()): ?>
                    <!-- Navigation theo role -->
                    <ul class="navbar-nav me-auto">
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>admin/index.php">
                                    <i class="fas fa-home me-1"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'clubs.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>admin/clubs.php">
                                    <i class="fas fa-users me-1"></i> CLB
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'leaders.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>admin/leaders.php">
                                    <i class="fas fa-user-tie me-1"></i> Chủ Nhiệm
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>admin/users.php">
                                    <i class="fas fa-user-friends me-1"></i> Người Dùng
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'approvals.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>admin/approvals.php">
                                    <i class="fas fa-check-circle me-1"></i> Phê Duyệt
                                    <?php 
                                    $pending_count_sql = "SELECT 
                                        (SELECT COUNT(*) FROM events WHERE status = 'pending') +
                                        (SELECT COUNT(*) FROM club_members WHERE status = 'pending') +
                                        (SELECT COUNT(*) FROM activity_plans WHERE status = 'pending') as total";
                                    $pending_count = get_single_row($pending_count_sql)['total'];
                                    if($pending_count > 0): 
                                    ?>
                                        <span class="badge bg-danger"><?php echo $pending_count; ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>admin/reports.php">
                                    <i class="fas fa-chart-bar me-1"></i> Báo Cáo
                                </a>
                            </li>
                            
                        <?php elseif ($_SESSION['role'] === 'leader'): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>leader/index.php">
                                    <i class="fas fa-home me-1"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'members.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>leader/members.php">
                                    <i class="fas fa-users me-1"></i> Thành Viên
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'events.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>leader/events.php">
                                    <i class="fas fa-calendar me-1"></i> Sự Kiện
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'finance.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>leader/finance.php">
                                    <i class="fas fa-dollar-sign me-1"></i> Tài Chính
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>leader/reports.php">
                                    <i class="fas fa-file-alt me-1"></i> Báo Cáo
                                </a>
                            </li>
                            
                        <?php else: // student ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>student/index.php">
                                    <i class="fas fa-home me-1"></i> Trang Chủ
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'clubs.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>student/clubs.php">
                                    <i class="fas fa-users me-1"></i> Câu Lạc Bộ
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'events.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>student/events.php">
                                    <i class="fas fa-calendar me-1"></i> Sự Kiện
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'my-clubs.php' ? 'active' : ''; ?>" 
                                   href="<?php echo $base_path; ?>student/my-clubs.php">
                                    <i class="fas fa-heart me-1"></i> CLB Của Tôi
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                    <!-- Notification & Profile -->
                    <ul class="navbar-nav ms-auto align-items-center">
                        <!-- Thông báo -->
                        <li class="nav-item dropdown">
                            <button class="btn-notification dropdown-toggle" data-bs-toggle="dropdown">
                                <i class="fas fa-bell"></i>
                                <?php if ($unread_notifications > 0): ?>
                                    <span class="notification-badge"><?php echo $unread_notifications; ?></span>
                                <?php endif; ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end p-0">
                                <div class="notification-header">
                                    <i class="fas fa-bell me-2"></i> Thông Báo
                                    <?php if ($unread_notifications > 0): ?>
                                        <span class="badge bg-light text-dark float-end">
                                            <?php echo $unread_notifications; ?> mới
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div style="max-height: 400px; overflow-y: auto;">
                                    <?php if ($notifications && $notifications->num_rows > 0): ?>
                                        <?php while($notif = $notifications->fetch_assoc()): ?>
                                            <div class="notification-item <?php echo $notif['is_read'] ? '' : 'unread'; ?>">
                                                <a href="<?php echo $base_path; ?>mark_notification_read.php?id=<?php echo $notif['notification_id']; ?>&redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" 
                                                   class="text-decoration-none text-dark">
                                                    <div class="d-flex align-items-start">
                                                        <div class="flex-grow-1">
                                                            <h6 class="mb-1">
                                                                <?php 
                                                                $icons = [
                                                                    'success' => 'fa-check-circle text-success',
                                                                    'error' => 'fa-times-circle text-danger',
                                                                    'info' => 'fa-info-circle text-info',
                                                                    'warning' => 'fa-exclamation-triangle text-warning'
                                                                ];
                                                                $icon = $icons[$notif['type']] ?? 'fa-bell text-primary';
                                                                ?>
                                                                <i class="fas <?php echo $icon; ?> me-2"></i>
                                                                <?php echo htmlspecialchars($notif['title']); ?>
                                                            </h6>
                                                            <p class="mb-1 small text-muted">
                                                                <?php echo htmlspecialchars(substr($notif['message'], 0, 80)); ?>
                                                                <?php echo strlen($notif['message']) > 80 ? '...' : ''; ?>
                                                            </p>
                                                            <small class="text-muted">
                                                                <i class="fas fa-clock me-1"></i>
                                                                <?php 
                                                                $time_diff = time() - strtotime($notif['created_at']);
                                                                if ($time_diff < 60) {
                                                                    echo 'Vừa xong';
                                                                } elseif ($time_diff < 3600) {
                                                                    echo floor($time_diff / 60) . ' phút trước';
                                                                } elseif ($time_diff < 86400) {
                                                                    echo floor($time_diff / 3600) . ' giờ trước';
                                                                } else {
                                                                    echo floor($time_diff / 86400) . ' ngày trước';
                                                                }
                                                                ?>
                                                            </small>
                                                        </div>
                                                        <?php if (!$notif['is_read']): ?>
                                                            <div class="ms-2">
                                                                <span class="badge bg-primary rounded-pill">Mới</span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <div class="text-center py-4 text-muted">
                                            <i class="fas fa-bell-slash fa-3x mb-3"></i>
                                            <p>Không có thông báo nào</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($notifications && $notifications->num_rows > 0): ?>
                                <div class="notification-footer">
                                    <a href="<?php echo $base_path; ?>notifications.php" class="text-decoration-none">
                                        Xem tất cả <i class="fas fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                                <?php endif; ?>
                            </ul>
                        </li>
                        
                        <!-- User Profile -->
                        <li class="nav-item dropdown ms-2">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="dropdown">
                                <img src="<?php echo $base_path; ?>assets/images/<?php echo $current_user['avatar'] ?? 'default-avatar.png'; ?>" 
                                     class="user-avatar me-2"
                                     onerror="this.src='<?php echo $base_path; ?>assets/images/default-avatar.png'">
                                <span class="d-none d-md-inline">
                                    <?php echo htmlspecialchars($current_user['full_name']); ?>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <div class="dropdown-header">
                                        <strong><?php echo htmlspecialchars($current_user['full_name']); ?></strong><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($current_user['email']); ?></small>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="<?php echo $base_path; ?>profile.php">
                                        <i class="fas fa-user-circle me-2"></i> Hồ Sơ
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?php echo $base_path; ?>settings.php">
                                        <i class="fas fa-cog me-2"></i> Cài Đặt
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="<?php echo $base_path; ?>logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    
                <?php else: ?>
                    <!-- Guest Navigation -->
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $base_path; ?>login.php">
                                <i class="fas fa-sign-in-alt me-1"></i> Đăng Nhập
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-light text-dark px-3" href="<?php echo $base_path; ?>register.php">
                                <i class="fas fa-user-plus me-1"></i> Đăng Ký
                            </a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <!-- Main Content Container -->
    <div class="main-content"><?php // Content sẽ được load ở đây ?>