<?php
// Bắt đầu session nếu chưa có
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Hàm kiểm tra đăng nhập
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Hàm kiểm tra role
function check_role($required_role) {
    if (!is_logged_in()) {
        return false;
    }
    
    if (is_array($required_role)) {
        return in_array($_SESSION['role'], $required_role);
    }
    
    return $_SESSION['role'] === $required_role;
}

// Hàm redirect
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// Hàm kiểm tra quyền truy cập
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['error'] = "Vui lòng đăng nhập để tiếp tục!";
        redirect('../login.php');
    }
}

// Hàm kiểm tra role và redirect nếu không đủ quyền
function require_role($required_role) {
    require_login();
    
    if (!check_role($required_role)) {
        $_SESSION['error'] = "Bạn không có quyền truy cập trang này!";
        redirect('../index.php');
    }
}

// Hàm hash mật khẩu
function hash_password($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Hàm verify mật khẩu
function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

// Hàm hiển thị thông báo
function show_message($type = 'info') {
    $messages = [
        'success' => $_SESSION['success'] ?? '',
        'error' => $_SESSION['error'] ?? '',
        'info' => $_SESSION['info'] ?? '',
        'warning' => $_SESSION['warning'] ?? ''
    ];
    
    if (!empty($messages[$type])) {
        $alert_class = [
            'success' => 'alert-success',
            'error' => 'alert-danger',
            'info' => 'alert-info',
            'warning' => 'alert-warning'
        ];
        
        echo '<div class="alert ' . $alert_class[$type] . ' alert-dismissible fade show" role="alert">';
        echo htmlspecialchars($messages[$type]);
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
        echo '</div>';
        
        unset($_SESSION[$type]);
    }
}

// Hàm format ngày tháng
function format_date($date, $format = 'd/m/Y') {
    return date($format, strtotime($date));
}

// Hàm format tiền tệ
function format_currency($amount) {
    return number_format($amount, 0, ',', '.') . ' VNĐ';
}

// Hàm sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Hàm validate email
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Hàm upload file
function upload_file($file, $upload_dir = '../assets/images/', $allowed_types = ['jpg', 'jpeg', 'png', 'gif']) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_types)) {
        return false;
    }
    
    $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
    $upload_path = $upload_dir . $new_filename;
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        return $new_filename;
    }
    
    return false;
}

// Hàm tạo mã QR code đơn giản
function generate_qr_code($data) {
    return 'qr_' . md5($data . time()) . '.png';
}

// Hàm lấy thông tin user
function get_user_info($user_id) {
    global $conn;
    $user_id = (int)$user_id;
    $sql = "SELECT * FROM users WHERE user_id = $user_id";
    return get_single_row($sql);
}

// Hàm lấy thông tin club
function get_club_info($club_id) {
    global $conn;
    $club_id = (int)$club_id;
    $sql = "SELECT * FROM clubs WHERE club_id = $club_id";
    return get_single_row($sql);
}

// Hàm kiểm tra leader của club
function is_club_leader($user_id, $club_id) {
    global $conn;
    $user_id = (int)$user_id;
    $club_id = (int)$club_id;
    
    $sql = "SELECT * FROM club_leaders 
            WHERE user_id = $user_id AND club_id = $club_id AND status = 'active'";
    $result = get_single_row($sql);
    
    return $result !== false;
}

// Hàm kiểm tra thành viên của club
function is_club_member($user_id, $club_id) {
    global $conn;
    $user_id = (int)$user_id;
    $club_id = (int)$club_id;
    
    $sql = "SELECT * FROM club_members 
            WHERE user_id = $user_id AND club_id = $club_id AND status = 'active'";
    $result = get_single_row($sql);
    
    return $result !== false;
}

// Hàm đếm thông báo chưa đọc
function count_unread_notifications($user_id) {
    global $conn;
    $user_id = (int)$user_id;
    
    $sql = "SELECT COUNT(*) as count FROM notifications 
            WHERE user_id = $user_id AND is_read = 0";
    $result = get_single_row($sql);
    
    return $result ? $result['count'] : 0;
}

// Hàm tạo thông báo
function create_notification($user_id, $title, $message, $type = 'info', $link = '') {
    global $conn;
    $user_id = (int)$user_id;
    $title = escape_string($title);
    $message = escape_string($message);
    $type = escape_string($type);
    $link = escape_string($link);
    
    $sql = "INSERT INTO notifications (user_id, title, message, type, link) 
            VALUES ($user_id, '$title', '$message', '$type', '$link')";
    
    return execute_query($sql);
}

// Hàm lấy danh sách clubs của user
function get_user_clubs($user_id) {
    global $conn;
    $user_id = (int)$user_id;
    
    $sql = "SELECT c.*, cm.join_date, cm.status as member_status 
            FROM clubs c 
            INNER JOIN club_members cm ON c.club_id = cm.club_id 
            WHERE cm.user_id = $user_id AND cm.status = 'active'";
    
    return get_result($sql);
}

// Hàm pagination
function paginate($total_records, $per_page = 10, $current_page = 1) {
    $total_pages = ceil($total_records / $per_page);
    $offset = ($current_page - 1) * $per_page;
    
    return [
        'total_pages' => $total_pages,
        'current_page' => $current_page,
        'offset' => $offset,
        'per_page' => $per_page
    ];
}
?>