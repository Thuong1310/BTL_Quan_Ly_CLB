</div> <!-- End main-content -->
    
    <!-- Footer -->
    <footer class="bg-dark text-white mt-5">
        <div class="container py-4">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3">
                        <i class="fas fa-users-cog me-2"></i>
                        Hệ Thống Quản Lý CLB
                    </h5>
                    <p class="text-muted">
                        Nền tảng quản lý câu lạc bộ toàn diện, giúp kết nối sinh viên và tổ chức các hoạt động hiệu quả.
                    </p>
                    <div class="social-links">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3">Liên Kết Nhanh</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="<?php echo $base_path ?? ''; ?>about.php" class="text-muted text-decoration-none">
                                <i class="fas fa-chevron-right me-2"></i> Giới Thiệu
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo $base_path ?? ''; ?>contact.php" class="text-muted text-decoration-none">
                                <i class="fas fa-chevron-right me-2"></i> Liên Hệ
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo $base_path ?? ''; ?>help.php" class="text-muted text-decoration-none">
                                <i class="fas fa-chevron-right me-2"></i> Trợ Giúp
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo $base_path ?? ''; ?>privacy.php" class="text-muted text-decoration-none">
                                <i class="fas fa-chevron-right me-2"></i> Chính Sách
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3">Liên Hệ</h5>
                    <ul class="list-unstyled text-muted">
                        <li class="mb-2">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            Địa chỉ: 123 Đường ABC, Quận XYZ
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-phone me-2"></i>
                            Điện thoại: (024) 1234-5678
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-envelope me-2"></i>
                            Email: contact@clubmanagement.vn
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-clock me-2"></i>
                            Giờ làm việc: 8:00 - 17:00 (T2-T6)
                        </li>
                    </ul>
                </div>
            </div>
            
            <hr class="bg-secondary">
            
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0 text-muted">
                        © <?php echo date('Y'); ?> Hệ Thống Quản Lý CLB. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0 text-muted">
                        Phát triển bởi <strong>Nhóm Sinh Viên CNTT</strong>
                    </p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Auto hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 5000);
            });
        });
        
        // Confirm before delete
        function confirmDelete(message) {
            return confirm(message || 'Bạn có chắc chắn muốn xóa?');
        }
        
        // Mark all notifications as read
        function markAllNotificationsRead() {
            if(confirm('Đánh dấu tất cả thông báo đã đọc?')) {
                window.location.href = '<?php echo $base_path ?? ''; ?>mark_all_notifications_read.php?redirect=' + 
                    encodeURIComponent(window.location.href);
            }
        }
    </script>
    
    <?php if (isset($extra_js)): ?>
        <?php echo $extra_js; ?>
    <?php endif; ?>
</body>
</html>