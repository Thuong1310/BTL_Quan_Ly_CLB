<?php
$page_title = "Hồ Sơ Cá Nhân";
require_once 'config/database.php';
require_once 'includes/functions.php';

require_login();

$user_id = $_SESSION['user_id'];

// Xử lý cập nhật thông tin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_info') {
    $full_name = escape_string($_POST['full_name']);
    $email = escape_string($_POST['email']);
    $phone = escape_string($_POST['phone']);
    
    $errors = [];
    
    if (empty($full_name)) {
        $errors[] = "Họ tên không được để trống!";
    }
    
    if (!validate_email($email)) {
        $errors[] = "Email không hợp lệ!";
    }
    
    // Kiểm tra email đã tồn tại chưa (trừ email của mình)
    $check_email = "SELECT user_id FROM users WHERE email = '$email' AND user_id != $user_id";
    if (get_single_row($check_email)) {
        $errors[] = "Email đã được sử dụng!";
    }
    
    if (empty($errors)) {
        $update_sql = "UPDATE users SET 
                       full_name = '$full_name',
                       email = '$email',
                       phone = '$phone'
                       WHERE user_id = $user_id";
        
        if (execute_query($update_sql)) {
            $_SESSION['full_name'] = $full_name;
            $_SESSION['success'] = "Cập nhật thông tin thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    } else {
        $_SESSION['error'] = implode('<br>', $errors);
    }
    redirect('profile.php');
}

// Xử lý đổi mật khẩu
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $errors = [];
    
    // Lấy mật khẩu hiện tại
    $user = get_single_row("SELECT password FROM users WHERE user_id = $user_id");
    
    if (!verify_password($current_password, $user['password'])) {
        $errors[] = "Mật khẩu hiện tại không đúng!";
    }
    
    if (strlen($new_password) < 6) {
        $errors[] = "Mật khẩu mới phải có ít nhất 6 ký tự!";
    }
    
    if ($new_password !== $confirm_password) {
        $errors[] = "Mật khẩu xác nhận không khớp!";
    }
    
    if (empty($errors)) {
        $hashed_password = hash_password($new_password);
        $update_sql = "UPDATE users SET password = '$hashed_password' WHERE user_id = $user_id";
        
        if (execute_query($update_sql)) {
            $_SESSION['success'] = "Đổi mật khẩu thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    } else {
        $_SESSION['error'] = implode('<br>', $errors);
    }
    redirect('profile.php');
}

// Lấy thông tin user
$user = get_user_info($user_id);

// Lấy thống kê
if ($_SESSION['role'] === 'student') {
    $clubs_count = get_single_row("SELECT COUNT(*) as count FROM club_members WHERE user_id = $user_id AND status = 'active'")['count'];
    $events_count = get_single_row("SELECT COUNT(*) as count FROM event_registrations WHERE user_id = $user_id")['count'];
    $attended_count = get_single_row("SELECT COUNT(*) as count FROM event_registrations WHERE user_id = $user_id AND status = 'attended'")['count'];
}

require_once 'includes/header.php';
?>

<style>
    .profile-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 40px 0;
    }
    
    .profile-avatar {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        border: 5px solid white;
        object-fit: cover;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    .stat-box {
        background: white;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
</style>

<div class="profile-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <img src="assets/images/<?php echo $user['avatar']; ?>" 
                     class="profile-avatar"
                     onerror="this.src='assets/images/default-avatar.png'">
            </div>
            <div class="col-md-9">
                <h1 class="display-5 fw-bold mb-2"><?php echo htmlspecialchars($user['full_name']); ?></h1>
                <p class="lead mb-3">
                    <i class="fas fa-envelope me-2"></i>
                    <?php echo htmlspecialchars($user['email']); ?>
                </p>
                <p class="mb-0">
                    <span class="badge bg-white text-dark me-2">
                        <i class="fas fa-user-tag me-1"></i>
                        <?php 
                        $roles = ['admin' => 'Admin', 'leader' => 'Chủ Nhiệm', 'student' => 'Sinh Viên'];
                        echo $roles[$user['role']];
                        ?>
                    </span>
                    <span class="badge bg-success">
                        <i class="fas fa-check-circle me-1"></i>
                        <?php echo $user['status'] === 'active' ? 'Hoạt động' : 'Không hoạt động'; ?>
                    </span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="container my-5">
    <?php 
    show_message('success');
    show_message('error');
    ?>
    
    <?php if ($_SESSION['role'] === 'student'): ?>
    <!-- Thống kê -->
    <div class="row mb-5">
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <i class="fas fa-users fa-3x text-primary mb-3"></i>
                <h3 class="mb-0"><?php echo $clubs_count; ?></h3>
                <p class="text-muted mb-0">CLB Đã Tham Gia</p>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <i class="fas fa-calendar-alt fa-3x text-success mb-3"></i>
                <h3 class="mb-0"><?php echo $events_count; ?></h3>
                <p class="text-muted mb-0">Sự Kiện Đã Đăng Ký</p>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stat-box">
                <i class="fas fa-check-circle fa-3x text-info mb-3"></i>
                <h3 class="mb-0"><?php echo $attended_count; ?></h3>
                <p class="text-muted mb-0">Đã Tham Dự</p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Thông tin cá nhân -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-user me-2 text-primary"></i> Thông Tin Cá Nhân
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="update_info">
                        
                        <div class="mb-3">
                            <label class="form-label">Tên đăng nhập</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                            <small class="text-muted">Không thể thay đổi tên đăng nhập</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Họ và tên <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" 
                                   value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Số điện thoại</label>
                            <input type="tel" class="form-control" name="phone" 
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Ngày tạo tài khoản</label>
                            <input type="text" class="form-control" 
                                   value="<?php echo format_date($user['created_at'], 'd/m/Y H:i'); ?>" disabled>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-save me-2"></i> Cập Nhật Thông Tin
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Đổi mật khẩu -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">
                        <i class="fas fa-lock me-2 text-warning"></i> Đổi Mật Khẩu
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="" id="changePasswordForm">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="mb-3">
                            <label class="form-label">Mật khẩu hiện tại <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="current_password" 
                                       id="current_password" required>
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="togglePassword('current_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Mật khẩu mới <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="new_password" 
                                       id="new_password" required minlength="6">
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="togglePassword('new_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <small class="text-muted">Ít nhất 6 ký tự</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Xác nhận mật khẩu mới <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="confirm_password" 
                                       id="confirm_password" required>
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <small>Sau khi đổi mật khẩu thành công, bạn có thể tiếp tục sử dụng hệ thống bình thường.</small>
                        </div>
                        
                        <button type="submit" class="btn btn-warning w-100">
                            <i class="fas fa-key me-2"></i> Đổi Mật Khẩu
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = event.currentTarget.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    if (newPassword !== confirmPassword) {
        e.preventDefault();
        alert('Mật khẩu xác nhận không khớp!');
        return false;
    }
    
    if (newPassword.length < 6) {
        e.preventDefault();
        alert('Mật khẩu phải có ít nhất 6 ký tự!');
        return false;
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>