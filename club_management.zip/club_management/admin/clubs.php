<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('admin');

// Xử lý thêm CLB
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $club_name = escape_string($_POST['club_name']);
    $description = escape_string($_POST['description']);
    $category = escape_string($_POST['category']);
    $establishment_date = escape_string($_POST['establishment_date']);
    
    if(empty($club_name)) {
        $_SESSION['error'] = "Tên câu lạc bộ không được để trống!";
    } else {
        $sql = "INSERT INTO clubs (club_name, description, category, establishment_date) 
                VALUES ('$club_name', '$description', '$category', '$establishment_date')";
        
        if(execute_query($sql)) {
            $_SESSION['success'] = "Thêm câu lạc bộ thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('clubs.php');
}

// Xử lý cập nhật CLB
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $club_id = (int)$_POST['club_id'];
    $club_name = escape_string($_POST['club_name']);
    $description = escape_string($_POST['description']);
    $category = escape_string($_POST['category']);
    $establishment_date = escape_string($_POST['establishment_date']);
    $status = escape_string($_POST['status']);
    
    $sql = "UPDATE clubs SET 
            club_name = '$club_name',
            description = '$description',
            category = '$category',
            establishment_date = '$establishment_date',
            status = '$status'
            WHERE club_id = $club_id";
    
    if(execute_query($sql)) {
        $_SESSION['success'] = "Cập nhật câu lạc bộ thành công!";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('clubs.php');
}

// Xử lý xóa CLB
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $club_id = (int)$_GET['id'];
    
    $sql = "DELETE FROM clubs WHERE club_id = $club_id";
    
    if(execute_query($sql)) {
        $_SESSION['success'] = "Xóa câu lạc bộ thành công!";
    } else {
        $_SESSION['error'] = "Không thể xóa câu lạc bộ!";
    }
    redirect('clubs.php');
}

// Lấy danh sách CLB
$clubs_sql = "SELECT c.*, 
              COUNT(DISTINCT cm.member_id) as member_count,
              COUNT(DISTINCT e.event_id) as event_count
              FROM clubs c
              LEFT JOIN club_members cm ON c.club_id = cm.club_id AND cm.status = 'active'
              LEFT JOIN events e ON c.club_id = e.club_id
              GROUP BY c.club_id
              ORDER BY c.created_at DESC";
$clubs = get_result($clubs_sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý CLB - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .club-card {
            transition: transform 0.3s;
        }
        .club-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x"></i>
                    <h5 class="mt-2">ADMIN PANEL</h5>
                    <small><?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a class="nav-link active" href="clubs.php">
                        <i class="fas fa-users me-2"></i> Quản Lý CLB
                    </a>
                    <a class="nav-link" href="leaders.php">
                        <i class="fas fa-user-tie me-2"></i> Chủ Nhiệm CLB
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-user-friends me-2"></i> Người Dùng
                    </a>
                    <a class="nav-link" href="approvals.php">
                        <i class="fas fa-check-circle me-2"></i> Phê Duyệt
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Báo Cáo
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                    </a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-users me-2"></i> Quản Lý Câu Lạc Bộ</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addClubModal">
                        <i class="fas fa-plus me-2"></i> Thêm CLB Mới
                    </button>
                </div>
                
                <?php 
                show_message('success');
                show_message('error');
                ?>
                
                <!-- Danh sách CLB -->
                <div class="row">
                    <?php if($clubs && $clubs->num_rows > 0): ?>
                        <?php while($club = $clubs->fetch_assoc()): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card club-card h-100">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h5 class="card-title mb-0">
                                            <?php echo htmlspecialchars($club['club_name']); ?>
                                        </h5>
                                        <?php if($club['status'] == 'active'): ?>
                                            <span class="badge bg-success">Hoạt động</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Không hoạt động</span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-tag me-2"></i><?php echo htmlspecialchars($club['category']); ?>
                                    </p>
                                    
                                    <p class="card-text text-muted small mb-3">
                                        <?php echo htmlspecialchars(substr($club['description'], 0, 100)) . '...'; ?>
                                    </p>
                                    
                                    <div class="row text-center mb-3">
                                        <div class="col-6">
                                            <h4 class="mb-0 text-primary"><?php echo $club['member_count']; ?></h4>
                                            <small class="text-muted">Thành viên</small>
                                        </div>
                                        <div class="col-6">
                                            <h4 class="mb-0 text-success"><?php echo $club['event_count']; ?></h4>
                                            <small class="text-muted">Sự kiện</small>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex gap-2">
                                        <button class="btn btn-sm btn-primary flex-fill" 
                                                onclick="editClub(<?php echo $club['club_id']; ?>)">
                                            <i class="fas fa-edit"></i> Sửa
                                        </button>
                                        <button class="btn btn-sm btn-danger" 
                                                onclick="deleteClub(<?php echo $club['club_id']; ?>, '<?php echo htmlspecialchars($club['club_name']); ?>')">
                                            <i class="fas fa-trash"></i> Xóa
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="alert alert-info text-center">
                                <i class="fas fa-info-circle me-2"></i>
                                Chưa có câu lạc bộ nào. Hãy thêm CLB mới!
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Thêm CLB -->
    <div class="modal fade" id="addClubModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus-circle me-2"></i> Thêm Câu Lạc Bộ Mới
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Tên Câu Lạc Bộ <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="club_name" required>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Danh Mục</label>
                                <select class="form-select" name="category">
                                    <option value="Thể thao">Thể thao</option>
                                    <option value="Âm nhạc">Âm nhạc</option>
                                    <option value="Học thuật">Học thuật</option>
                                    <option value="Văn hóa">Văn hóa</option>
                                    <option value="Công nghệ">Công nghệ</option>
                                    <option value="Khác">Khác</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Mô Tả</label>
                            <textarea class="form-control" name="description" rows="4"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Ngày Thành Lập</label>
                            <input type="date" class="form-control" name="establishment_date">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Lưu
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Sửa CLB -->
    <div class="modal fade" id="editClubModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-edit me-2"></i> Chỉnh Sửa Câu Lạc Bộ
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body" id="editClubForm">
                        <!-- Content will be loaded via AJAX -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Cập Nhật
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editClub(clubId) {
            fetch('get_club.php?id=' + clubId)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        const club = data.club;
                        document.getElementById('editClubForm').innerHTML = `
                            <input type="hidden" name="action" value="edit">
                            <input type="hidden" name="club_id" value="${club.club_id}">
                            
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label class="form-label">Tên Câu Lạc Bộ <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="club_name" value="${club.club_name}" required>
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Danh Mục</label>
                                    <select class="form-select" name="category">
                                        <option value="Thể thao" ${club.category === 'Thể thao' ? 'selected' : ''}>Thể thao</option>
                                        <option value="Âm nhạc" ${club.category === 'Âm nhạc' ? 'selected' : ''}>Âm nhạc</option>
                                        <option value="Học thuật" ${club.category === 'Học thuật' ? 'selected' : ''}>Học thuật</option>
                                        <option value="Văn hóa" ${club.category === 'Văn hóa' ? 'selected' : ''}>Văn hóa</option>
                                        <option value="Công nghệ" ${club.category === 'Công nghệ' ? 'selected' : ''}>Công nghệ</option>
                                        <option value="Khác" ${club.category === 'Khác' ? 'selected' : ''}>Khác</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Mô Tả</label>
                                <textarea class="form-control" name="description" rows="4">${club.description || ''}</textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ngày Thành Lập</label>
                                    <input type="date" class="form-control" name="establishment_date" value="${club.establishment_date || ''}">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Trạng Thái</label>
                                    <select class="form-select" name="status">
                                        <option value="active" ${club.status === 'active' ? 'selected' : ''}>Hoạt động</option>
                                        <option value="inactive" ${club.status === 'inactive' ? 'selected' : ''}>Không hoạt động</option>
                                    </select>
                                </div>
                            </div>
                        `;
                        
                        new bootstrap.Modal(document.getElementById('editClubModal')).show();
                    }
                })
                .catch(error => {
                    alert('Có lỗi xảy ra!');
                    console.error(error);
                });
        }
        
        function deleteClub(clubId, clubName) {
            if(confirm('Bạn có chắc muốn xóa câu lạc bộ "' + clubName + '"?\nLưu ý: Tất cả dữ liệu liên quan sẽ bị xóa!')) {
                window.location.href = 'clubs.php?action=delete&id=' + clubId;
            }
        }
    </script>
</body>
</html>