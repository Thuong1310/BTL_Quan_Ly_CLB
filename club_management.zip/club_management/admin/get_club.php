<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('admin');

header('Content-Type: application/json');

if(isset($_GET['id'])) {
    $club_id = (int)$_GET['id'];
    
    $sql = "SELECT * FROM clubs WHERE club_id = $club_id";
    $club = get_single_row($sql);
    
    if($club) {
        echo json_encode([
            'success' => true,
            'club' => $club
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Không tìm thấy câu lạc bộ'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Thiếu thông tin'
    ]);
}
?>