<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('admin');

// Xử lý duyệt/từ chối sự kiện
if (isset($_GET['action']) && isset($_GET['type']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $type = $_GET['type'];
    $id = (int)$_GET['id'];
    $admin_id = $_SESSION['user_id'];
    
    if($type === 'event') {
        if($action === 'approve') {
            $sql = "UPDATE events SET 
                    status = 'approved',
                    approved_by = $admin_id,
                    approved_at = NOW()
                    WHERE event_id = $id";
            $message = "Sự kiện đã được phê duyệt!";
            
            // Tạo thông báo cho người tạo
            $event_info = get_single_row("SELECT created_by, event_name FROM events WHERE event_id = $id");
            if($event_info) {
                create_notification(
                    $event_info['created_by'],
                    'Sự kiện được phê duyệt',
                    'Sự kiện "' . $event_info['event_name'] . '" của bạn đã được phê duyệt!',
                    'success'
                );
            }
        } else {
            $sql = "UPDATE events SET status = 'rejected' WHERE event_id = $id";
            $message = "Sự kiện đã bị từ chối!";
            
            // Tạo thông báo cho người tạo
            $event_info = get_single_row("SELECT created_by, event_name FROM events WHERE event_id = $id");
            if($event_info) {
                create_notification(
                    $event_info['created_by'],
                    'Sự kiện bị từ chối',
                    'Sự kiện "' . $event_info['event_name'] . '" của bạn đã bị từ chối!',
                    'error'
                );
            }
        }
        
        if(execute_query($sql)) {
            $_SESSION['success'] = $message;
        }
    } 
    elseif($type === 'member') {
        if($action === 'approve') {
            $sql = "UPDATE club_members SET 
                    status = 'active',
                    approved_by = $admin_id,
                    approved_at = NOW()
                    WHERE member_id = $id";
            $message = "Đơn đăng ký đã được phê duyệt!";
            
            // Tạo thông báo
            $member_info = get_single_row("SELECT cm.user_id, c.club_name 
                                          FROM club_members cm
                                          INNER JOIN clubs c ON cm.club_id = c.club_id
                                          WHERE cm.member_id = $id");
            if($member_info) {
                create_notification(
                    $member_info['user_id'],
                    'Đơn đăng ký được chấp nhận',
                    'Đơn đăng ký tham gia CLB "' . $member_info['club_name'] . '" của bạn đã được chấp nhận!',
                    'success'
                );
            }
        } else {
            $sql = "UPDATE club_members SET status = 'rejected' WHERE member_id = $id";
            $message = "Đơn đăng ký đã bị từ chối!";
        }
        
        if(execute_query($sql)) {
            $_SESSION['success'] = $message;
        }
    }
    elseif($type === 'plan') {
        if($action === 'approve') {
            $sql = "UPDATE activity_plans SET 
                    status = 'approved',
                    approved_by = $admin_id,
                    approved_at = NOW()
                    WHERE plan_id = $id";
            $message = "Kế hoạch đã được phê duyệt!";
            
            // Tạo thông báo
            $plan_info = get_single_row("SELECT created_by, title FROM activity_plans WHERE plan_id = $id");
            if($plan_info) {
                create_notification(
                    $plan_info['created_by'],
                    'Kế hoạch được phê duyệt',
                    'Kế hoạch "' . $plan_info['title'] . '" của bạn đã được phê duyệt!',
                    'success'
                );
            }
        } else {
            $sql = "UPDATE activity_plans SET status = 'rejected' WHERE plan_id = $id";
            $message = "Kế hoạch đã bị từ chối!";
        }
        
        if(execute_query($sql)) {
            $_SESSION['success'] = $message;
        }
    }
    
    redirect('approvals.php');
}

// Lấy danh sách sự kiện chờ duyệt
$events_sql = "SELECT e.*, c.club_name, u.full_name as creator_name
               FROM events e
               INNER JOIN clubs c ON e.club_id = c.club_id
               INNER JOIN users u ON e.created_by = u.user_id
               WHERE e.status = 'pending'
               ORDER BY e.created_at DESC";
$pending_events = get_result($events_sql);

// Lấy danh sách đơn xin vào CLB chờ duyệt
$members_sql = "SELECT cm.*, c.club_name, u.full_name, u.email
                FROM club_members cm
                INNER JOIN clubs c ON cm.club_id = c.club_id
                INNER JOIN users u ON cm.user_id = u.user_id
                WHERE cm.status = 'pending'
                ORDER BY cm.created_at DESC";
$pending_members = get_result($members_sql);

// Lấy danh sách kế hoạch chờ duyệt
$plans_sql = "SELECT ap.*, c.club_name, u.full_name as creator_name
              FROM activity_plans ap
              INNER JOIN clubs c ON ap.club_id = c.club_id
              INNER JOIN users u ON ap.created_by = u.user_id
              WHERE ap.status = 'pending'
              ORDER BY ap.created_at DESC";
$pending_plans = get_result($plans_sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phê Duyệt - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .approval-card {
            border-left: 4px solid #ffc107;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x"></i>
                    <h5 class="mt-2">ADMIN PANEL</h5>
                    <small><?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a class="nav-link" href="clubs.php">
                        <i class="fas fa-users me-2"></i> Quản Lý CLB
                    </a>
                    <a class="nav-link" href="leaders.php">
                        <i class="fas fa-user-tie me-2"></i> Chủ Nhiệm CLB
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-user-friends me-2"></i> Người Dùng
                    </a>
                    <a class="nav-link active" href="approvals.php">
                        <i class="fas fa-check-circle me-2"></i> Phê Duyệt
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Báo Cáo
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                    </a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4"><i class="fas fa-check-circle me-2"></i> Phê Duyệt</h2>
                
                <?php 
                show_message('success');
                show_message('error');
                ?>
                
                <!-- Tabs -->
                <ul class="nav nav-tabs mb-4" id="approvalTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="events-tab" data-bs-toggle="tab" 
                                data-bs-target="#events" type="button">
                            <i class="fas fa-calendar me-2"></i> Sự Kiện
                            <?php if($pending_events && $pending_events->num_rows > 0): ?>
                                <span class="badge bg-danger"><?php echo $pending_events->num_rows; ?></span>
                            <?php endif; ?>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="members-tab" data-bs-toggle="tab" 
                                data-bs-target="#members" type="button">
                            <i class="fas fa-user-plus me-2"></i> Đơn Xin Vào CLB
                            <?php if($pending_members && $pending_members->num_rows > 0): ?>
                                <span class="badge bg-danger"><?php echo $pending_members->num_rows; ?></span>
                            <?php endif; ?>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="plans-tab" data-bs-toggle="tab" 
                                data-bs-target="#plans" type="button">
                            <i class="fas fa-clipboard-list me-2"></i> Kế Hoạch
                            <?php if($pending_plans && $pending_plans->num_rows > 0): ?>
                                <span class="badge bg-danger"><?php echo $pending_plans->num_rows; ?></span>
                            <?php endif; ?>
                        </button>
                    </li>
                </ul>
                
                <div class="tab-content" id="approvalTabsContent">
                    <!-- Tab Sự kiện -->
                    <div class="tab-pane fade show active" id="events" role="tabpanel">
                        <?php if($pending_events && $pending_events->num_rows > 0): ?>
                            <?php while($event = $pending_events->fetch_assoc()): ?>
                            <div class="card approval-card mb-3">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-md-8">
                                            <h5 class="card-title mb-2">
                                                <i class="fas fa-calendar-alt me-2 text-primary"></i>
                                                <?php echo htmlspecialchars($event['event_name']); ?>
                                            </h5>
                                            <p class="text-muted mb-2">
                                                <span class="badge bg-info me-2">
                                                    <?php echo htmlspecialchars($event['club_name']); ?>
                                                </span>
                                                Tạo bởi: <?php echo htmlspecialchars($event['creator_name']); ?>
                                            </p>
                                            <p class="mb-2">
                                                <i class="fas fa-clock me-2"></i>
                                                <?php echo format_date($event['event_date']); ?> | 
                                                <?php echo date('H:i', strtotime($event['start_time'])); ?> - 
                                                <?php echo date('H:i', strtotime($event['end_time'])); ?>
                                            </p>
                                            <p class="mb-0">
                                                <i class="fas fa-map-marker-alt me-2"></i>
                                                <?php echo htmlspecialchars($event['location']); ?>
                                            </p>
                                            <?php if($event['description']): ?>
                                            <p class="text-muted mt-2 mb-0">
                                                <?php echo htmlspecialchars(substr($event['description'], 0, 150)); ?>...
                                            </p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <button class="btn btn-success me-2" 
                                                    onclick="approveItem('event', <?php echo $event['event_id']; ?>)">
                                                <i class="fas fa-check me-2"></i> Duyệt
                                            </button>
                                            <button class="btn btn-danger" 
                                                    onclick="rejectItem('event', <?php echo $event['event_id']; ?>)">
                                                <i class="fas fa-times me-2"></i> Từ chối
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Không có sự kiện nào chờ duyệt
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Tab Đơn xin vào CLB -->
                    <div class="tab-pane fade" id="members" role="tabpanel">
                        <?php if($pending_members && $pending_members->num_rows > 0): ?>
                            <?php while($member = $pending_members->fetch_assoc()): ?>
                            <div class="card approval-card mb-3">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-md-8">
                                            <h5 class="card-title mb-2">
                                                <i class="fas fa-user me-2 text-success"></i>
                                                <?php echo htmlspecialchars($member['full_name']); ?>
                                            </h5>
                                            <p class="mb-2">
                                                <span class="badge bg-info">
                                                    <?php echo htmlspecialchars($member['club_name']); ?>
                                                </span>
                                            </p>
                                            <p class="text-muted mb-0">
                                                <i class="fas fa-envelope me-2"></i>
                                                <?php echo htmlspecialchars($member['email']); ?>
                                            </p>
                                            <small class="text-muted">
                                                Đăng ký lúc: <?php echo format_date($member['created_at'], 'd/m/Y H:i'); ?>
                                            </small>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <button class="btn btn-success me-2" 
                                                    onclick="approveItem('member', <?php echo $member['member_id']; ?>)">
                                                <i class="fas fa-check me-2"></i> Duyệt
                                            </button>
                                            <button class="btn btn-danger" 
                                                    onclick="rejectItem('member', <?php echo $member['member_id']; ?>)">
                                                <i class="fas fa-times me-2"></i> Từ chối
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Không có đơn nào chờ duyệt
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Tab Kế hoạch -->
                    <div class="tab-pane fade" id="plans" role="tabpanel">
                        <?php if($pending_plans && $pending_plans->num_rows > 0): ?>
                            <?php while($plan = $pending_plans->fetch_assoc()): ?>
                            <div class="card approval-card mb-3">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-md-8">
                                            <h5 class="card-title mb-2">
                                                <i class="fas fa-clipboard-list me-2 text-warning"></i>
                                                <?php echo htmlspecialchars($plan['title']); ?>
                                            </h5>
                                            <p class="mb-2">
                                                <span class="badge bg-info me-2">
                                                    <?php echo htmlspecialchars($plan['club_name']); ?>
                                                </span>
                                                Tạo bởi: <?php echo htmlspecialchars($plan['creator_name']); ?>
                                            </p>
                                            <p class="mb-2">
                                                <i class="fas fa-calendar me-2"></i>
                                                Từ <?php echo format_date($plan['start_date']); ?> đến 
                                                <?php echo format_date($plan['end_date']); ?>
                                            </p>
                                            <?php if($plan['budget']): ?>
                                            <p class="mb-2">
                                                <i class="fas fa-dollar-sign me-2"></i>
                                                Ngân sách: <?php echo format_currency($plan['budget']); ?>
                                            </p>
                                            <?php endif; ?>
                                            <?php if($plan['description']): ?>
                                            <p class="text-muted mb-0">
                                                <?php echo htmlspecialchars(substr($plan['description'], 0, 150)); ?>...
                                            </p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <button class="btn btn-success me-2" 
                                                    onclick="approveItem('plan', <?php echo $plan['plan_id']; ?>)">
                                                <i class="fas fa-check me-2"></i> Duyệt
                                            </button>
                                            <button class="btn btn-danger" 
                                                    onclick="rejectItem('plan', <?php echo $plan['plan_id']; ?>)">
                                                <i class="fas fa-times me-2"></i> Từ chối
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Không có kế hoạch nào chờ duyệt
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function approveItem(type, id) {
            if(confirm('Bạn có chắc muốn phê duyệt?')) {
                window.location.href = 'approvals.php?action=approve&type=' + type + '&id=' + id;
            }
        }
        
        function rejectItem(type, id) {
            if(confirm('Bạn có chắc muốn từ chối?')) {
                window.location.href = 'approvals.php?action=reject&type=' + type + '&id=' + id;
            }
        }
    </script>
</body>
</html>