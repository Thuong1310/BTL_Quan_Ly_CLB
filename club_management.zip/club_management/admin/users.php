<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('admin');

// Xử lý thay đổi trạng thái user
if (isset($_GET['action']) && $_GET['action'] === 'toggle_status' && isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];
    
    // Lấy trạng thái hiện tại
    $user = get_single_row("SELECT status FROM users WHERE user_id = $user_id");
    
    if($user) {
        $new_status = ($user['status'] === 'active') ? 'inactive' : 'active';
        $sql = "UPDATE users SET status = '$new_status' WHERE user_id = $user_id";
        
        if(execute_query($sql)) {
            $_SESSION['success'] = "Cập nhật trạng thái thành công!";
        }
    }
    redirect('users.php');
}

// Xử lý xóa user
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];
    
    // Không cho xóa admin
    $user = get_single_row("SELECT role FROM users WHERE user_id = $user_id");
    if($user && $user['role'] !== 'admin') {
        $sql = "DELETE FROM users WHERE user_id = $user_id";
        
        if(execute_query($sql)) {
            $_SESSION['success'] = "Xóa người dùng thành công!";
        } else {
            $_SESSION['error'] = "Không thể xóa người dùng!";
        }
    } else {
        $_SESSION['error'] = "Không thể xóa tài khoản admin!";
    }
    redirect('users.php');
}

// Pagination
$per_page = 20;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $per_page;

// Tìm kiếm
$search = isset($_GET['search']) ? escape_string($_GET['search']) : '';
$role_filter = isset($_GET['role']) ? escape_string($_GET['role']) : '';

$where_conditions = [];
if(!empty($search)) {
    $where_conditions[] = "(full_name LIKE '%$search%' OR email LIKE '%$search%' OR username LIKE '%$search%')";
}
if(!empty($role_filter)) {
    $where_conditions[] = "role = '$role_filter'";
}

$where_sql = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Đếm tổng số user
$count_sql = "SELECT COUNT(*) as total FROM users $where_sql";
$total_users = get_single_row($count_sql)['total'];
$total_pages = ceil($total_users / $per_page);

// Lấy danh sách users
$users_sql = "SELECT u.*,
              (SELECT COUNT(*) FROM club_members WHERE user_id = u.user_id AND status = 'active') as clubs_count
              FROM users u
              $where_sql
              ORDER BY u.created_at DESC
              LIMIT $per_page OFFSET $offset";
$users = get_result($users_sql);

// Thống kê
$stats_sql = "SELECT 
              COUNT(CASE WHEN role = 'student' THEN 1 END) as students,
              COUNT(CASE WHEN role = 'leader' THEN 1 END) as leaders,
              COUNT(CASE WHEN status = 'active' THEN 1 END) as active_users
              FROM users";
$stats = get_single_row($stats_sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Người Dùng - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .stat-box {
            padding: 20px;
            border-radius: 10px;
            background: white;
            margin-bottom: 20px;
        }
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x"></i>
                    <h5 class="mt-2">ADMIN PANEL</h5>
                    <small><?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a class="nav-link" href="clubs.php">
                        <i class="fas fa-users me-2"></i> Quản Lý CLB
                    </a>
                    <a class="nav-link" href="leaders.php">
                        <i class="fas fa-user-tie me-2"></i> Chủ Nhiệm CLB
                    </a>
                    <a class="nav-link active" href="users.php">
                        <i class="fas fa-user-friends me-2"></i> Người Dùng
                    </a>
                    <a class="nav-link" href="approvals.php">
                        <i class="fas fa-check-circle me-2"></i> Phê Duyệt
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Báo Cáo
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                    </a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <h2 class="mb-4"><i class="fas fa-user-friends me-2"></i> Quản Lý Người Dùng</h2>
                
                <?php 
                show_message('success');
                show_message('error');
                ?>
                
                <!-- Thống kê -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="stat-box border-start border-5 border-primary">
                            <h6 class="text-muted">Sinh Viên</h6>
                            <h3 class="mb-0"><?php echo $stats['students']; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-box border-start border-5 border-success">
                            <h6 class="text-muted">Chủ Nhiệm</h6>
                            <h3 class="mb-0"><?php echo $stats['leaders']; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-box border-start border-5 border-info">
                            <h6 class="text-muted">Đang Hoạt Động</h6>
                            <h3 class="mb-0"><?php echo $stats['active_users']; ?></h3>
                        </div>
                    </div>
                </div>
                
                <!-- Tìm kiếm và lọc -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" action="" class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Tìm kiếm theo tên, email, username..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="role">
                                    <option value="">Tất cả vai trò</option>
                                    <option value="student" <?php echo $role_filter === 'student' ? 'selected' : ''; ?>>
                                        Sinh viên
                                    </option>
                                    <option value="leader" <?php echo $role_filter === 'leader' ? 'selected' : ''; ?>>
                                        Chủ nhiệm
                                    </option>
                                    <option value="admin" <?php echo $role_filter === 'admin' ? 'selected' : ''; ?>>
                                        Admin
                                    </option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-search me-2"></i> Tìm kiếm
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Danh sách users -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Người dùng</th>
                                        <th>Vai trò</th>
                                        <th>CLB tham gia</th>
                                        <th>Trạng thái</th>
                                        <th>Ngày tạo</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($users && $users->num_rows > 0): 
                                        while($user = $users->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td><?php echo $user['user_id']; ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="../assets/images/<?php echo $user['avatar']; ?>" 
                                                     class="avatar me-2" 
                                                     onerror="this.src='../assets/images/default-avatar.png'">
                                                <div>
                                                    <strong><?php echo htmlspecialchars($user['full_name']); ?></strong><br>
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars($user['email']); ?>
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php 
                                            $role_badges = [
                                                'admin' => 'danger',
                                                'leader' => 'success',
                                                'student' => 'primary'
                                            ];
                                            $role_names = [
                                                'admin' => 'Admin',
                                                'leader' => 'Chủ nhiệm',
                                                'student' => 'Sinh viên'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $role_badges[$user['role']]; ?>">
                                                <?php echo $role_names[$user['role']]; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo $user['clubs_count']; ?> CLB</span>
                                        </td>
                                        <td>
                                            <?php if($user['status'] === 'active'): ?>
                                                <span class="badge bg-success">Hoạt động</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Không hoạt động</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small><?php echo format_date($user['created_at'], 'd/m/Y'); ?></small>
                                        </td>
                                        <td>
                                            <?php if($user['role'] !== 'admin'): ?>
                                            <div class="btn-group btn-group-sm">
                                                <button class="btn btn-outline-primary" 
                                                        onclick="toggleStatus(<?php echo $user['user_id']; ?>)">
                                                    <i class="fas fa-<?php echo $user['status'] === 'active' ? 'ban' : 'check'; ?>"></i>
                                                </button>
                                                <button class="btn btn-outline-danger" 
                                                        onclick="deleteUser(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['full_name']); ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php 
                                        endwhile; 
                                    else: 
                                    ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">
                                            Không tìm thấy người dùng nào
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if($total_pages > 1): ?>
                        <nav>
                            <ul class="pagination justify-content-center">
                                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo urlencode($role_filter); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                                <?php endfor; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleStatus(userId) {
            if(confirm('Bạn có chắc muốn thay đổi trạng thái người dùng này?')) {
                window.location.href = 'users.php?action=toggle_status&id=' + userId;
            }
        }
        
        function deleteUser(userId, userName) {
            if(confirm('Bạn có chắc muốn xóa người dùng "' + userName + '"?\nToàn bộ dữ liệu liên quan sẽ bị xóa!')) {
                window.location.href = 'users.php?action=delete&id=' + userId;
            }
        }
    </script>
</body>
</html>