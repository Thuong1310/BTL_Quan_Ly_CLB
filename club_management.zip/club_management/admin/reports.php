<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('admin');

// Thống kê tổng quan
$total_clubs = get_single_row("SELECT COUNT(*) as count FROM clubs WHERE status = 'active'")['count'];
$total_members = get_single_row("SELECT COUNT(*) as count FROM club_members WHERE status = 'active'")['count'];
$total_events = get_single_row("SELECT COUNT(*) as count FROM events")['count'];
$total_users = get_single_row("SELECT COUNT(*) as count FROM users WHERE role = 'student'")['count'];

// Top 5 CLB có nhiều thành viên nhất
$top_clubs_sql = "SELECT c.club_name, c.category, COUNT(cm.member_id) as member_count
                  FROM clubs c
                  LEFT JOIN club_members cm ON c.club_id = cm.club_id AND cm.status = 'active'
                  WHERE c.status = 'active'
                  GROUP BY c.club_id
                  ORDER BY member_count DESC
                  LIMIT 5";
$top_clubs = get_result($top_clubs_sql);

// CLB theo danh mục
$clubs_by_category_sql = "SELECT category, COUNT(*) as count 
                          FROM clubs 
                          WHERE status = 'active' 
                          GROUP BY category 
                          ORDER BY count DESC";
$clubs_by_category = get_result($clubs_by_category_sql);

// Sự kiện theo tháng (6 tháng gần nhất)
$events_by_month_sql = "SELECT 
                        DATE_FORMAT(event_date, '%m/%Y') as month,
                        COUNT(*) as count
                        FROM events
                        WHERE event_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                        GROUP BY DATE_FORMAT(event_date, '%Y-%m')
                        ORDER BY event_date";
$events_by_month = get_result($events_by_month_sql);

// Sinh viên mới đăng ký (30 ngày gần nhất)
$new_users_sql = "SELECT COUNT(*) as count 
                  FROM users 
                  WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                  AND role = 'student'";
$new_users = get_single_row($new_users_sql)['count'];

// Tổng ngân sách các CLB
$total_budget_sql = "SELECT 
                     SUM(CASE WHEN transaction_type = 'income' THEN amount ELSE 0 END) as total_income,
                     SUM(CASE WHEN transaction_type = 'expense' THEN amount ELSE 0 END) as total_expense
                     FROM finances";
$budget = get_single_row($total_budget_sql);
$total_income = $budget['total_income'] ?? 0;
$total_expense = $budget['total_expense'] ?? 0;
$balance = $total_income - $total_expense;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo Cáo - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .stat-card {
            padding: 25px;
            border-radius: 15px;
            color: white;
            margin-bottom: 20px;
        }
        .chart-container {
            position: relative;
            height: 300px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x"></i>
                    <h5 class="mt-2">ADMIN PANEL</h5>
                    <small><?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a class="nav-link" href="clubs.php">
                        <i class="fas fa-users me-2"></i> Quản Lý CLB
                    </a>
                    <a class="nav-link" href="leaders.php">
                        <i class="fas fa-user-tie me-2"></i> Chủ Nhiệm CLB
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-user-friends me-2"></i> Người Dùng
                    </a>
                    <a class="nav-link" href="approvals.php">
                        <i class="fas fa-check-circle me-2"></i> Phê Duyệt
                    </a>
                    <a class="nav-link active" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Báo Cáo
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                    </a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-chart-bar me-2"></i> Báo Cáo Thống Kê</h2>
                    <button class="btn btn-primary" onclick="window.print()">
                        <i class="fas fa-print me-2"></i> In Báo Cáo
                    </button>
                </div>
                
                <!-- Thống kê tổng quan -->
                <div class="row">
                    <div class="col-md-3">
                        <div class="stat-card bg-primary">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Câu Lạc Bộ</h6>
                                    <h2 class="mb-0"><?php echo $total_clubs; ?></h2>
                                </div>
                                <div>
                                    <i class="fas fa-users fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-card bg-success">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Thành Viên</h6>
                                    <h2 class="mb-0"><?php echo $total_members; ?></h2>
                                </div>
                                <div>
                                    <i class="fas fa-user-friends fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-card bg-warning text-dark">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Sự Kiện</h6>
                                    <h2 class="mb-0"><?php echo $total_events; ?></h2>
                                </div>
                                <div>
                                    <i class="fas fa-calendar fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-card bg-info text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Sinh Viên Mới (30 ngày)</h6>
                                    <h2 class="mb-0"><?php echo $new_users; ?></h2>
                                </div>
                                <div>
                                    <i class="fas fa-user-plus fa-3x opacity-50"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Top CLB -->
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-trophy me-2 text-warning"></i>
                                    Top 5 CLB Nhiều Thành Viên
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if($top_clubs && $top_clubs->num_rows > 0): ?>
                                    <?php 
                                    $colors = ['primary', 'success', 'info', 'warning', 'secondary'];
                                    $i = 0;
                                    while($club = $top_clubs->fetch_assoc()): 
                                    ?>
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <div>
                                                <strong><?php echo htmlspecialchars($club['club_name']); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo htmlspecialchars($club['category']); ?></small>
                                            </div>
                                            <span class="badge bg-<?php echo $colors[$i]; ?>">
                                                <?php echo $club['member_count']; ?> thành viên
                                            </span>
                                        </div>
                                        <div class="progress" style="height: 8px;">
                                            <div class="progress-bar bg-<?php echo $colors[$i]; ?>" 
                                                 style="width: <?php echo ($club['member_count'] / $total_members * 100); ?>%">
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    $i++;
                                    endwhile; 
                                    ?>
                                <?php else: ?>
                                    <p class="text-muted text-center">Chưa có dữ liệu</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- CLB theo danh mục -->
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-tags me-2 text-primary"></i>
                                    CLB Theo Danh Mục
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if($clubs_by_category && $clubs_by_category->num_rows > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Danh Mục</th>
                                                    <th class="text-end">Số Lượng</th>
                                                    <th>Tỷ Lệ</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($cat = $clubs_by_category->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($cat['category']); ?></td>
                                                    <td class="text-end">
                                                        <strong><?php echo $cat['count']; ?></strong>
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        $percentage = ($cat['count'] / $total_clubs * 100);
                                                        ?>
                                                        <div class="progress" style="height: 20px;">
                                                            <div class="progress-bar" 
                                                                 style="width: <?php echo $percentage; ?>%">
                                                                <?php echo round($percentage, 1); ?>%
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted text-center">Chưa có dữ liệu</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Sự kiện theo tháng -->
                    <div class="col-md-8 mb-4">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-calendar-alt me-2 text-success"></i>
                                    Số Lượng Sự Kiện (6 Tháng Gần Nhất)
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if($events_by_month && $events_by_month->num_rows > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Tháng</th>
                                                    <th>Số Sự Kiện</th>
                                                    <th>Biểu Đồ</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $max_events = 0;
                                                $events_data = [];
                                                while($event = $events_by_month->fetch_assoc()) {
                                                    $events_data[] = $event;
                                                    if($event['count'] > $max_events) $max_events = $event['count'];
                                                }
                                                
                                                foreach($events_data as $event): 
                                                ?>
                                                <tr>
                                                    <td><strong><?php echo $event['month']; ?></strong></td>
                                                    <td><span class="badge bg-primary"><?php echo $event['count']; ?></span></td>
                                                    <td>
                                                        <div class="progress" style="height: 25px;">
                                                            <div class="progress-bar bg-success" 
                                                                 style="width: <?php echo ($event['count'] / $max_events * 100); ?>%">
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted text-center">Chưa có dữ liệu</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tài chính -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-dollar-sign me-2 text-warning"></i>
                                    Tổng Quan Tài Chính
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-4">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="text-muted">Thu Nhập</span>
                                        <strong class="text-success"><?php echo format_currency($total_income); ?></strong>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-success" style="width: 100%"></div>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="text-muted">Chi Tiêu</span>
                                        <strong class="text-danger"><?php echo format_currency($total_expense); ?></strong>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-danger" style="width: 100%"></div>
                                    </div>
                                </div>
                                
                                <hr>
                                
                                <div class="text-center p-3 rounded" 
                                     style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                    <small class="text-white d-block mb-1">Số Dư</small>
                                    <h3 class="text-white mb-0"><?php echo format_currency($balance); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>