<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

require_role('admin');

// Xử lý thêm chủ nhiệm
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $club_id = (int)$_POST['club_id'];
    $user_id = (int)$_POST['user_id'];
    $position = escape_string($_POST['position']);
    $start_date = escape_string($_POST['start_date']);
    
    // Kiểm tra xem user đã là leader của CLB này chưa
    $check_sql = "SELECT * FROM club_leaders WHERE club_id = $club_id AND user_id = $user_id AND status = 'active'";
    if(get_single_row($check_sql)) {
        $_SESSION['error'] = "Người dùng này đã là chủ nhiệm của CLB!";
    } else {
        // Cập nhật role user thành leader
        $update_user = "UPDATE users SET role = 'leader' WHERE user_id = $user_id";
        execute_query($update_user);
        
        // Thêm vào bảng club_leaders
        $sql = "INSERT INTO club_leaders (club_id, user_id, position, start_date) 
                VALUES ($club_id, $user_id, '$position', '$start_date')";
        
        if(execute_query($sql)) {
            $_SESSION['success'] = "Thêm chủ nhiệm thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('leaders.php');
}

// Xử lý xóa chủ nhiệm
if (isset($_GET['action']) && $_GET['action'] === 'remove' && isset($_GET['id'])) {
    $leader_id = (int)$_GET['id'];
    
    // Lấy thông tin leader
    $leader_info = get_single_row("SELECT user_id FROM club_leaders WHERE leader_id = $leader_id");
    
    if($leader_info) {
        // Cập nhật status
        $sql = "UPDATE club_leaders SET status = 'inactive', end_date = CURDATE() WHERE leader_id = $leader_id";
        
        if(execute_query($sql)) {
            // Kiểm tra xem user còn là leader của CLB nào khác không
            $check_other = "SELECT * FROM club_leaders WHERE user_id = {$leader_info['user_id']} AND status = 'active'";
            if(!get_single_row($check_other)) {
                // Nếu không còn là leader của CLB nào, đổi role về student
                $update_role = "UPDATE users SET role = 'student' WHERE user_id = {$leader_info['user_id']}";
                execute_query($update_role);
            }
            
            $_SESSION['success'] = "Xóa chủ nhiệm thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra!";
        }
    }
    redirect('leaders.php');
}

// Lấy danh sách chủ nhiệm
$leaders_sql = "SELECT cl.*, c.club_name, u.full_name, u.email, u.phone
                FROM club_leaders cl
                INNER JOIN clubs c ON cl.club_id = c.club_id
                INNER JOIN users u ON cl.user_id = u.user_id
                WHERE cl.status = 'active'
                ORDER BY cl.created_at DESC";
$leaders = get_result($leaders_sql);

// Lấy danh sách CLB
$clubs_sql = "SELECT club_id, club_name FROM clubs WHERE status = 'active' ORDER BY club_name";
$clubs = get_result($clubs_sql);

// Lấy danh sách users (không phải admin và chưa là leader)
$users_sql = "SELECT u.user_id, u.full_name, u.email 
              FROM users u
              WHERE u.status = 'active' AND u.role != 'admin'
              ORDER BY u.full_name";
$users = get_result($users_sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Chủ Nhiệm - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x"></i>
                    <h5 class="mt-2">ADMIN PANEL</h5>
                    <small><?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a class="nav-link" href="clubs.php">
                        <i class="fas fa-users me-2"></i> Quản Lý CLB
                    </a>
                    <a class="nav-link active" href="leaders.php">
                        <i class="fas fa-user-tie me-2"></i> Chủ Nhiệm CLB
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-user-friends me-2"></i> Người Dùng
                    </a>
                    <a class="nav-link" href="approvals.php">
                        <i class="fas fa-check-circle me-2"></i> Phê Duyệt
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Báo Cáo
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                    </a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-user-tie me-2"></i> Quản Lý Chủ Nhiệm CLB</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addLeaderModal">
                        <i class="fas fa-plus me-2"></i> Thêm Chủ Nhiệm
                    </button>
                </div>
                
                <?php 
                show_message('success');
                show_message('error');
                ?>
                
                <!-- Danh sách chủ nhiệm -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Họ và Tên</th>
                                        <th>Câu Lạc Bộ</th>
                                        <th>Chức vụ</th>
                                        <th>Liên hệ</th>
                                        <th>Ngày bắt đầu</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if($leaders && $leaders->num_rows > 0): 
                                        $stt = 1;
                                        while($leader = $leaders->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td><?php echo $stt++; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($leader['full_name']); ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php echo htmlspecialchars($leader['club_name']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($leader['position']); ?></td>
                                        <td>
                                            <small>
                                                <i class="fas fa-envelope me-1"></i>
                                                <?php echo htmlspecialchars($leader['email']); ?><br>
                                                <?php if($leader['phone']): ?>
                                                <i class="fas fa-phone me-1"></i>
                                                <?php echo htmlspecialchars($leader['phone']); ?>
                                                <?php endif; ?>
                                            </small>
                                        </td>
                                        <td><?php echo format_date($leader['start_date']); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-danger" 
                                                    onclick="removeLeader(<?php echo $leader['leader_id']; ?>, '<?php echo htmlspecialchars($leader['full_name']); ?>')">
                                                <i class="fas fa-times"></i> Xóa
                                            </button>
                                        </td>
                                    </tr>
                                    <?php 
                                        endwhile; 
                                    else: 
                                    ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">
                                            Chưa có chủ nhiệm nào
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Thêm Chủ Nhiệm -->
    <div class="modal fade" id="addLeaderModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-user-plus me-2"></i> Thêm Chủ Nhiệm CLB
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="mb-3">
                            <label class="form-label">Câu Lạc Bộ <span class="text-danger">*</span></label>
                            <select class="form-select" name="club_id" required>
                                <option value="">-- Chọn CLB --</option>
                                <?php 
                                if($clubs && $clubs->num_rows > 0):
                                    mysqli_data_seek($clubs, 0);
                                    while($club = $clubs->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $club['club_id']; ?>">
                                    <?php echo htmlspecialchars($club['club_name']); ?>
                                </option>
                                <?php 
                                    endwhile; 
                                endif; 
                                ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Người Dùng <span class="text-danger">*</span></label>
                            <select class="form-select" name="user_id" required>
                                <option value="">-- Chọn người dùng --</option>
                                <?php 
                                if($users && $users->num_rows > 0):
                                    while($user = $users->fetch_assoc()): 
                                ?>
                                <option value="<?php echo $user['user_id']; ?>">
                                    <?php echo htmlspecialchars($user['full_name']); ?> 
                                    (<?php echo htmlspecialchars($user['email']); ?>)
                                </option>
                                <?php 
                                    endwhile; 
                                endif; 
                                ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Chức Vụ</label>
                            <input type="text" class="form-control" name="position" 
                                   value="Leader" placeholder="Leader, President...">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Ngày Bắt Đầu <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="start_date" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Lưu
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function removeLeader(leaderId, leaderName) {
            if(confirm('Bạn có chắc muốn xóa chủ nhiệm "' + leaderName + '"?')) {
                window.location.href = 'leaders.php?action=remove&id=' + leaderId;
            }
        }
    </script>
</body>
</html>