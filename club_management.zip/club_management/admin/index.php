<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Kiểm tra quyền admin
require_role('admin');

// Lấy thống kê
$total_users_sql = "SELECT COUNT(*) as count FROM users WHERE role = 'student'";
$total_users = get_single_row($total_users_sql)['count'];

$total_clubs_sql = "SELECT COUNT(*) as count FROM clubs WHERE status = 'active'";
$total_clubs = get_single_row($total_clubs_sql)['count'];

$total_events_sql = "SELECT COUNT(*) as count FROM events WHERE status = 'pending'";
$pending_events = get_single_row($total_events_sql)['count'];

$total_members_sql = "SELECT COUNT(*) as count FROM club_members WHERE status = 'pending'";
$pending_members = get_single_row($total_members_sql)['count'];

// Lấy danh sách CLB mới nhất
$recent_clubs_sql = "SELECT c.*, COUNT(cm.member_id) as member_count 
                     FROM clubs c 
                     LEFT JOIN club_members cm ON c.club_id = cm.club_id AND cm.status = 'active'
                     GROUP BY c.club_id 
                     ORDER BY c.created_at DESC 
                     LIMIT 5";
$recent_clubs = get_result($recent_clubs_sql);

// Lấy sự kiện đang chờ duyệt
$pending_events_sql = "SELECT e.*, c.club_name, u.full_name as creator_name
                       FROM events e
                       INNER JOIN clubs c ON e.club_id = c.club_id
                       INNER JOIN users u ON e.created_by = u.user_id
                       WHERE e.status = 'pending'
                       ORDER BY e.created_at DESC
                       LIMIT 5";
$pending_events_list = get_result($pending_events_sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Quản Lý CLB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card {
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .table thead {
            background-color: #f8f9fa;
        }
        .badge-status {
            padding: 5px 15px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-user-shield fa-3x"></i>
                    <h5 class="mt-2">ADMIN PANEL</h5>
                    <small><?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link active" href="index.php">
                        <i class="fas fa-home me-2"></i> Trang chủ
                    </a>
                    <a class="nav-link" href="clubs.php">
                        <i class="fas fa-users me-2"></i> Quản Lý CLB
                    </a>
                    <a class="nav-link" href="leaders.php">
                        <i class="fas fa-user-tie me-2"></i> Chủ Nhiệm CLB
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-user-friends me-2"></i> Người Dùng
                    </a>
                    <a class="nav-link" href="approvals.php">
                        <i class="fas fa-check-circle me-2"></i> Phê Duyệt
                        <?php if($pending_events > 0 || $pending_members > 0): ?>
                            <span class="badge bg-danger"><?php echo $pending_events + $pending_members; ?></span>
                        <?php endif; ?>
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Báo Cáo
                    </a>
                    <hr class="text-white">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Đăng Xuất
                    </a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-tachometer-alt me-2"></i> Dashboard</h2>
                    <div class="text-muted">
                        <i class="fas fa-calendar me-2"></i>
                        <?php echo date('d/m/Y H:i'); ?>
                    </div>
                </div>
                
                <?php 
                show_message('success');
                show_message('error');
                ?>
                
                <!-- Thống kê -->
                <div class="row">
                    <div class="col-md-3">
                        <div class="stat-card bg-primary text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Tổng Sinh Viên</h6>
                                    <h2 class="mb-0"><?php echo $total_users; ?></h2>
                                </div>
                                <div class="stat-icon bg-white bg-opacity-25">
                                    <i class="fas fa-user-graduate"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-card bg-success text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Câu Lạc Bộ</h6>
                                    <h2 class="mb-0"><?php echo $total_clubs; ?></h2>
                                </div>
                                <div class="stat-icon bg-white bg-opacity-25">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-card bg-warning text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Sự Kiện Chờ Duyệt</h6>
                                    <h2 class="mb-0"><?php echo $pending_events; ?></h2>
                                </div>
                                <div class="stat-icon bg-white bg-opacity-25">
                                    <i class="fas fa-calendar-check"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stat-card bg-info text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Đơn Chờ Duyệt</h6>
                                    <h2 class="mb-0"><?php echo $pending_members; ?></h2>
                                </div>
                                <div class="stat-icon bg-white bg-opacity-25">
                                    <i class="fas fa-user-check"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <!-- Câu lạc bộ mới nhất -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-users me-2"></i> Câu Lạc Bộ Mới Nhất</h5>
                            </div>
                            <div class="card-body">
                                <?php if($recent_clubs && $recent_clubs->num_rows > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Tên CLB</th>
                                                    <th>Thành viên</th>
                                                    <th>Trạng thái</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($club = $recent_clubs->fetch_assoc()): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($club['club_name']); ?></strong><br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($club['category']); ?></small>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info"><?php echo $club['member_count']; ?> người</span>
                                                    </td>
                                                    <td>
                                                        <?php if($club['status'] == 'active'): ?>
                                                            <span class="badge bg-success">Hoạt động</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary">Không hoạt động</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-center text-muted">Chưa có câu lạc bộ nào</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Sự kiện chờ duyệt -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-white">
                                <h5 class="mb-0"><i class="fas fa-calendar-check me-2"></i> Sự Kiện Chờ Duyệt</h5>
                            </div>
                            <div class="card-body">
                                <?php if($pending_events_list && $pending_events_list->num_rows > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Tên sự kiện</th>
                                                    <th>CLB</th>
                                                    <th>Ngày</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($event = $pending_events_list->fetch_assoc()): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($event['event_name']); ?></strong><br>
                                                        <small class="text-muted">Bởi <?php echo htmlspecialchars($event['creator_name']); ?></small>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($event['club_name']); ?></td>
                                                    <td>
                                                        <small><?php echo format_date($event['event_date']); ?></small>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="text-center">
                                        <a href="approvals.php" class="btn btn-primary btn-sm">Xem tất cả</a>
                                    </div>
                                <?php else: ?>
                                    <p class="text-center text-muted">Không có sự kiện chờ duyệt</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>