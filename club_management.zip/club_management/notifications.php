<?php
$page_title = "Thông Báo";
require_once 'config/database.php';
require_once 'includes/functions.php';

require_login();

$user_id = $_SESSION['user_id'];

// Xử lý xóa thông báo
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $notification_id = (int)$_GET['id'];
    
    $delete_sql = "DELETE FROM notifications WHERE notification_id = $notification_id AND user_id = $user_id";
    
    if (execute_query($delete_sql)) {
        $_SESSION['success'] = "Đã xóa thông báo!";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('notifications.php');
}

// Xử lý xóa tất cả thông báo đã đọc
if (isset($_GET['action']) && $_GET['action'] === 'delete_read') {
    $delete_sql = "DELETE FROM notifications WHERE user_id = $user_id AND is_read = 1";
    
    if (execute_query($delete_sql)) {
        $_SESSION['success'] = "Đã xóa tất cả thông báo đã đọc!";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra!";
    }
    redirect('notifications.php');
}

// Pagination
$per_page = 20;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $per_page;

// Lọc theo trạng thái
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$where_filter = '';
if ($filter === 'unread') {
    $where_filter = ' AND is_read = 0';
} elseif ($filter === 'read') {
    $where_filter = ' AND is_read = 1';
}

// Đếm tổng số thông báo
$count_sql = "SELECT COUNT(*) as total FROM notifications WHERE user_id = $user_id $where_filter";
$total_notifications = get_single_row($count_sql)['total'];
$total_pages = ceil($total_notifications / $per_page);

// Lấy danh sách thông báo
$notifications_sql = "SELECT * FROM notifications 
                      WHERE user_id = $user_id $where_filter
                      ORDER BY created_at DESC 
                      LIMIT $per_page OFFSET $offset";
$notifications = get_result($notifications_sql);

// Đếm thông báo chưa đọc
$unread_count = get_single_row("SELECT COUNT(*) as count FROM notifications WHERE user_id = $user_id AND is_read = 0")['count'];

require_once 'includes/header.php';
?>

<div class="container my-5">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>
                    <i class="fas fa-bell me-2"></i> 
                    Thông Báo
                    <?php if ($unread_count > 0): ?>
                        <span class="badge bg-danger"><?php echo $unread_count; ?> mới</span>
                    <?php endif; ?>
                </h2>
                
                <div>
                    <?php if ($unread_count > 0): ?>
                        <button class="btn btn-outline-primary me-2" onclick="markAllNotificationsRead()">
                            <i class="fas fa-check-double me-2"></i> Đánh dấu tất cả đã đọc
                        </button>
                    <?php endif; ?>
                    
                    <a href="?action=delete_read" class="btn btn-outline-danger" 
                       onclick="return confirm('Xóa tất cả thông báo đã đọc?')">
                        <i class="fas fa-trash me-2"></i> Xóa đã đọc
                    </a>
                </div>
            </div>
            
            <?php 
            show_message('success');
            show_message('error');
            ?>
            
            <!-- Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="btn-group" role="group">
                        <a href="notifications.php?filter=all" 
                           class="btn btn-outline-primary <?php echo $filter === 'all' ? 'active' : ''; ?>">
                            <i class="fas fa-list me-2"></i> Tất cả (<?php echo $total_notifications; ?>)
                        </a>
                        <a href="notifications.php?filter=unread" 
                           class="btn btn-outline-primary <?php echo $filter === 'unread' ? 'active' : ''; ?>">
                            <i class="fas fa-envelope me-2"></i> Chưa đọc (<?php echo $unread_count; ?>)
                        </a>
                        <a href="notifications.php?filter=read" 
                           class="btn btn-outline-primary <?php echo $filter === 'read' ? 'active' : ''; ?>">
                            <i class="fas fa-envelope-open me-2"></i> Đã đọc
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Danh sách thông báo -->
            <?php if ($notifications && $notifications->num_rows > 0): ?>
                <div class="list-group">
                    <?php while($notif = $notifications->fetch_assoc()): ?>
                        <div class="list-group-item <?php echo $notif['is_read'] ? '' : 'list-group-item-info'; ?>">
                            <div class="d-flex w-100 justify-content-between align-items-start">
                                <div class="flex-grow-1">
                                    <h5 class="mb-2">
                                        <?php 
                                        $icons = [
                                            'success' => 'fa-check-circle text-success',
                                            'error' => 'fa-times-circle text-danger',
                                            'info' => 'fa-info-circle text-info',
                                            'warning' => 'fa-exclamation-triangle text-warning'
                                        ];
                                        $icon = $icons[$notif['type']] ?? 'fa-bell text-primary';
                                        ?>
                                        <i class="fas <?php echo $icon; ?> me-2"></i>
                                        <?php echo htmlspecialchars($notif['title']); ?>
                                        
                                        <?php if (!$notif['is_read']): ?>
                                            <span class="badge bg-primary ms-2">Mới</span>
                                        <?php endif; ?>
                                    </h5>
                                    
                                    <p class="mb-2"><?php echo nl2br(htmlspecialchars($notif['message'])); ?></p>
                                    
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i>
                                        <?php echo format_date($notif['created_at'], 'd/m/Y H:i'); ?>
                                    </small>
                                    
                                    <?php if (!empty($notif['link'])): ?>
                                        <a href="<?php echo htmlspecialchars($notif['link']); ?>" 
                                           class="btn btn-sm btn-outline-primary ms-3">
                                            <i class="fas fa-external-link-alt me-1"></i> Xem chi tiết
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="ms-3">
                                    <?php if (!$notif['is_read']): ?>
                                        <a href="mark_notification_read.php?id=<?php echo $notif['notification_id']; ?>&redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>" 
                                           class="btn btn-sm btn-outline-success me-2"
                                           title="Đánh dấu đã đọc">
                                            <i class="fas fa-check"></i>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="?action=delete&id=<?php echo $notif['notification_id']; ?>" 
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Xóa thông báo này?')"
                                       title="Xóa">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($current_page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $current_page - 1; ?>&filter=<?php echo $filter; ?>">
                                        <i class="fas fa-chevron-left"></i> Trước
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == 1 || $i == $total_pages || ($i >= $current_page - 2 && $i <= $current_page + 2)): ?>
                                    <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&filter=<?php echo $filter; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php elseif ($i == $current_page - 3 || $i == $current_page + 3): ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">...</span>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($current_page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $current_page + 1; ?>&filter=<?php echo $filter; ?>">
                                        Sau <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-bell-slash fa-5x text-muted mb-4"></i>
                        <h4 class="text-muted">Không có thông báo nào</h4>
                        <p class="text-muted">
                            <?php if ($filter === 'unread'): ?>
                                Bạn đã đọc hết tất cả thông báo!
                            <?php else: ?>
                                Bạn chưa có thông báo nào.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>